.. code:: ipython3

    #Load necessary library
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    sns.set(style="white", color_codes=True)
    sns.set(font_scale=1.2)

.. code:: ipython3

    df = pd.read_csv('health care diabetes.csv')
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Pregnancies</th>
          <th>Glucose</th>
          <th>BloodPressure</th>
          <th>SkinThickness</th>
          <th>Insulin</th>
          <th>BMI</th>
          <th>DiabetesPedigreeFunction</th>
          <th>Age</th>
          <th>Outcome</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>6</td>
          <td>148</td>
          <td>72</td>
          <td>35</td>
          <td>0</td>
          <td>33.6</td>
          <td>0.627</td>
          <td>50</td>
          <td>1</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>85</td>
          <td>66</td>
          <td>29</td>
          <td>0</td>
          <td>26.6</td>
          <td>0.351</td>
          <td>31</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>8</td>
          <td>183</td>
          <td>64</td>
          <td>0</td>
          <td>0</td>
          <td>23.3</td>
          <td>0.672</td>
          <td>32</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>89</td>
          <td>66</td>
          <td>23</td>
          <td>94</td>
          <td>28.1</td>
          <td>0.167</td>
          <td>21</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>0</td>
          <td>137</td>
          <td>40</td>
          <td>35</td>
          <td>168</td>
          <td>43.1</td>
          <td>2.288</td>
          <td>33</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    cols_with_null_as_zero = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
    df[cols_with_null_as_zero] = df[cols_with_null_as_zero].replace(0, np.NaN)

.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 768 entries, 0 to 767
    Data columns (total 9 columns):
     #   Column                    Non-Null Count  Dtype  
    ---  ------                    --------------  -----  
     0   Pregnancies               768 non-null    int64  
     1   Glucose                   763 non-null    float64
     2   BloodPressure             733 non-null    float64
     3   SkinThickness             541 non-null    float64
     4   Insulin                   394 non-null    float64
     5   BMI                       757 non-null    float64
     6   DiabetesPedigreeFunction  768 non-null    float64
     7   Age                       768 non-null    int64  
     8   Outcome                   768 non-null    int64  
    dtypes: float64(6), int64(3)
    memory usage: 54.1 KB


.. code:: ipython3

    df.isnull().sum()




.. parsed-literal::

    Pregnancies                   0
    Glucose                       5
    BloodPressure                35
    SkinThickness               227
    Insulin                     374
    BMI                          11
    DiabetesPedigreeFunction      0
    Age                           0
    Outcome                       0
    dtype: int64



.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Pregnancies</th>
          <th>Glucose</th>
          <th>BloodPressure</th>
          <th>SkinThickness</th>
          <th>Insulin</th>
          <th>BMI</th>
          <th>DiabetesPedigreeFunction</th>
          <th>Age</th>
          <th>Outcome</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>768.000000</td>
          <td>763.000000</td>
          <td>733.000000</td>
          <td>541.000000</td>
          <td>394.000000</td>
          <td>757.000000</td>
          <td>768.000000</td>
          <td>768.000000</td>
          <td>768.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>3.845052</td>
          <td>121.686763</td>
          <td>72.405184</td>
          <td>29.153420</td>
          <td>155.548223</td>
          <td>32.457464</td>
          <td>0.471876</td>
          <td>33.240885</td>
          <td>0.348958</td>
        </tr>
        <tr>
          <th>std</th>
          <td>3.369578</td>
          <td>30.535641</td>
          <td>12.382158</td>
          <td>10.476982</td>
          <td>118.775855</td>
          <td>6.924988</td>
          <td>0.331329</td>
          <td>11.760232</td>
          <td>0.476951</td>
        </tr>
        <tr>
          <th>min</th>
          <td>0.000000</td>
          <td>44.000000</td>
          <td>24.000000</td>
          <td>7.000000</td>
          <td>14.000000</td>
          <td>18.200000</td>
          <td>0.078000</td>
          <td>21.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>1.000000</td>
          <td>99.000000</td>
          <td>64.000000</td>
          <td>22.000000</td>
          <td>76.250000</td>
          <td>27.500000</td>
          <td>0.243750</td>
          <td>24.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>3.000000</td>
          <td>117.000000</td>
          <td>72.000000</td>
          <td>29.000000</td>
          <td>125.000000</td>
          <td>32.300000</td>
          <td>0.372500</td>
          <td>29.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>6.000000</td>
          <td>141.000000</td>
          <td>80.000000</td>
          <td>36.000000</td>
          <td>190.000000</td>
          <td>36.600000</td>
          <td>0.626250</td>
          <td>41.000000</td>
          <td>1.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>17.000000</td>
          <td>199.000000</td>
          <td>122.000000</td>
          <td>99.000000</td>
          <td>846.000000</td>
          <td>67.100000</td>
          <td>2.420000</td>
          <td>81.000000</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



Visually explore these variables using histograms and treat the missing
values

.. code:: ipython3

    df['Glucose'].hist();



.. image:: output_7_0.png


.. code:: ipython3

    df['BloodPressure'].hist();



.. image:: output_8_0.png


.. code:: ipython3

    df['SkinThickness'].hist();



.. image:: output_9_0.png


.. code:: ipython3

    df['Insulin'].hist();



.. image:: output_10_0.png


.. code:: ipython3

    df['BMI'].hist();



.. image:: output_11_0.png


From above histograms, it is clear that **Insulin** has highly skewed
data distribution \* Glucose - replace missing values with mean of
values. \* BloodPressure - replace missing values with mean of values.
\* SkinThickness - replace missing values with mean of values. \*
Insulin - replace missing values with median of values. \* BMI - replace
missing values with mean of values.

.. code:: ipython3

    df['Insulin'] = df['Insulin'].fillna(df['Insulin'].median())

.. code:: ipython3

    cols_mean_for_null = ['Glucose', 'BloodPressure', 'SkinThickness', 'BMI']
    df[cols_mean_for_null] = df[cols_mean_for_null].fillna(df[cols_mean_for_null].mean())

.. code:: ipython3

    df.dtypes.value_counts().plot(kind='bar');



.. image:: output_15_0.png


Check the balance of the data by plotting the count of outcomes by their
value. Describe your findings and plan future course of action:

.. code:: ipython3

    df['Outcome'].value_counts().plot(kind='bar')
    df['Outcome'].value_counts()




.. parsed-literal::

    0    500
    1    268
    Name: Outcome, dtype: int64




.. image:: output_17_1.png


Since classes in **Outcome** is little skewed so we will generate new
samples using **SMOTE (Synthetic Minority Oversampling Technique)** for
the class ‘**1**’ which is under-represented in our data. We will use
SMOTE out of many other techniques available since:

.. code:: ipython3

    df_X = df.drop('Outcome', axis=1)
    df_y = df['Outcome']
    print(df_X.shape, df_y.shape)


.. parsed-literal::

    (768, 8) (768,)


.. code:: ipython3

    from imblearn.over_sampling import SMOTE

.. code:: ipython3

    df_X_resampled, df_y_resampled = SMOTE(random_state=108).fit_resample(df_X, df_y)
    print(df_X_resampled.shape, df_y_resampled.shape)


.. parsed-literal::

    (1000, 8) (1000,)


.. code:: ipython3

    df_y_resampled.value_counts().plot(kind='bar')
    df_y_resampled.value_counts()




.. parsed-literal::

    1    500
    0    500
    Name: Outcome, dtype: int64




.. image:: output_22_1.png


**(2) Create scatter charts between the pair of variables to understand
the relationships. Describe your findings:**

.. code:: ipython3

    df_resampled = pd.concat([df_X_resampled, df_y_resampled], axis=1)
    df_resampled




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Pregnancies</th>
          <th>Glucose</th>
          <th>BloodPressure</th>
          <th>SkinThickness</th>
          <th>Insulin</th>
          <th>BMI</th>
          <th>DiabetesPedigreeFunction</th>
          <th>Age</th>
          <th>Outcome</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>6</td>
          <td>148.000000</td>
          <td>72.000000</td>
          <td>35.000000</td>
          <td>125.000000</td>
          <td>33.600000</td>
          <td>0.627000</td>
          <td>50</td>
          <td>1</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>85.000000</td>
          <td>66.000000</td>
          <td>29.000000</td>
          <td>125.000000</td>
          <td>26.600000</td>
          <td>0.351000</td>
          <td>31</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>8</td>
          <td>183.000000</td>
          <td>64.000000</td>
          <td>29.153420</td>
          <td>125.000000</td>
          <td>23.300000</td>
          <td>0.672000</td>
          <td>32</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1</td>
          <td>89.000000</td>
          <td>66.000000</td>
          <td>23.000000</td>
          <td>94.000000</td>
          <td>28.100000</td>
          <td>0.167000</td>
          <td>21</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>0</td>
          <td>137.000000</td>
          <td>40.000000</td>
          <td>35.000000</td>
          <td>168.000000</td>
          <td>43.100000</td>
          <td>2.288000</td>
          <td>33</td>
          <td>1</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>995</th>
          <td>3</td>
          <td>164.686765</td>
          <td>74.249021</td>
          <td>29.153420</td>
          <td>125.000000</td>
          <td>42.767110</td>
          <td>0.726091</td>
          <td>29</td>
          <td>1</td>
        </tr>
        <tr>
          <th>996</th>
          <td>0</td>
          <td>138.913540</td>
          <td>69.022720</td>
          <td>27.713033</td>
          <td>127.283849</td>
          <td>39.177649</td>
          <td>0.703702</td>
          <td>24</td>
          <td>1</td>
        </tr>
        <tr>
          <th>997</th>
          <td>10</td>
          <td>131.497740</td>
          <td>66.331574</td>
          <td>33.149837</td>
          <td>125.000000</td>
          <td>45.820819</td>
          <td>0.498032</td>
          <td>38</td>
          <td>1</td>
        </tr>
        <tr>
          <th>998</th>
          <td>0</td>
          <td>105.571347</td>
          <td>83.238205</td>
          <td>29.153420</td>
          <td>125.000000</td>
          <td>27.728596</td>
          <td>0.649204</td>
          <td>60</td>
          <td>1</td>
        </tr>
        <tr>
          <th>999</th>
          <td>0</td>
          <td>127.727025</td>
          <td>108.908879</td>
          <td>44.468195</td>
          <td>129.545366</td>
          <td>65.808840</td>
          <td>0.308998</td>
          <td>26</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    <p>1000 rows × 9 columns</p>
    </div>



.. code:: ipython3

    sns.set(rc={'figure.figsize':(5,5)})
    sns.scatterplot(x="Pregnancies", y="Glucose", data=df_resampled, hue="Outcome");



.. image:: output_25_0.png


.. code:: ipython3

    fig, axes = plt.subplots(8, 8, figsize=(18, 15))
    fig.suptitle('Scatter Plot for Features in Training Data')
    
    for i, col_y in enumerate(df_X_resampled.columns):
        for j, col_x in enumerate(df_X_resampled.columns):             
            sns.scatterplot(ax=axes[i, j], x=col_x, y=col_y, data=df_resampled, hue="Outcome", legend = False)
    
    plt.tight_layout()



.. image:: output_26_0.png


Perform correlation analysis. Visually explore it using a heat map:

.. code:: ipython3

    df_X_resampled.corr()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Pregnancies</th>
          <th>Glucose</th>
          <th>BloodPressure</th>
          <th>SkinThickness</th>
          <th>Insulin</th>
          <th>BMI</th>
          <th>DiabetesPedigreeFunction</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Pregnancies</th>
          <td>1.000000</td>
          <td>0.079953</td>
          <td>0.205232</td>
          <td>0.082752</td>
          <td>0.009365</td>
          <td>0.021006</td>
          <td>-0.040210</td>
          <td>0.532660</td>
        </tr>
        <tr>
          <th>Glucose</th>
          <td>0.079953</td>
          <td>1.000000</td>
          <td>0.200717</td>
          <td>0.189776</td>
          <td>0.418830</td>
          <td>0.242501</td>
          <td>0.138945</td>
          <td>0.235522</td>
        </tr>
        <tr>
          <th>BloodPressure</th>
          <td>0.205232</td>
          <td>0.200717</td>
          <td>1.000000</td>
          <td>0.176496</td>
          <td>0.034861</td>
          <td>0.277565</td>
          <td>-0.005850</td>
          <td>0.332015</td>
        </tr>
        <tr>
          <th>SkinThickness</th>
          <td>0.082752</td>
          <td>0.189776</td>
          <td>0.176496</td>
          <td>1.000000</td>
          <td>0.170719</td>
          <td>0.538207</td>
          <td>0.120799</td>
          <td>0.117644</td>
        </tr>
        <tr>
          <th>Insulin</th>
          <td>0.009365</td>
          <td>0.418830</td>
          <td>0.034861</td>
          <td>0.170719</td>
          <td>1.000000</td>
          <td>0.168702</td>
          <td>0.115187</td>
          <td>0.096940</td>
        </tr>
        <tr>
          <th>BMI</th>
          <td>0.021006</td>
          <td>0.242501</td>
          <td>0.277565</td>
          <td>0.538207</td>
          <td>0.168702</td>
          <td>1.000000</td>
          <td>0.177915</td>
          <td>0.017529</td>
        </tr>
        <tr>
          <th>DiabetesPedigreeFunction</th>
          <td>-0.040210</td>
          <td>0.138945</td>
          <td>-0.005850</td>
          <td>0.120799</td>
          <td>0.115187</td>
          <td>0.177915</td>
          <td>1.000000</td>
          <td>0.010532</td>
        </tr>
        <tr>
          <th>Age</th>
          <td>0.532660</td>
          <td>0.235522</td>
          <td>0.332015</td>
          <td>0.117644</td>
          <td>0.096940</td>
          <td>0.017529</td>
          <td>0.010532</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    plt.figure(figsize=(12,8))
    sns.heatmap(df_X_resampled.corr(), cmap='bwr', annot=True);



.. image:: output_29_0.png


.. code:: ipython3

    from sklearn.model_selection import train_test_split, KFold, RandomizedSearchCV
    from sklearn.metrics import accuracy_score, average_precision_score, f1_score, confusion_matrix, classification_report, auc, roc_curve, roc_auc_score, precision_recall_curve

.. code:: ipython3

    X_train, X_test, y_train, y_test = train_test_split(df_X_resampled, df_y_resampled, test_size=0.15, random_state =10)

.. code:: ipython3

    X_train.shape, X_test.shape




.. parsed-literal::

    ((850, 8), (150, 8))



.. code:: ipython3

    models = []
    model_accuracy = []
    model_f1 = []
    model_auc = []

Logistic Regression:

.. code:: ipython3

    from sklearn.linear_model import LogisticRegression
    lr1 = LogisticRegression(max_iter=300)

.. code:: ipython3

    lr1.fit(X_train,y_train)




.. parsed-literal::

    LogisticRegression(max_iter=300)



.. code:: ipython3

    lr1.score(X_train,y_train)




.. parsed-literal::

    0.7294117647058823



.. code:: ipython3

    lr1.score(X_test, y_test)




.. parsed-literal::

    0.76



**Performance evaluation and optimizing parameters using GridSearchCV:**
Logistic regression does not really have any critical hyperparameters to
tune. However we will try to optimize one of its parameters ‘C’ with the
help of GridSearchCV. So we have set this parameter as a list of values
form which GridSearchCV will select the best value of parameter.

.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = lr2.predict_proba(X_test)                # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_lr = roc_auc_score(y_test, probs)            # calculate AUC
    print('AUC: %.3f' %auc_lr)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.884



.. image:: output_40_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = lr2.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_lr_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_lr_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.790 auc_pr=0.908 ap=0.909



.. image:: output_41_1.png


.. code:: ipython3

    models.append('LR')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_lr)

Decision Tree:

.. code:: ipython3

    from sklearn.tree import DecisionTreeClassifier
    dt1 = DecisionTreeClassifier(random_state=0)     

.. code:: ipython3

    dt1.fit(X_train,y_train)




.. parsed-literal::

    DecisionTreeClassifier(random_state=0)



.. code:: ipython3

    dt1.score(X_train,y_train)           # Decision Tree always 100% accuracy over train data




.. parsed-literal::

    1.0



.. code:: ipython3

    dt1.score(X_test, y_test)




.. parsed-literal::

    0.7733333333333333



**Performance evaluation and optimizing parameters using GridSearchCV:**

.. code:: ipython3

    parameters = {
        'max_depth':[1,2,3,4,5,None]
    }

.. code:: ipython3

    gs_dt = GridSearchCV(dt1, param_grid = parameters, cv=5, verbose=0)
    gs_dt.fit(df_X_resampled, df_y_resampled)




.. parsed-literal::

    GridSearchCV(cv=5, estimator=DecisionTreeClassifier(random_state=0),
                 param_grid={'max_depth': [1, 2, 3, 4, 5, None]})



.. code:: ipython3

    gs_dt.best_params_




.. parsed-literal::

    {'max_depth': 4}



.. code:: ipython3

    gs_dt.best_score_




.. parsed-literal::

    0.76



.. code:: ipython3

    dt1.feature_importances_




.. parsed-literal::

    array([0.06452226, 0.28556999, 0.06715314, 0.04979714, 0.07150365,
           0.20905992, 0.08573109, 0.16666279])



.. code:: ipython3

    X_train.columns




.. parsed-literal::

    Index(['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
           'BMI', 'DiabetesPedigreeFunction', 'Age'],
          dtype='object')



.. code:: ipython3

    import seaborn as sns
    import matplotlib.pyplot as plt
    
    plt.figure(figsize=(8,3))
    sns.barplot(y=X_train.columns, x=dt1.feature_importances_)
    plt.title("Feature Importance in Model");



.. image:: output_55_0.png


.. code:: ipython3

    dt2 = DecisionTreeClassifier(max_depth=4)

.. code:: ipython3

    dt2.fit(X_train,y_train)




.. parsed-literal::

    DecisionTreeClassifier(max_depth=4)



.. code:: ipython3

    dt2.score(X_train,y_train)




.. parsed-literal::

    0.8070588235294117



.. code:: ipython3

    dt2.score(X_test, y_test)




.. parsed-literal::

    0.82



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = dt2.predict_proba(X_test)                # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_dt = roc_auc_score(y_test, probs)            # calculate AUC
    print('AUC: %.3f' %auc_dt)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.879



.. image:: output_60_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = dt2.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_dt_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_dt_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.844 auc_pr=0.717 ap=0.868



.. image:: output_61_1.png


.. code:: ipython3

    models.append('DT')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_dt)

RandomForest Classifier

.. code:: ipython3

    from sklearn.ensemble import RandomForestClassifier
    rf1 = RandomForestClassifier()

.. code:: ipython3

    rf1 = RandomForestClassifier(random_state=0)

.. code:: ipython3

    rf1.fit(X_train, y_train)




.. parsed-literal::

    RandomForestClassifier(random_state=0)



.. code:: ipython3

    rf1.score(X_train, y_train)            # Random Forest also 100% accuracy over train data always




.. parsed-literal::

    1.0



.. code:: ipython3

    rf1.score(X_test, y_test)




.. parsed-literal::

    0.8466666666666667



**Performance evaluation and optimizing parameters using GridSearchCV:**

.. code:: ipython3

    parameters = {
        'n_estimators': [50,100,150],
        'max_depth': [None,1,3,5,7],
        'min_samples_leaf': [1,3,5]
    }

.. code:: ipython3

    gs_dt = GridSearchCV(estimator=rf1, param_grid=parameters, cv=5, verbose=0)
    gs_dt.fit(df_X_resampled, df_y_resampled)




.. parsed-literal::

    GridSearchCV(cv=5, estimator=RandomForestClassifier(random_state=0),
                 param_grid={'max_depth': [None, 1, 3, 5, 7],
                             'min_samples_leaf': [1, 3, 5],
                             'n_estimators': [50, 100, 150]})



.. code:: ipython3

    gs_dt.best_params_




.. parsed-literal::

    {'max_depth': None, 'min_samples_leaf': 1, 'n_estimators': 100}



.. code:: ipython3

    gs_dt.best_score_




.. parsed-literal::

    0.813



.. code:: ipython3

    rf1.feature_importances_




.. parsed-literal::

    array([0.06264995, 0.24106573, 0.08653626, 0.08301549, 0.09945063,
           0.17678287, 0.11685244, 0.13364664])



.. code:: ipython3

    plt.figure(figsize=(8,3))
    sns.barplot(y=X_train.columns, x=rf1.feature_importances_);
    plt.title("Feature Importance in Model");



.. image:: output_75_0.png


.. code:: ipython3

    rf2 = RandomForestClassifier(max_depth=None, min_samples_leaf=1, n_estimators=100)

.. code:: ipython3

    rf2.fit(X_train,y_train)




.. parsed-literal::

    RandomForestClassifier()



.. code:: ipython3

    rf2.score(X_train,y_train)




.. parsed-literal::

    1.0



.. code:: ipython3

    rf2.score(X_test, y_test)




.. parsed-literal::

    0.86



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = rf2.predict_proba(X_test)                # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_rf = roc_auc_score(y_test, probs)            # calculate AUC
    print('AUC: %.3f' %auc_rf)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.928



.. image:: output_80_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = rf2.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_rf_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_rf_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.873 auc_pr=0.938 ap=0.936



.. image:: output_81_1.png


.. code:: ipython3

    models.append('RF')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_dt)

K-Nearest Neighbour (KNN) Classification:

.. code:: ipython3

    from sklearn.neighbors import KNeighborsClassifier
    knn1 = KNeighborsClassifier(n_neighbors=3)

.. code:: ipython3

    knn1.fit(X_train, y_train)




.. parsed-literal::

    KNeighborsClassifier(n_neighbors=3)



.. code:: ipython3

    knn1.score(X_train,y_train)




.. parsed-literal::

    0.8835294117647059



.. code:: ipython3

    knn1.score(X_test,y_test)




.. parsed-literal::

    0.7866666666666666



**Performance evaluation and optimizing parameters using GridSearchCV:**

.. code:: ipython3

    knn_neighbors = [i for i in range(2,16)]
    parameters = {
        'n_neighbors': knn_neighbors
    }

.. code:: ipython3

    gs_knn = GridSearchCV(estimator=knn1, param_grid=parameters, cv=5, verbose=0)
    gs_knn.fit(df_X_resampled, df_y_resampled)




.. parsed-literal::

    GridSearchCV(cv=5, estimator=KNeighborsClassifier(n_neighbors=3),
                 param_grid={'n_neighbors': [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
                                             14, 15]})



.. code:: ipython3

    gs_knn.best_params_




.. parsed-literal::

    {'n_neighbors': 3}



.. code:: ipython3

    gs_knn.best_score_




.. parsed-literal::

    0.771



.. code:: ipython3

    # gs_knn.cv_results_
    gs_knn.cv_results_['mean_test_score']




.. parsed-literal::

    array([0.76 , 0.771, 0.765, 0.757, 0.757, 0.739, 0.744, 0.746, 0.744,
           0.755, 0.751, 0.755, 0.754, 0.749])



.. code:: ipython3

    plt.figure(figsize=(6,4))
    sns.barplot(x=knn_neighbors, y=gs_knn.cv_results_['mean_test_score'])
    plt.xlabel("N_Neighbors")
    plt.ylabel("Test Accuracy")
    plt.title("Test Accuracy vs. N_Neighbors");



.. image:: output_94_0.png


.. code:: ipython3

    knn2 = KNeighborsClassifier(n_neighbors=3)

.. code:: ipython3

    knn2.fit(X_train, y_train)




.. parsed-literal::

    KNeighborsClassifier(n_neighbors=3)



.. code:: ipython3

    knn2.score(X_train,y_train)




.. parsed-literal::

    0.8835294117647059



.. code:: ipython3

    knn2.score(X_test,y_test)




.. parsed-literal::

    0.7866666666666666



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = knn2.predict_proba(X_test)               # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_knn = roc_auc_score(y_test, probs)           # calculate AUC
    print('AUC: %.3f' %auc_knn)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.852



.. image:: output_99_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = knn2.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_knn_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_knn_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.814 auc_pr=0.885 ap=0.832



.. image:: output_100_1.png


.. code:: ipython3

    models.append('KNN')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_knn)

Support Vector Machine (SVM) Algorithm:

.. code:: ipython3

    from sklearn.svm import SVC
    svm1 = SVC(kernel='rbf')

.. code:: ipython3

    svm1.fit(X_train, y_train)




.. parsed-literal::

    SVC()



.. code:: ipython3

    svm1.score(X_train, y_train)




.. parsed-literal::

    0.7282352941176471



.. code:: ipython3

    svm1.score(X_test, y_test)




.. parsed-literal::

    0.78



**Performance evaluation and optimizing parameters using GridSearchCV:**

.. code:: ipython3

    parameters = {
        'C':[1, 5, 10, 15, 20, 25],
        'gamma':[0.001, 0.005, 0.0001, 0.00001]
    }

.. code:: ipython3

    gs_svm = GridSearchCV(estimator=svm1, param_grid=parameters, cv=5, verbose=0)
    gs_svm.fit(df_X_resampled, df_y_resampled)




.. parsed-literal::

    GridSearchCV(cv=5, estimator=SVC(),
                 param_grid={'C': [1, 5, 10, 15, 20, 25],
                             'gamma': [0.001, 0.005, 0.0001, 1e-05]})



.. code:: ipython3

    gs_svm.best_params_




.. parsed-literal::

    {'C': 20, 'gamma': 0.005}



.. code:: ipython3

    gs_svm.best_score_




.. parsed-literal::

    0.8089999999999999



.. code:: ipython3

    svm2 = SVC(kernel='rbf', C=20, gamma=0.005, probability=True)

.. code:: ipython3

    svm2.fit(X_train, y_train)




.. parsed-literal::

    SVC(C=20, gamma=0.005, probability=True)



.. code:: ipython3

    svm2.score(X_train, y_train)




.. parsed-literal::

    0.9941176470588236



.. code:: ipython3

    svm2.score(X_test, y_test)




.. parsed-literal::

    0.8133333333333334



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = svm2.predict_proba(X_test)               # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_svm = roc_auc_score(y_test, probs)           # calculate AUC
    print('AUC: %.3f' %auc_svm)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.857



.. image:: output_116_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = svm2.predict(X_test)                                    # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_svm_pr = auc(recall, precision)                                   # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_svm_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.829 auc_pr=0.830 ap=0.837



.. image:: output_117_1.png


.. code:: ipython3

    models.append('SVM')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_svm)

Naive Bayes Algorithm:

.. code:: ipython3

    from sklearn.naive_bayes import GaussianNB, BernoulliNB, MultinomialNB
    gnb = GaussianNB()

.. code:: ipython3

    gnb.fit(X_train, y_train)




.. parsed-literal::

    GaussianNB()



.. code:: ipython3

    gnb.score(X_train, y_train)




.. parsed-literal::

    0.7294117647058823



.. code:: ipython3

    gnb.score(X_test, y_test)




.. parsed-literal::

    0.8



**Naive Bayes has almost no hyperparameters to tune, so it usually
generalizes well.**

.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = gnb.predict_proba(X_test)                # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_gnb = roc_auc_score(y_test, probs)            # calculate AUC
    print('AUC: %.3f' %auc_gnb)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.873



.. image:: output_125_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = gnb.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_gnb_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_gnb_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.819 auc_pr=0.879 ap=0.880



.. image:: output_126_1.png


.. code:: ipython3

    models.append('GNB')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_gnb)

Ensemble Learning –> Boosting –> Adaptive Boosting:

.. code:: ipython3

    from sklearn.ensemble import AdaBoostClassifier
    ada1 = AdaBoostClassifier(n_estimators=100)

.. code:: ipython3

    ada1.fit(X_train,y_train)




.. parsed-literal::

    AdaBoostClassifier(n_estimators=100)



.. code:: ipython3

    ada1.score(X_train,y_train)  




.. parsed-literal::

    0.8564705882352941



.. code:: ipython3

    ada1.score(X_test, y_test)




.. parsed-literal::

    0.7666666666666667



**Performance evaluation and optimizing parameters using
cross_val_score:**

.. code:: ipython3

    parameters = {'n_estimators': [100,200,300,400,500,700,1000]}

.. code:: ipython3

    gs_ada = GridSearchCV(ada1, param_grid = parameters, cv=5, verbose=0)
    gs_ada.fit(df_X_resampled, df_y_resampled)




.. parsed-literal::

    GridSearchCV(cv=5, estimator=AdaBoostClassifier(n_estimators=100),
                 param_grid={'n_estimators': [100, 200, 300, 400, 500, 700, 1000]})



.. code:: ipython3

    gs_ada.best_params_




.. parsed-literal::

    {'n_estimators': 500}



.. code:: ipython3

    gs_ada.best_score_




.. parsed-literal::

    0.785



.. code:: ipython3

    ada1.feature_importances_




.. parsed-literal::

    array([0.03, 0.16, 0.2 , 0.11, 0.16, 0.18, 0.11, 0.05])



.. code:: ipython3

    plt.figure(figsize=(8,3))
    sns.barplot(y=X_train.columns, x=ada1.feature_importances_)
    plt.title("Feature Importance in Model");



.. image:: output_139_0.png


.. code:: ipython3

    ada2 = AdaBoostClassifier(n_estimators=500)

.. code:: ipython3

    ada2.fit(X_train,y_train)




.. parsed-literal::

    AdaBoostClassifier(n_estimators=500)



.. code:: ipython3

    ada2.score(X_train,y_train)




.. parsed-literal::

    0.9247058823529412



.. code:: ipython3

    ada2.score(X_test, y_test)




.. parsed-literal::

    0.7733333333333333



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = ada2.predict_proba(X_test)               # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_ada = roc_auc_score(y_test, probs)           # calculate AUC
    print('AUC: %.3f' %auc_ada)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.850



.. image:: output_144_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = ada2.predict(X_test)                                    # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_ada_pr = auc(recall, precision)                                   # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_ada_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.785 auc_pr=0.838 ap=0.845



.. image:: output_145_1.png


.. code:: ipython3

    models.append('ADA')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_ada)

Ensemble Learning –> Boosting –> Gradient Boosting (XGBClassifier):

.. code:: ipython3

    from xgboost import XGBClassifier
    xgb1 = XGBClassifier(use_label_encoder=False, objective = 'binary:logistic', nthread=4, seed=10)

.. code:: ipython3

    xgb1.fit(X_train, y_train)


.. parsed-literal::

    [01:58:23] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.5.1/src/learner.cc:1115: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.




.. parsed-literal::

    XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                  colsample_bynode=1, colsample_bytree=1, enable_categorical=False,
                  gamma=0, gpu_id=-1, importance_type=None,
                  interaction_constraints='', learning_rate=0.300000012,
                  max_delta_step=0, max_depth=6, min_child_weight=1, missing=nan,
                  monotone_constraints='()', n_estimators=100, n_jobs=4, nthread=4,
                  num_parallel_tree=1, predictor='auto', random_state=10,
                  reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=10,
                  subsample=1, tree_method='exact', use_label_encoder=False,
                  validate_parameters=1, ...)



.. code:: ipython3

    xgb1.score(X_train, y_train) 




.. parsed-literal::

    1.0



.. code:: ipython3

    xgb1.score(X_test, y_test)




.. parsed-literal::

    0.8266666666666667



**Performance evaluation and optimizing parameters using GridSearchCV:**

.. code:: ipython3

    parameters = {
        'max_depth': range (2, 10, 1),
        'n_estimators': range(60, 220, 40),
        'learning_rate': [0.1, 0.01, 0.05]
    }

.. code:: ipython3

    gs_xgb = GridSearchCV(xgb1, param_grid = parameters, scoring = 'roc_auc', n_jobs = 10, cv=5, verbose=0)
    gs_xgb.fit(df_X_resampled, df_y_resampled)


.. parsed-literal::

    [02:00:05] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.5.1/src/learner.cc:1115: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.




.. parsed-literal::

    GridSearchCV(cv=5,
                 estimator=XGBClassifier(base_score=0.5, booster='gbtree',
                                         colsample_bylevel=1, colsample_bynode=1,
                                         colsample_bytree=1,
                                         enable_categorical=False, gamma=0,
                                         gpu_id=-1, importance_type=None,
                                         interaction_constraints='',
                                         learning_rate=0.300000012,
                                         max_delta_step=0, max_depth=6,
                                         min_child_weight=1, missing=nan,
                                         monotone_constraints='()',
                                         n_estimators=100, n_jobs=4, nthread=4,
                                         num_parallel_tree=1, predictor='auto',
                                         random_state=10, reg_alpha=0, reg_lambda=1,
                                         scale_pos_weight=1, seed=10, subsample=1,
                                         tree_method='exact',
                                         use_label_encoder=False,
                                         validate_parameters=1, ...),
                 n_jobs=10,
                 param_grid={'learning_rate': [0.1, 0.01, 0.05],
                             'max_depth': range(2, 10),
                             'n_estimators': range(60, 220, 40)},
                 scoring='roc_auc')



.. code:: ipython3

    gs_xgb.best_params_




.. parsed-literal::

    {'learning_rate': 0.05, 'max_depth': 7, 'n_estimators': 180}



.. code:: ipython3

    gs_xgb.best_score_




.. parsed-literal::

    0.88522



.. code:: ipython3

    xgb1.feature_importances_




.. parsed-literal::

    array([0.09883171, 0.23199296, 0.09590795, 0.08073226, 0.10332598,
           0.15247224, 0.08829137, 0.14844562], dtype=float32)



.. code:: ipython3

    plt.figure(figsize=(8,3))
    sns.barplot(y=X_train.columns, x=xgb1.feature_importances_)
    plt.title("Feature Importance in Model");



.. image:: output_158_0.png


.. code:: ipython3

    xgb2 = XGBClassifier(use_label_encoder=False, objective = 'binary:logistic', 
                        nthread=4, seed=10, learning_rate= 0.05, max_depth= 7, n_estimators= 180)

.. code:: ipython3

    xgb2.fit(X_train,y_train)


.. parsed-literal::

    [02:00:06] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.5.1/src/learner.cc:1115: Starting in XGBoost 1.3.0, the default evaluation metric used with the objective 'binary:logistic' was changed from 'error' to 'logloss'. Explicitly set eval_metric if you'd like to restore the old behavior.




.. parsed-literal::

    XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
                  colsample_bynode=1, colsample_bytree=1, enable_categorical=False,
                  gamma=0, gpu_id=-1, importance_type=None,
                  interaction_constraints='', learning_rate=0.05, max_delta_step=0,
                  max_depth=7, min_child_weight=1, missing=nan,
                  monotone_constraints='()', n_estimators=180, n_jobs=4, nthread=4,
                  num_parallel_tree=1, predictor='auto', random_state=10,
                  reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=10,
                  subsample=1, tree_method='exact', use_label_encoder=False,
                  validate_parameters=1, ...)



.. code:: ipython3

    xgb2.score(X_train,y_train)




.. parsed-literal::

    0.9976470588235294



.. code:: ipython3

    xgb2.score(X_test, y_test)




.. parsed-literal::

    0.8066666666666666



.. code:: ipython3

    # Preparing ROC Curve (Receiver Operating Characteristics Curve)
    
    probs = xgb2.predict_proba(X_test)                # predict probabilities
    probs = probs[:, 1]                              # keep probabilities for the positive outcome only
    
    auc_xgb = roc_auc_score(y_test, probs)            # calculate AUC
    print('AUC: %.3f' %auc_xgb)
    fpr, tpr, thresholds = roc_curve(y_test, probs)  # calculate roc curve
    plt.plot([0, 1], [0, 1], linestyle='--')         # plot no skill
    plt.plot(fpr, tpr, marker='.')                   # plot the roc curve for the model
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC (Receiver Operating Characteristics) Curve");


.. parsed-literal::

    AUC: 0.922



.. image:: output_163_1.png


.. code:: ipython3

    # Precision Recall Curve 
    
    pred_y_test = xgb2.predict(X_test)                                     # predict class values
    precision, recall, thresholds = precision_recall_curve(y_test, probs) # calculate precision-recall curve
    f1 = f1_score(y_test, pred_y_test)                                    # calculate F1 score
    auc_xgb_pr = auc(recall, precision)                                    # calculate precision-recall AUC
    ap = average_precision_score(y_test, probs)                           # calculate average precision score
    print('f1=%.3f auc_pr=%.3f ap=%.3f' % (f1, auc_xgb_pr, ap))
    plt.plot([0, 1], [0.5, 0.5], linestyle='--')                          # plot no skill
    plt.plot(recall, precision, marker='.')                               # plot the precision-recall curve for the model
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve");


.. parsed-literal::

    f1=0.824 auc_pr=0.936 ap=0.937



.. image:: output_164_1.png


.. code:: ipython3

    models.append('XGB')
    model_accuracy.append(accuracy_score(y_test, pred_y_test))
    model_f1.append(f1)
    model_auc.append(auc_xgb)

.. code:: ipython3

    model_summary = pd.DataFrame(zip(models,model_accuracy,model_f1,model_auc), columns = ['model','accuracy','f1_score','auc'])
    model_summary = model_summary.set_index('model')

.. code:: ipython3

    model_summary.plot(figsize=(16,5))
    plt.title("Comparison of Different Classification Algorithms");



.. image:: output_167_0.png


.. code:: ipython3

    model_summary




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>accuracy</th>
          <th>f1_score</th>
          <th>auc</th>
        </tr>
        <tr>
          <th>model</th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>LR</th>
          <td>0.773333</td>
          <td>0.790123</td>
          <td>0.883967</td>
        </tr>
        <tr>
          <th>DT</th>
          <td>0.820000</td>
          <td>0.843931</td>
          <td>0.879484</td>
        </tr>
        <tr>
          <th>RF</th>
          <td>0.860000</td>
          <td>0.872727</td>
          <td>0.879484</td>
        </tr>
        <tr>
          <th>KNN</th>
          <td>0.786667</td>
          <td>0.813953</td>
          <td>0.851865</td>
        </tr>
        <tr>
          <th>SVM</th>
          <td>0.813333</td>
          <td>0.829268</td>
          <td>0.857425</td>
        </tr>
        <tr>
          <th>GNB</th>
          <td>0.800000</td>
          <td>0.819277</td>
          <td>0.872848</td>
        </tr>
        <tr>
          <th>ADA</th>
          <td>0.773333</td>
          <td>0.784810</td>
          <td>0.850430</td>
        </tr>
        <tr>
          <th>XGB</th>
          <td>0.806667</td>
          <td>0.824242</td>
          <td>0.921808</td>
        </tr>
      </tbody>
    </table>
    </div>



**Among all models, RandomForest has given best accuracy and f1_score.
Therefore we will build final model using RandomForest.**

FINAL CLASSIFIER:
^^^^^^^^^^^^^^^^^

.. code:: ipython3

    final_model = rf2

.. code:: ipython3

    cr = classification_report(y_test, final_model.predict(X_test))
    print(cr)


.. parsed-literal::

                  precision    recall  f1-score   support
    
               0       0.85      0.84      0.84        68
               1       0.87      0.88      0.87        82
    
        accuracy                           0.86       150
       macro avg       0.86      0.86      0.86       150
    weighted avg       0.86      0.86      0.86       150
    


.. code:: ipython3

    confusion = confusion_matrix(y_test, final_model.predict(X_test))
    print("Confusion Matrix:\n", confusion)


.. parsed-literal::

    Confusion Matrix:
     [[57 11]
     [10 72]]


.. code:: ipython3

    TP = confusion[1,1] # true positive 
    TN = confusion[0,0] # true negatives
    FP = confusion[0,1] # false positives
    FN = confusion[1,0] # false negatives
    
    Accuracy = (TP+TN)/(TP+TN+FP+FN)
    Precision = TP/(TP+FP)
    Sensitivity = TP/(TP+FN)                     # also called recall
    Specificity = TN/(TN+FP)

.. code:: ipython3

    print("Accuracy: %.3f"%Accuracy)
    print("Precision: %.3f"%Precision)
    print("Sensitivity: %.3f"%Sensitivity)
    print("Specificity: %.3f"%Specificity)
    print("AUC: %.3f"%auc_rf)


.. parsed-literal::

    Accuracy: 0.860
    Precision: 0.867
    Sensitivity: 0.878
    Specificity: 0.838
    AUC: 0.928

