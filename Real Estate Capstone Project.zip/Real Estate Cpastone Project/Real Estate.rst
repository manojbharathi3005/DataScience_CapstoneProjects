Real Estate
===========

1. Import data
~~~~~~~~~~~~~~

.. code:: ipython3

    df_train=pd.read_csv("train.csv")

.. code:: ipython3

    df_test=pd.read_csv("test.csv")

.. code:: ipython3

    df_train.columns




.. parsed-literal::

    Index(['UID', 'BLOCKID', 'SUMLEVEL', 'COUNTYID', 'STATEID', 'state',
           'state_ab', 'city', 'place', 'type', 'primary', 'zip_code', 'area_code',
           'lat', 'lng', 'ALand', 'AWater', 'pop', 'male_pop', 'female_pop',
           'rent_mean', 'rent_median', 'rent_stdev', 'rent_sample_weight',
           'rent_samples', 'rent_gt_10', 'rent_gt_15', 'rent_gt_20', 'rent_gt_25',
           'rent_gt_30', 'rent_gt_35', 'rent_gt_40', 'rent_gt_50',
           'universe_samples', 'used_samples', 'hi_mean', 'hi_median', 'hi_stdev',
           'hi_sample_weight', 'hi_samples', 'family_mean', 'family_median',
           'family_stdev', 'family_sample_weight', 'family_samples',
           'hc_mortgage_mean', 'hc_mortgage_median', 'hc_mortgage_stdev',
           'hc_mortgage_sample_weight', 'hc_mortgage_samples', 'hc_mean',
           'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight',
           'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt',
           'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree',
           'hs_degree_male', 'hs_degree_female', 'male_age_mean',
           'male_age_median', 'male_age_stdev', 'male_age_sample_weight',
           'male_age_samples', 'female_age_mean', 'female_age_median',
           'female_age_stdev', 'female_age_sample_weight', 'female_age_samples',
           'pct_own', 'married', 'married_snp', 'separated', 'divorced'],
          dtype='object')



.. code:: ipython3

    df_test.columns




.. parsed-literal::

    Index(['UID', 'BLOCKID', 'SUMLEVEL', 'COUNTYID', 'STATEID', 'state',
           'state_ab', 'city', 'place', 'type', 'primary', 'zip_code', 'area_code',
           'lat', 'lng', 'ALand', 'AWater', 'pop', 'male_pop', 'female_pop',
           'rent_mean', 'rent_median', 'rent_stdev', 'rent_sample_weight',
           'rent_samples', 'rent_gt_10', 'rent_gt_15', 'rent_gt_20', 'rent_gt_25',
           'rent_gt_30', 'rent_gt_35', 'rent_gt_40', 'rent_gt_50',
           'universe_samples', 'used_samples', 'hi_mean', 'hi_median', 'hi_stdev',
           'hi_sample_weight', 'hi_samples', 'family_mean', 'family_median',
           'family_stdev', 'family_sample_weight', 'family_samples',
           'hc_mortgage_mean', 'hc_mortgage_median', 'hc_mortgage_stdev',
           'hc_mortgage_sample_weight', 'hc_mortgage_samples', 'hc_mean',
           'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight',
           'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt',
           'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree',
           'hs_degree_male', 'hs_degree_female', 'male_age_mean',
           'male_age_median', 'male_age_stdev', 'male_age_sample_weight',
           'male_age_samples', 'female_age_mean', 'female_age_median',
           'female_age_stdev', 'female_age_sample_weight', 'female_age_samples',
           'pct_own', 'married', 'married_snp', 'separated', 'divorced'],
          dtype='object')



.. code:: ipython3

    len(df_train)




.. parsed-literal::

    27321



.. code:: ipython3

    len(df_test)




.. parsed-literal::

    11709



.. code:: ipython3

    df_train.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>UID</th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>state</th>
          <th>state_ab</th>
          <th>city</th>
          <th>place</th>
          <th>type</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>0</td>
          <td>267822</td>
          <td>NaN</td>
          <td>140</td>
          <td>53</td>
          <td>36</td>
          <td>New York</td>
          <td>NY</td>
          <td>Hamilton</td>
          <td>Hamilton</td>
          <td>City</td>
          <td>...</td>
          <td>44.48629</td>
          <td>45.33333</td>
          <td>22.51276</td>
          <td>685.33845</td>
          <td>2618.0</td>
          <td>0.79046</td>
          <td>0.57851</td>
          <td>0.01882</td>
          <td>0.01240</td>
          <td>0.08770</td>
        </tr>
        <tr>
          <td>1</td>
          <td>246444</td>
          <td>NaN</td>
          <td>140</td>
          <td>141</td>
          <td>18</td>
          <td>Indiana</td>
          <td>IN</td>
          <td>South Bend</td>
          <td>Roseland</td>
          <td>City</td>
          <td>...</td>
          <td>36.48391</td>
          <td>37.58333</td>
          <td>23.43353</td>
          <td>267.23367</td>
          <td>1284.0</td>
          <td>0.52483</td>
          <td>0.34886</td>
          <td>0.01426</td>
          <td>0.01426</td>
          <td>0.09030</td>
        </tr>
        <tr>
          <td>2</td>
          <td>245683</td>
          <td>NaN</td>
          <td>140</td>
          <td>63</td>
          <td>18</td>
          <td>Indiana</td>
          <td>IN</td>
          <td>Danville</td>
          <td>Danville</td>
          <td>City</td>
          <td>...</td>
          <td>42.15810</td>
          <td>42.83333</td>
          <td>23.94119</td>
          <td>707.01963</td>
          <td>3238.0</td>
          <td>0.85331</td>
          <td>0.64745</td>
          <td>0.02830</td>
          <td>0.01607</td>
          <td>0.10657</td>
        </tr>
        <tr>
          <td>3</td>
          <td>279653</td>
          <td>NaN</td>
          <td>140</td>
          <td>127</td>
          <td>72</td>
          <td>Puerto Rico</td>
          <td>PR</td>
          <td>San Juan</td>
          <td>Guaynabo</td>
          <td>Urban</td>
          <td>...</td>
          <td>47.77526</td>
          <td>50.58333</td>
          <td>24.32015</td>
          <td>362.20193</td>
          <td>1559.0</td>
          <td>0.65037</td>
          <td>0.47257</td>
          <td>0.02021</td>
          <td>0.02021</td>
          <td>0.10106</td>
        </tr>
        <tr>
          <td>4</td>
          <td>247218</td>
          <td>NaN</td>
          <td>140</td>
          <td>161</td>
          <td>20</td>
          <td>Kansas</td>
          <td>KS</td>
          <td>Manhattan</td>
          <td>Manhattan City</td>
          <td>City</td>
          <td>...</td>
          <td>24.17693</td>
          <td>21.58333</td>
          <td>11.10484</td>
          <td>1854.48652</td>
          <td>3051.0</td>
          <td>0.13046</td>
          <td>0.12356</td>
          <td>0.00000</td>
          <td>0.00000</td>
          <td>0.03109</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 80 columns</p>
    </div>



.. code:: ipython3

    df_test.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>UID</th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>state</th>
          <th>state_ab</th>
          <th>city</th>
          <th>place</th>
          <th>type</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>0</td>
          <td>255504</td>
          <td>NaN</td>
          <td>140</td>
          <td>163</td>
          <td>26</td>
          <td>Michigan</td>
          <td>MI</td>
          <td>Detroit</td>
          <td>Dearborn Heights City</td>
          <td>CDP</td>
          <td>...</td>
          <td>34.78682</td>
          <td>33.75000</td>
          <td>21.58531</td>
          <td>416.48097</td>
          <td>1938.0</td>
          <td>0.70252</td>
          <td>0.28217</td>
          <td>0.05910</td>
          <td>0.03813</td>
          <td>0.14299</td>
        </tr>
        <tr>
          <td>1</td>
          <td>252676</td>
          <td>NaN</td>
          <td>140</td>
          <td>1</td>
          <td>23</td>
          <td>Maine</td>
          <td>ME</td>
          <td>Auburn</td>
          <td>Auburn City</td>
          <td>City</td>
          <td>...</td>
          <td>44.23451</td>
          <td>46.66667</td>
          <td>22.37036</td>
          <td>532.03505</td>
          <td>1950.0</td>
          <td>0.85128</td>
          <td>0.64221</td>
          <td>0.02338</td>
          <td>0.00000</td>
          <td>0.13377</td>
        </tr>
        <tr>
          <td>2</td>
          <td>276314</td>
          <td>NaN</td>
          <td>140</td>
          <td>15</td>
          <td>42</td>
          <td>Pennsylvania</td>
          <td>PA</td>
          <td>Pine City</td>
          <td>Millerton</td>
          <td>Borough</td>
          <td>...</td>
          <td>41.62426</td>
          <td>44.50000</td>
          <td>22.86213</td>
          <td>453.11959</td>
          <td>1879.0</td>
          <td>0.81897</td>
          <td>0.59961</td>
          <td>0.01746</td>
          <td>0.01358</td>
          <td>0.10026</td>
        </tr>
        <tr>
          <td>3</td>
          <td>248614</td>
          <td>NaN</td>
          <td>140</td>
          <td>231</td>
          <td>21</td>
          <td>Kentucky</td>
          <td>KY</td>
          <td>Monticello</td>
          <td>Monticello City</td>
          <td>City</td>
          <td>...</td>
          <td>44.81200</td>
          <td>48.00000</td>
          <td>21.03155</td>
          <td>263.94320</td>
          <td>1081.0</td>
          <td>0.84609</td>
          <td>0.56953</td>
          <td>0.05492</td>
          <td>0.04694</td>
          <td>0.12489</td>
        </tr>
        <tr>
          <td>4</td>
          <td>286865</td>
          <td>NaN</td>
          <td>140</td>
          <td>355</td>
          <td>48</td>
          <td>Texas</td>
          <td>TX</td>
          <td>Corpus Christi</td>
          <td>Edroy</td>
          <td>Town</td>
          <td>...</td>
          <td>40.66618</td>
          <td>42.66667</td>
          <td>21.30900</td>
          <td>709.90829</td>
          <td>2956.0</td>
          <td>0.79077</td>
          <td>0.57620</td>
          <td>0.01726</td>
          <td>0.00588</td>
          <td>0.16379</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 80 columns</p>
    </div>



.. code:: ipython3

    df_train.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>UID</th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>zip_code</th>
          <th>area_code</th>
          <th>lat</th>
          <th>lng</th>
          <th>ALand</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>count</td>
          <td>27321.000000</td>
          <td>0.0</td>
          <td>27321.0</td>
          <td>27321.000000</td>
          <td>27321.000000</td>
          <td>27321.000000</td>
          <td>27321.000000</td>
          <td>27321.000000</td>
          <td>27321.000000</td>
          <td>2.732100e+04</td>
          <td>...</td>
          <td>27115.000000</td>
          <td>27115.000000</td>
          <td>27115.000000</td>
          <td>27115.000000</td>
          <td>27115.000000</td>
          <td>27053.000000</td>
          <td>27130.000000</td>
          <td>27130.000000</td>
          <td>27130.000000</td>
          <td>27130.000000</td>
        </tr>
        <tr>
          <td>mean</td>
          <td>257331.996303</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>85.646426</td>
          <td>28.271806</td>
          <td>50081.999524</td>
          <td>596.507668</td>
          <td>37.508813</td>
          <td>-91.288394</td>
          <td>1.295106e+08</td>
          <td>...</td>
          <td>40.319803</td>
          <td>40.355099</td>
          <td>22.178745</td>
          <td>544.238432</td>
          <td>2208.761903</td>
          <td>0.640434</td>
          <td>0.508300</td>
          <td>0.047537</td>
          <td>0.019089</td>
          <td>0.100248</td>
        </tr>
        <tr>
          <td>std</td>
          <td>21343.859725</td>
          <td>NaN</td>
          <td>0.0</td>
          <td>98.333097</td>
          <td>16.392846</td>
          <td>29558.115660</td>
          <td>232.497482</td>
          <td>5.588268</td>
          <td>16.343816</td>
          <td>1.275531e+09</td>
          <td>...</td>
          <td>5.886317</td>
          <td>8.039585</td>
          <td>2.540257</td>
          <td>283.546896</td>
          <td>1089.316999</td>
          <td>0.226640</td>
          <td>0.136860</td>
          <td>0.037640</td>
          <td>0.020796</td>
          <td>0.049055</td>
        </tr>
        <tr>
          <td>min</td>
          <td>220342.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>602.000000</td>
          <td>201.000000</td>
          <td>17.929085</td>
          <td>-165.453872</td>
          <td>4.113400e+04</td>
          <td>...</td>
          <td>16.008330</td>
          <td>13.250000</td>
          <td>0.556780</td>
          <td>0.664700</td>
          <td>2.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <td>25%</td>
          <td>238816.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>29.000000</td>
          <td>13.000000</td>
          <td>26554.000000</td>
          <td>405.000000</td>
          <td>33.899064</td>
          <td>-97.816067</td>
          <td>1.799408e+06</td>
          <td>...</td>
          <td>36.892050</td>
          <td>34.916670</td>
          <td>21.312135</td>
          <td>355.995825</td>
          <td>1471.000000</td>
          <td>0.502780</td>
          <td>0.425102</td>
          <td>0.020810</td>
          <td>0.004530</td>
          <td>0.065800</td>
        </tr>
        <tr>
          <td>50%</td>
          <td>257220.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>63.000000</td>
          <td>28.000000</td>
          <td>47715.000000</td>
          <td>614.000000</td>
          <td>38.755183</td>
          <td>-86.554374</td>
          <td>4.866940e+06</td>
          <td>...</td>
          <td>40.373320</td>
          <td>40.583330</td>
          <td>22.514410</td>
          <td>503.643890</td>
          <td>2066.000000</td>
          <td>0.690840</td>
          <td>0.526665</td>
          <td>0.038840</td>
          <td>0.013460</td>
          <td>0.095205</td>
        </tr>
        <tr>
          <td>75%</td>
          <td>275818.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>109.000000</td>
          <td>42.000000</td>
          <td>77093.000000</td>
          <td>801.000000</td>
          <td>41.380606</td>
          <td>-79.782503</td>
          <td>3.359820e+07</td>
          <td>...</td>
          <td>43.567120</td>
          <td>45.416670</td>
          <td>23.575260</td>
          <td>680.275055</td>
          <td>2772.000000</td>
          <td>0.817460</td>
          <td>0.605760</td>
          <td>0.065100</td>
          <td>0.027487</td>
          <td>0.129000</td>
        </tr>
        <tr>
          <td>max</td>
          <td>294334.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>840.000000</td>
          <td>72.000000</td>
          <td>99925.000000</td>
          <td>989.000000</td>
          <td>67.074018</td>
          <td>-65.379332</td>
          <td>1.039510e+11</td>
          <td>...</td>
          <td>79.837390</td>
          <td>82.250000</td>
          <td>30.241270</td>
          <td>6197.995200</td>
          <td>27250.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.714290</td>
          <td>0.714290</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    <p>8 rows × 74 columns</p>
    </div>



.. code:: ipython3

    df_test.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>UID</th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>zip_code</th>
          <th>area_code</th>
          <th>lat</th>
          <th>lng</th>
          <th>ALand</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>count</td>
          <td>11709.000000</td>
          <td>0.0</td>
          <td>11709.0</td>
          <td>11709.000000</td>
          <td>11709.000000</td>
          <td>11709.000000</td>
          <td>11709.000000</td>
          <td>11709.000000</td>
          <td>11709.000000</td>
          <td>1.170900e+04</td>
          <td>...</td>
          <td>11613.000000</td>
          <td>11613.000000</td>
          <td>11613.000000</td>
          <td>11613.000000</td>
          <td>11613.000000</td>
          <td>11587.000000</td>
          <td>11625.000000</td>
          <td>11625.000000</td>
          <td>11625.000000</td>
          <td>11625.000000</td>
        </tr>
        <tr>
          <td>mean</td>
          <td>257525.004783</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>85.710650</td>
          <td>28.489196</td>
          <td>50123.418396</td>
          <td>593.598514</td>
          <td>37.405491</td>
          <td>-91.340229</td>
          <td>1.095500e+08</td>
          <td>...</td>
          <td>40.111999</td>
          <td>40.131864</td>
          <td>22.148145</td>
          <td>550.411243</td>
          <td>2233.003186</td>
          <td>0.634194</td>
          <td>0.505632</td>
          <td>0.047960</td>
          <td>0.019346</td>
          <td>0.099191</td>
        </tr>
        <tr>
          <td>std</td>
          <td>21466.372658</td>
          <td>NaN</td>
          <td>0.0</td>
          <td>99.304334</td>
          <td>16.607262</td>
          <td>29775.134038</td>
          <td>232.074263</td>
          <td>5.625904</td>
          <td>16.407818</td>
          <td>7.624940e+08</td>
          <td>...</td>
          <td>5.851192</td>
          <td>7.972026</td>
          <td>2.554907</td>
          <td>280.992521</td>
          <td>1072.017063</td>
          <td>0.232232</td>
          <td>0.139774</td>
          <td>0.038693</td>
          <td>0.021428</td>
          <td>0.048525</td>
        </tr>
        <tr>
          <td>min</td>
          <td>220336.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>601.000000</td>
          <td>201.000000</td>
          <td>17.965835</td>
          <td>-166.770979</td>
          <td>8.299000e+03</td>
          <td>...</td>
          <td>15.360240</td>
          <td>12.833330</td>
          <td>0.737110</td>
          <td>0.251910</td>
          <td>3.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <td>25%</td>
          <td>238819.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>29.000000</td>
          <td>13.000000</td>
          <td>25570.000000</td>
          <td>404.000000</td>
          <td>33.919813</td>
          <td>-97.816561</td>
          <td>1.718660e+06</td>
          <td>...</td>
          <td>36.729210</td>
          <td>34.750000</td>
          <td>21.270920</td>
          <td>363.225840</td>
          <td>1499.000000</td>
          <td>0.492500</td>
          <td>0.422020</td>
          <td>0.020890</td>
          <td>0.004500</td>
          <td>0.064590</td>
        </tr>
        <tr>
          <td>50%</td>
          <td>257651.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>61.000000</td>
          <td>28.000000</td>
          <td>47362.000000</td>
          <td>612.000000</td>
          <td>38.618092</td>
          <td>-86.643344</td>
          <td>4.835000e+06</td>
          <td>...</td>
          <td>40.196960</td>
          <td>40.333330</td>
          <td>22.472990</td>
          <td>509.103610</td>
          <td>2099.000000</td>
          <td>0.687640</td>
          <td>0.525270</td>
          <td>0.038680</td>
          <td>0.013870</td>
          <td>0.094350</td>
        </tr>
        <tr>
          <td>75%</td>
          <td>276300.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>109.000000</td>
          <td>42.000000</td>
          <td>77406.000000</td>
          <td>787.000000</td>
          <td>41.232973</td>
          <td>-79.697311</td>
          <td>3.204540e+07</td>
          <td>...</td>
          <td>43.496490</td>
          <td>45.333330</td>
          <td>23.549450</td>
          <td>685.883910</td>
          <td>2800.000000</td>
          <td>0.815235</td>
          <td>0.605660</td>
          <td>0.065340</td>
          <td>0.027910</td>
          <td>0.128400</td>
        </tr>
        <tr>
          <td>max</td>
          <td>294333.000000</td>
          <td>NaN</td>
          <td>140.0</td>
          <td>810.000000</td>
          <td>72.000000</td>
          <td>99929.000000</td>
          <td>989.000000</td>
          <td>64.804269</td>
          <td>-65.695344</td>
          <td>5.520166e+10</td>
          <td>...</td>
          <td>90.107940</td>
          <td>90.166670</td>
          <td>29.626680</td>
          <td>4145.557870</td>
          <td>15466.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.714290</td>
          <td>0.714290</td>
          <td>0.362750</td>
        </tr>
      </tbody>
    </table>
    <p>8 rows × 74 columns</p>
    </div>



.. code:: ipython3

    df_train.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 27321 entries, 0 to 27320
    Data columns (total 80 columns):
    UID                            27321 non-null int64
    BLOCKID                        0 non-null float64
    SUMLEVEL                       27321 non-null int64
    COUNTYID                       27321 non-null int64
    STATEID                        27321 non-null int64
    state                          27321 non-null object
    state_ab                       27321 non-null object
    city                           27321 non-null object
    place                          27321 non-null object
    type                           27321 non-null object
    primary                        27321 non-null object
    zip_code                       27321 non-null int64
    area_code                      27321 non-null int64
    lat                            27321 non-null float64
    lng                            27321 non-null float64
    ALand                          27321 non-null float64
    AWater                         27321 non-null int64
    pop                            27321 non-null int64
    male_pop                       27321 non-null int64
    female_pop                     27321 non-null int64
    rent_mean                      27007 non-null float64
    rent_median                    27007 non-null float64
    rent_stdev                     27007 non-null float64
    rent_sample_weight             27007 non-null float64
    rent_samples                   27007 non-null float64
    rent_gt_10                     27007 non-null float64
    rent_gt_15                     27007 non-null float64
    rent_gt_20                     27007 non-null float64
    rent_gt_25                     27007 non-null float64
    rent_gt_30                     27007 non-null float64
    rent_gt_35                     27007 non-null float64
    rent_gt_40                     27007 non-null float64
    rent_gt_50                     27007 non-null float64
    universe_samples               27321 non-null int64
    used_samples                   27321 non-null int64
    hi_mean                        27053 non-null float64
    hi_median                      27053 non-null float64
    hi_stdev                       27053 non-null float64
    hi_sample_weight               27053 non-null float64
    hi_samples                     27053 non-null float64
    family_mean                    27023 non-null float64
    family_median                  27023 non-null float64
    family_stdev                   27023 non-null float64
    family_sample_weight           27023 non-null float64
    family_samples                 27023 non-null float64
    hc_mortgage_mean               26748 non-null float64
    hc_mortgage_median             26748 non-null float64
    hc_mortgage_stdev              26748 non-null float64
    hc_mortgage_sample_weight      26748 non-null float64
    hc_mortgage_samples            26748 non-null float64
    hc_mean                        26721 non-null float64
    hc_median                      26721 non-null float64
    hc_stdev                       26721 non-null float64
    hc_samples                     26721 non-null float64
    hc_sample_weight               26721 non-null float64
    home_equity_second_mortgage    26864 non-null float64
    second_mortgage                26864 non-null float64
    home_equity                    26864 non-null float64
    debt                           26864 non-null float64
    second_mortgage_cdf            26864 non-null float64
    home_equity_cdf                26864 non-null float64
    debt_cdf                       26864 non-null float64
    hs_degree                      27131 non-null float64
    hs_degree_male                 27121 non-null float64
    hs_degree_female               27098 non-null float64
    male_age_mean                  27132 non-null float64
    male_age_median                27132 non-null float64
    male_age_stdev                 27132 non-null float64
    male_age_sample_weight         27132 non-null float64
    male_age_samples               27132 non-null float64
    female_age_mean                27115 non-null float64
    female_age_median              27115 non-null float64
    female_age_stdev               27115 non-null float64
    female_age_sample_weight       27115 non-null float64
    female_age_samples             27115 non-null float64
    pct_own                        27053 non-null float64
    married                        27130 non-null float64
    married_snp                    27130 non-null float64
    separated                      27130 non-null float64
    divorced                       27130 non-null float64
    dtypes: float64(62), int64(12), object(6)
    memory usage: 16.7+ MB


.. code:: ipython3

    df_test.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 11709 entries, 0 to 11708
    Data columns (total 80 columns):
    UID                            11709 non-null int64
    BLOCKID                        0 non-null float64
    SUMLEVEL                       11709 non-null int64
    COUNTYID                       11709 non-null int64
    STATEID                        11709 non-null int64
    state                          11709 non-null object
    state_ab                       11709 non-null object
    city                           11709 non-null object
    place                          11709 non-null object
    type                           11709 non-null object
    primary                        11709 non-null object
    zip_code                       11709 non-null int64
    area_code                      11709 non-null int64
    lat                            11709 non-null float64
    lng                            11709 non-null float64
    ALand                          11709 non-null int64
    AWater                         11709 non-null int64
    pop                            11709 non-null int64
    male_pop                       11709 non-null int64
    female_pop                     11709 non-null int64
    rent_mean                      11561 non-null float64
    rent_median                    11561 non-null float64
    rent_stdev                     11561 non-null float64
    rent_sample_weight             11561 non-null float64
    rent_samples                   11561 non-null float64
    rent_gt_10                     11560 non-null float64
    rent_gt_15                     11560 non-null float64
    rent_gt_20                     11560 non-null float64
    rent_gt_25                     11560 non-null float64
    rent_gt_30                     11560 non-null float64
    rent_gt_35                     11560 non-null float64
    rent_gt_40                     11560 non-null float64
    rent_gt_50                     11560 non-null float64
    universe_samples               11709 non-null int64
    used_samples                   11709 non-null int64
    hi_mean                        11587 non-null float64
    hi_median                      11587 non-null float64
    hi_stdev                       11587 non-null float64
    hi_sample_weight               11587 non-null float64
    hi_samples                     11587 non-null float64
    family_mean                    11573 non-null float64
    family_median                  11573 non-null float64
    family_stdev                   11573 non-null float64
    family_sample_weight           11573 non-null float64
    family_samples                 11573 non-null float64
    hc_mortgage_mean               11441 non-null float64
    hc_mortgage_median             11441 non-null float64
    hc_mortgage_stdev              11441 non-null float64
    hc_mortgage_sample_weight      11441 non-null float64
    hc_mortgage_samples            11441 non-null float64
    hc_mean                        11419 non-null float64
    hc_median                      11419 non-null float64
    hc_stdev                       11419 non-null float64
    hc_samples                     11419 non-null float64
    hc_sample_weight               11419 non-null float64
    home_equity_second_mortgage    11489 non-null float64
    second_mortgage                11489 non-null float64
    home_equity                    11489 non-null float64
    debt                           11489 non-null float64
    second_mortgage_cdf            11489 non-null float64
    home_equity_cdf                11489 non-null float64
    debt_cdf                       11489 non-null float64
    hs_degree                      11624 non-null float64
    hs_degree_male                 11620 non-null float64
    hs_degree_female               11604 non-null float64
    male_age_mean                  11625 non-null float64
    male_age_median                11625 non-null float64
    male_age_stdev                 11625 non-null float64
    male_age_sample_weight         11625 non-null float64
    male_age_samples               11625 non-null float64
    female_age_mean                11613 non-null float64
    female_age_median              11613 non-null float64
    female_age_stdev               11613 non-null float64
    female_age_sample_weight       11613 non-null float64
    female_age_samples             11613 non-null float64
    pct_own                        11587 non-null float64
    married                        11625 non-null float64
    married_snp                    11625 non-null float64
    separated                      11625 non-null float64
    divorced                       11625 non-null float64
    dtypes: float64(61), int64(13), object(6)
    memory usage: 7.1+ MB


.. code:: ipython3

    #UID is unique userID value in the train and test dataset. So an index can be created from the UID feature
    df_train.set_index(keys=['UID'],inplace=True)#Set the DataFrame index using existing columns.
    df_test.set_index(keys=['UID'],inplace=True)

.. code:: ipython3

    df_train.head(2)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>state</th>
          <th>state_ab</th>
          <th>city</th>
          <th>place</th>
          <th>type</th>
          <th>primary</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>267822</td>
          <td>NaN</td>
          <td>140</td>
          <td>53</td>
          <td>36</td>
          <td>New York</td>
          <td>NY</td>
          <td>Hamilton</td>
          <td>Hamilton</td>
          <td>City</td>
          <td>tract</td>
          <td>...</td>
          <td>44.48629</td>
          <td>45.33333</td>
          <td>22.51276</td>
          <td>685.33845</td>
          <td>2618.0</td>
          <td>0.79046</td>
          <td>0.57851</td>
          <td>0.01882</td>
          <td>0.01240</td>
          <td>0.0877</td>
        </tr>
        <tr>
          <td>246444</td>
          <td>NaN</td>
          <td>140</td>
          <td>141</td>
          <td>18</td>
          <td>Indiana</td>
          <td>IN</td>
          <td>South Bend</td>
          <td>Roseland</td>
          <td>City</td>
          <td>tract</td>
          <td>...</td>
          <td>36.48391</td>
          <td>37.58333</td>
          <td>23.43353</td>
          <td>267.23367</td>
          <td>1284.0</td>
          <td>0.52483</td>
          <td>0.34886</td>
          <td>0.01426</td>
          <td>0.01426</td>
          <td>0.0903</td>
        </tr>
      </tbody>
    </table>
    <p>2 rows × 79 columns</p>
    </div>



.. code:: ipython3

    df_test.head(2)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BLOCKID</th>
          <th>SUMLEVEL</th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>state</th>
          <th>state_ab</th>
          <th>city</th>
          <th>place</th>
          <th>type</th>
          <th>primary</th>
          <th>...</th>
          <th>female_age_mean</th>
          <th>female_age_median</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>255504</td>
          <td>NaN</td>
          <td>140</td>
          <td>163</td>
          <td>26</td>
          <td>Michigan</td>
          <td>MI</td>
          <td>Detroit</td>
          <td>Dearborn Heights City</td>
          <td>CDP</td>
          <td>tract</td>
          <td>...</td>
          <td>34.78682</td>
          <td>33.75000</td>
          <td>21.58531</td>
          <td>416.48097</td>
          <td>1938.0</td>
          <td>0.70252</td>
          <td>0.28217</td>
          <td>0.05910</td>
          <td>0.03813</td>
          <td>0.14299</td>
        </tr>
        <tr>
          <td>252676</td>
          <td>NaN</td>
          <td>140</td>
          <td>1</td>
          <td>23</td>
          <td>Maine</td>
          <td>ME</td>
          <td>Auburn</td>
          <td>Auburn City</td>
          <td>City</td>
          <td>tract</td>
          <td>...</td>
          <td>44.23451</td>
          <td>46.66667</td>
          <td>22.37036</td>
          <td>532.03505</td>
          <td>1950.0</td>
          <td>0.85128</td>
          <td>0.64221</td>
          <td>0.02338</td>
          <td>0.00000</td>
          <td>0.13377</td>
        </tr>
      </tbody>
    </table>
    <p>2 rows × 79 columns</p>
    </div>



.. code:: ipython3

    #percantage of missing values in train set
    missing_list_train=df_train.isnull().sum() *100/len(df_train)
    missing_values_df_train=pd.DataFrame(missing_list_train,columns=['Percantage of missing values'])
    missing_values_df_train.sort_values(by=['Percantage of missing values'],inplace=True,ascending=False)
    missing_values_df_train[missing_values_df_train['Percantage of missing values'] >0][:10]
    #BLOCKID can be dropped, since it is 100%missing values




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Percantage of missing values</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>BLOCKID</td>
          <td>100.000000</td>
        </tr>
        <tr>
          <td>hc_samples</td>
          <td>2.196113</td>
        </tr>
        <tr>
          <td>hc_mean</td>
          <td>2.196113</td>
        </tr>
        <tr>
          <td>hc_median</td>
          <td>2.196113</td>
        </tr>
        <tr>
          <td>hc_stdev</td>
          <td>2.196113</td>
        </tr>
        <tr>
          <td>hc_sample_weight</td>
          <td>2.196113</td>
        </tr>
        <tr>
          <td>hc_mortgage_mean</td>
          <td>2.097288</td>
        </tr>
        <tr>
          <td>hc_mortgage_stdev</td>
          <td>2.097288</td>
        </tr>
        <tr>
          <td>hc_mortgage_sample_weight</td>
          <td>2.097288</td>
        </tr>
        <tr>
          <td>hc_mortgage_samples</td>
          <td>2.097288</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #percantage of missing values in test set
    missing_list_test=df_test.isnull().sum() *100/len(df_train)
    missing_values_df_test=pd.DataFrame(missing_list_test,columns=['Percantage of missing values'])
    missing_values_df_test.sort_values(by=['Percantage of missing values'],inplace=True,ascending=False)
    missing_values_df_test[missing_values_df_test['Percantage of missing values'] >0][:10]
    #BLOCKID can be dropped, since it is 43%missing values




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Percantage of missing values</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>BLOCKID</td>
          <td>42.857143</td>
        </tr>
        <tr>
          <td>hc_samples</td>
          <td>1.061455</td>
        </tr>
        <tr>
          <td>hc_mean</td>
          <td>1.061455</td>
        </tr>
        <tr>
          <td>hc_median</td>
          <td>1.061455</td>
        </tr>
        <tr>
          <td>hc_stdev</td>
          <td>1.061455</td>
        </tr>
        <tr>
          <td>hc_sample_weight</td>
          <td>1.061455</td>
        </tr>
        <tr>
          <td>hc_mortgage_mean</td>
          <td>0.980930</td>
        </tr>
        <tr>
          <td>hc_mortgage_stdev</td>
          <td>0.980930</td>
        </tr>
        <tr>
          <td>hc_mortgage_sample_weight</td>
          <td>0.980930</td>
        </tr>
        <tr>
          <td>hc_mortgage_samples</td>
          <td>0.980930</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df_train .drop(columns=['BLOCKID','SUMLEVEL'],inplace=True) #SUMLEVEL doest not have any predictive power and no variance

.. code:: ipython3

    df_test .drop(columns=['BLOCKID','SUMLEVEL'],inplace=True) #SUMLEVEL doest not have any predictive power

.. code:: ipython3

    # Imputing  missing values with mean
    missing_train_cols=[]
    for col in df_train.columns:
        if df_train[col].isna().sum() !=0:
             missing_train_cols.append(col)
    print(missing_train_cols)


.. parsed-literal::

    ['rent_mean', 'rent_median', 'rent_stdev', 'rent_sample_weight', 'rent_samples', 'rent_gt_10', 'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35', 'rent_gt_40', 'rent_gt_50', 'hi_mean', 'hi_median', 'hi_stdev', 'hi_sample_weight', 'hi_samples', 'family_mean', 'family_median', 'family_stdev', 'family_sample_weight', 'family_samples', 'hc_mortgage_mean', 'hc_mortgage_median', 'hc_mortgage_stdev', 'hc_mortgage_sample_weight', 'hc_mortgage_samples', 'hc_mean', 'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight', 'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt', 'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree', 'hs_degree_male', 'hs_degree_female', 'male_age_mean', 'male_age_median', 'male_age_stdev', 'male_age_sample_weight', 'male_age_samples', 'female_age_mean', 'female_age_median', 'female_age_stdev', 'female_age_sample_weight', 'female_age_samples', 'pct_own', 'married', 'married_snp', 'separated', 'divorced']


.. code:: ipython3

    # Imputing  missing values with mean
    missing_test_cols=[]
    for col in df_test.columns:
        if df_test[col].isna().sum() !=0:
             missing_test_cols.append(col)
    print(missing_test_cols)


.. parsed-literal::

    ['rent_mean', 'rent_median', 'rent_stdev', 'rent_sample_weight', 'rent_samples', 'rent_gt_10', 'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35', 'rent_gt_40', 'rent_gt_50', 'hi_mean', 'hi_median', 'hi_stdev', 'hi_sample_weight', 'hi_samples', 'family_mean', 'family_median', 'family_stdev', 'family_sample_weight', 'family_samples', 'hc_mortgage_mean', 'hc_mortgage_median', 'hc_mortgage_stdev', 'hc_mortgage_sample_weight', 'hc_mortgage_samples', 'hc_mean', 'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight', 'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt', 'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree', 'hs_degree_male', 'hs_degree_female', 'male_age_mean', 'male_age_median', 'male_age_stdev', 'male_age_sample_weight', 'male_age_samples', 'female_age_mean', 'female_age_median', 'female_age_stdev', 'female_age_sample_weight', 'female_age_samples', 'pct_own', 'married', 'married_snp', 'separated', 'divorced']


.. code:: ipython3

      # Missing cols are all numerical variables
    for col in df_train.columns:
        if col in (missing_train_cols):
            df_train[col].replace(np.nan, df_train[col].mean(),inplace=True)

.. code:: ipython3

    # Missing cols are all numerical variables
    for col in df_test.columns:
        if col in (missing_test_cols):
            df_test[col].replace(np.nan, df_test[col].mean(),inplace=True)

.. code:: ipython3

    df_train.isna().sum().sum()




.. parsed-literal::

    0



.. code:: ipython3

    df_test.isna().sum().sum()




.. parsed-literal::

    0



Explore the top 2,500 locations where the percentage of households with
a second mortgage is the highest and percent ownership is above 10
percent. Visualize using geo-map. You may keep the upper limit for the
percent of households with a second mortgage to 50 percent

.. code:: ipython3

    from pandasql import sqldf
    q1 = "select place,pct_own,second_mortgage,lat,lng from df_train where pct_own >0.10 and second_mortgage <0.5 order by second_mortgage DESC LIMIT 2500;"
    pysqldf = lambda q: sqldf(q, globals())
    df_train_location_mort_pct=pysqldf(q1)


.. code:: ipython3

    df_train_location_mort_pct.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>place</th>
          <th>pct_own</th>
          <th>second_mortgage</th>
          <th>lat</th>
          <th>lng</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>0</td>
          <td>Worcester City</td>
          <td>0.20247</td>
          <td>0.43363</td>
          <td>42.254262</td>
          <td>-71.800347</td>
        </tr>
        <tr>
          <td>1</td>
          <td>Harbor Hills</td>
          <td>0.15618</td>
          <td>0.31818</td>
          <td>40.751809</td>
          <td>-73.853582</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Glen Burnie</td>
          <td>0.22380</td>
          <td>0.30212</td>
          <td>39.127273</td>
          <td>-76.635265</td>
        </tr>
        <tr>
          <td>3</td>
          <td>Egypt Lake-leto</td>
          <td>0.11618</td>
          <td>0.28972</td>
          <td>28.029063</td>
          <td>-82.495395</td>
        </tr>
        <tr>
          <td>4</td>
          <td>Lincolnwood</td>
          <td>0.14228</td>
          <td>0.28899</td>
          <td>41.967289</td>
          <td>-87.652434</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    import plotly.express as px
    import plotly.graph_objects as go

.. code:: ipython3

    
    fig = go.Figure(data=go.Scattergeo(
        lat = df_train_location_mort_pct['lat'],
        lon = df_train_location_mort_pct['lng']),
        )
    fig.update_layout(
        geo=dict(
            scope = 'north america',
            showland = True,
            landcolor = "rgb(212, 212, 212)",
            subunitcolor = "rgb(255, 255, 255)",
            countrycolor = "rgb(255, 255, 255)",
            showlakes = True,
            lakecolor = "rgb(255, 255, 255)",
            showsubunits = True,
            showcountries = True,
            resolution = 50,
            projection = dict(
                type = 'conic conformal',
                rotation_lon = -100
            ),
            lonaxis = dict(
                showgrid = True,
                gridwidth = 0.5,
                range= [ -140.0, -55.0 ],
                dtick = 5
            ),
            lataxis = dict (
                showgrid = True,
                gridwidth = 0.5,
                range= [ 20.0, 60.0 ],
                dtick = 5
            )
        ),
        title='Top 2,500 locations with second mortgage is the highest and percent ownership is above 10 percent')
    fig.show()




.. raw:: html

    <div>
    
    
                <div id="23b74194-1832-4765-b19c-724b5da80806" class="plotly-graph-div" style="height:525px; width:100%;"></div>
                <script type="text/javascript">
                    require(["plotly"], function(Plotly) {
                        window.PLOTLYENV=window.PLOTLYENV || {};
    
                    if (document.getElementById("23b74194-1832-4765-b19c-724b5da80806")) {
                        Plotly.newPlot(
                            '23b74194-1832-4765-b19c-724b5da80806',
                            [{"lat": [42.254261799999995, 40.7518089, 39.12727279999999, 28.029063300000004, 41.9672885, 41.9066403, 42.71420820000001, 43.067063299999994, 34.0931841, 37.656228999999996, 39.121315700000004, 32.8003476, 38.819171399999995, 39.5094376, 38.2947649, 41.5270157, 42.39712720000001, 38.2470347, 38.8499425, 41.7677281, 41.783468, 34.1039593, 45.4454048, 33.9555895, 28.533263199999997, 33.724903600000005, 35.128587599999996, 32.2955885, 47.2401479, 43.9728571, 38.971338, 34.363620000000004, 33.5651234, 39.6599172, 28.023056300000004, 26.0073086, 39.7756533, 40.9199667, 39.859951, 41.7454851, 40.6943396, 37.832642299999996, 38.8328939, 41.723515500000005, 35.092118299999996, 33.8796686, 39.37924829999999, 33.989555700000004, 40.8377899, 40.8377899, 35.9901296, 32.6599903, 40.6406399, 39.1524277, 38.6614448, 33.924708100000004, 42.72897570000001, 39.9527732, 37.356210499999996, 36.16242929999999, 28.520498800000002, 38.5916036, 40.066865299999996, 47.6199882, 33.7088571, 34.0432749, 40.7821699, 45.6548641, 39.135554299999995, 34.253678799999996, 34.1494929, 41.1131233, 38.8879464, 38.7222559, 36.318979600000006, 40.5942315, 38.832772, 37.804675399999994, 38.6037792, 40.385902, 37.050310499999995, 34.2804584, 40.1233788, 45.5188106, 40.8897429, 41.6639299, 41.705247799999995, 41.741561499999996, 45.527539000000004, 42.7224295, 41.7902101, 37.7741755, 35.998208899999995, 45.4992015, 34.012268799999994, 40.7955828, 41.7617135, 38.846390299999996, 39.6754541, 41.8085114, 41.259119500000004, 41.835608, 39.1886045, 33.1732234, 45.13485479999999, 41.7944972, 33.7789729, 37.7344919, 33.7452198, 45.0360622, 38.7240552, 39.0901783, 37.2980229, 32.7840087, 33.801900399999994, 30.3465716, 40.4253305, 33.9546932, 41.987226, 35.53258220000001, 43.563675, 47.2287315, 38.945693799999994, 41.1706268, 34.960759100000004, 38.86885720000001, 34.2409046, 37.7109995, 36.8444256, 39.3785915, 39.9174144, 35.281548, 36.0446391, 34.09790770000001, 38.1295441, 33.7247482, 25.864262600000004, 33.3305333, 38.5419331, 38.2665083, 33.075514500000004, 44.9767007, 34.2247342, 34.264058899999995, 40.4427091, 32.7898054, 41.621989299999996, 33.5876988, 41.54496339999999, 40.679176399999996, 42.0227059, 35.7849873, 42.0298213, 42.682308899999995, 33.7538839, 40.8384785, 38.0127453, 33.7069847, 32.476876399999995, 34.0685435, 40.7556398, 39.0087272, 36.78732670000001, 25.606451999999997, 40.6701918, 40.472764399999996, 33.6278555, 47.8581251, 36.2541516, 38.8313107, 47.399399, 40.7842611, 33.65181629999999, 33.7548958, 34.8631405, 33.1732652, 33.8647762, 27.9118994, 37.920601700000006, 45.5454185, 33.771918, 39.0666053, 39.0912204, 35.9949426, 38.8396609, 40.0416936, 36.8973185, 29.935141700000003, 30.1702766, 39.537403399999995, 34.2046283, 40.29974970000001, 38.910779, 32.6533559, 36.1633112, 25.8879442, 45.485166299999996, 44.783401500000004, 40.284994700000006, 34.268934, 30.422857899999997, 42.3171635, 38.9002, 39.738202799999996, 38.9479653, 41.86292460000001, 39.1318665, 33.1276339, 39.898677899999996, 33.298662199999995, 40.6893276, 34.091697499999995, 38.752774200000005, 26.0038057, 35.3029184, 41.3271237, 28.099432500000002, 40.77283189999999, 42.3840376, 40.6637279, 41.468532399999994, 37.6970765, 39.543137, 29.727267600000005, 41.813806, 40.6816514, 40.602487100000005, 45.0095917, 40.7866906, 39.700231, 41.9350552, 33.9001056, 41.9015665, 37.650262, 39.4024657, 37.463311700000006, 47.1971869, 33.6779027, 33.905117, 25.782484399999998, 38.8610018, 41.8103984, 39.4112636, 39.648829, 45.204478, 35.32110170000001, 37.3702336, 30.167655, 34.2026924, 38.8260946, 38.802405, 32.666331400000004, 41.971339, 40.6825052, 39.884858200000004, 33.605332700000005, 44.9951749, 46.617046, 33.5863884, 34.1009548, 38.2490976, 44.8654852, 34.224257, 42.4948823, 39.8781135, 35.0613382, 39.8072621, 41.8008741, 39.9394959, 38.734462799999996, 40.7437159, 38.8494179, 40.6272716, 45.54030039999999, 43.0602744, 36.5088616, 33.3837635, 33.6980366, 34.9324506, 47.1057867, 38.0473283, 34.1466652, 40.76500720000001, 39.6282932, 43.0951653, 32.867998, 43.11568629999999, 33.974582500000004, 34.0155355, 34.0456314, 40.1083208, 34.0571243, 33.9747696, 38.876859700000004, 42.2774512, 32.8129785, 41.0810691, 40.0076218, 39.1753881, 39.5503765, 40.7322124, 40.123019799999994, 33.9420596, 41.8930097, 36.8200899, 38.725077500000005, 41.6714456, 42.003403000000006, 39.4891874, 34.098786, 38.026408399999994, 35.386741, 29.8962526, 44.853398799999994, 35.6464434, 33.7205506, 38.803149499999996, 31.584741499999996, 41.4496925, 38.4357606, 35.246080600000006, 38.807731, 39.5192622, 41.7064973, 39.9887598, 39.908725200000006, 41.8750221, 34.2135692, 34.0549939, 42.36895139999999, 43.12617589999999, 39.920151000000004, 33.840615299999996, 41.9753473, 39.0957168, 34.997146799999996, 34.1305047, 43.1668136, 38.770080799999995, 40.3496789, 41.6948175, 38.8740235, 39.681591100000006, 39.7466315, 29.932534399999998, 34.0848049, 29.9230297, 42.4375474, 34.038230799999994, 44.9709006, 40.7597713, 46.887285, 34.1490512, 41.6122427, 41.7985268, 32.639755900000004, 33.3558253, 41.1916789, 40.462813, 41.516092799999996, 33.9933787, 36.80919779999999, 40.691500899999994, 38.237768599999995, 26.721964500000002, 39.2364659, 40.9058091, 39.0964218, 33.4884762, 41.0991396, 41.783281099999996, 37.8020757, 39.6993931, 36.7882746, 34.1510732, 39.9666126, 41.7268625, 42.1687441, 30.2119403, 40.088299600000006, 30.2027914, 40.7892525, 33.934531899999996, 38.333362, 37.1575735, 33.4980444, 33.608917, 39.6280414, 41.797968700000006, 38.904157899999994, 40.7327308, 41.817445500000005, 33.4496873, 47.0718234, 41.2178042, 40.4914328, 39.935260799999995, 30.164388899999995, 34.110405799999995, 42.537108200000006, 40.7595706, 34.04902070000001, 39.6491238, 42.2914125, 36.8116152, 40.3450536, 40.19591, 33.063899, 41.910313099999996, 34.1176605, 30.1745516, 42.0783429, 37.4123848, 28.934135499999996, 44.0411086, 41.525506799999995, 40.6616591, 42.65019229999999, 45.4973096, 41.47394620000001, 42.4400021, 38.84267, 33.1075966, 33.9851297, 47.5141844, 40.6477544, 30.4171849, 40.4689825, 34.2948569, 25.843268899999998, 41.6401036, 37.8179738, 33.719217, 26.2149825, 36.7793349, 45.4847811, 30.4250462, 42.6305381, 33.716576700000005, 42.426959000000004, 33.956349100000004, 37.8972299, 32.845315299999996, 38.4684534, 34.1192092, 40.6056315, 42.9950523, 34.1616765, 30.776699199999996, 38.620883299999996, 42.261759999999995, 33.4896483, 39.370059499999996, 34.1351285, 38.925875299999994, 25.781363600000002, 39.2777485, 33.481257, 30.6919512, 33.9388223, 39.7206692, 47.2455764, 34.267038799999995, 41.8141492, 40.6530866, 42.2309589, 40.1958838, 33.7805453, 34.214735, 38.8327451, 34.147179799999996, 64.8512872, 43.0692654, 41.56723970000001, 35.1789593, 41.0534461, 38.2689461, 33.9490727, 39.6023092, 33.149489100000004, 38.8238977, 33.559948999999996, 38.5665602, 41.6997625, 37.9613437, 39.6441184, 39.8188236, 41.681561200000004, 28.8082536, 43.1010409, 32.9525906, 39.1334567, 34.227138399999994, 35.174072100000004, 39.024978000000004, 39.6608049, 33.8381856, 34.042074, 39.6792879, 42.6376032, 32.8998834, 28.480137300000003, 39.9059339, 43.597812100000006, 32.963961, 34.197228, 37.790944700000004, 38.295072600000005, 36.8048512, 35.29821679999999, 37.476588799999995, 44.772053, 38.9418287, 37.2976945, 38.6132902, 40.6628135, 38.8553718, 40.507313700000005, 40.7477294, 34.1277465, 41.7112651, 38.863583500000004, 37.7681553, 38.857490500000004, 34.27272120000001, 39.52684779999999, 36.152119, 34.151167, 38.228668400000004, 35.9859917, 41.6939604, 45.5256566, 33.9502684, 34.5024489, 33.788130200000005, 38.7912314, 39.689480700000004, 37.2293402, 42.6151903, 34.027317, 39.4899314, 38.9518921, 38.9397715, 33.1458708, 39.51910720000001, 40.4724273, 39.5040809, 38.58133839999999, 32.3480787, 38.6691098, 41.8003813, 41.396867799999995, 47.6476102, 38.954272100000004, 38.650686900000004, 34.0730055, 39.1873565, 37.0978813, 33.9274077, 32.660227500000005, 40.4429651, 41.7550528, 41.92083289999999, 41.5530919, 40.685321200000004, 25.8535299, 39.780635100000005, 29.8017669, 43.0707915, 34.1873507, 33.6616059, 39.978601399999995, 32.9342794, 33.662021, 42.3353908, 33.3567902, 41.8049921, 32.9471739, 25.8949228, 34.1124237, 42.627500500000004, 44.955008, 32.7392472, 39.143499799999994, 33.8282532, 41.5158696, 28.894274, 33.8165383, 32.1985657, 47.4631901, 47.454403899999996, 38.8621875, 34.2481946, 33.9852598, 42.715247600000005, 41.702582, 32.8778369, 38.528581200000005, 39.2905908, 39.7610973, 34.162293700000006, 28.1030635, 25.6091202, 37.7096379, 33.774967499999995, 39.940045399999995, 41.420558, 39.3426876, 39.6622275, 36.7904775, 29.9889065, 34.61735529999999, 34.2348828, 45.6692734, 33.7249711, 38.3222432, 42.4321158, 41.212207799999995, 36.871517, 38.7571595, 42.51489, 42.62143579999999, 40.7600215, 28.052695299999996, 33.8973552, 41.817397799999995, 33.669897999999996, 38.9482799, 33.956560700000004, 26.000667, 36.0982748, 35.3359425, 41.722398, 46.9976109, 38.89222120000001, 37.7021372, 40.685634, 39.9911848, 33.7169277, 40.6287701, 41.029016999999996, 33.958299700000005, 40.6840329, 41.863416799999996, 33.719646999999995, 33.889702299999996, 40.305128499999995, 38.0930935, 34.418121299999996, 32.0717555, 39.7861611, 25.6762354, 47.408918299999996, 41.1173174, 34.4151371, 40.6684184, 33.2834644, 39.6982253, 44.665299100000006, 34.1812289, 40.4397432, 38.2204068, 39.9123676, 26.8490059, 34.0851726, 30.302228200000002, 43.7710901, 32.8294344, 37.7801283, 45.047711799999995, 33.918087899999996, 39.772991499999996, 39.691155200000004, 38.8128802, 40.8729177, 34.0080154, 20.901673300000002, 38.667389799999995, 38.2114861, 26.2262486, 44.924159499999995, 34.15221939999999, 40.9303636, 28.503141600000003, 40.7159549, 38.044548, 47.0793129, 33.9237216, 40.4207745, 33.9446554, 40.6489784, 39.134305, 37.5797282, 34.064175899999995, 43.1655774, 32.5005516, 32.4714423, 43.5536497, 38.832313899999995, 34.0395089, 38.369159499999995, 32.6237395, 36.67651370000001, 34.0185256, 37.00404520000001, 38.1104411, 41.0376661, 42.636931700000005, 39.0690044, 30.686873600000002, 33.4881646, 39.3845572, 43.9577761, 40.845602899999996, 21.3367753, 37.883750299999996, 38.979789000000004, 38.8959945, 34.1049693, 38.9454826, 41.2731308, 42.678253999999995, 38.9307514, 33.166749800000005, 38.852084399999995, 41.8040062, 40.2031811, 37.602939899999996, 39.42599860000001, 42.629669799999995, 34.140874600000004, 41.73475139999999, 33.966479, 27.978238399999995, 33.735510600000005, 32.8819793, 40.7417853, 40.6600109, 33.9419438, 33.665571899999996, 33.425336, 35.8467196, 38.8054848, 41.6616948, 40.8006768, 32.8524426, 39.817318, 40.51450870000001, 41.9123508, 28.5401108, 45.0324121, 40.779776, 39.7049882, 33.290355100000006, 32.7174916, 39.962255, 38.9665231, 47.554136299999996, 39.6494961, 43.0264331, 39.796066100000004, 35.252765999999994, 33.479534, 35.057988200000004, 41.9645567, 36.867340999999996, 39.124720399999994, 34.138221, 37.402805, 41.0582597, 41.7839867, 42.3229604, 40.7000316, 41.2413836, 42.015721, 33.3570982, 38.9254351, 40.0934711, 41.5203551, 43.021374200000004, 25.976798300000002, 38.768704799999995, 30.029978000000003, 40.6937625, 38.6838883, 39.685188399999994, 41.602202899999995, 31.9729543, 27.931383899999997, 39.4388686, 39.9604441, 39.660587899999996, 40.8779155, 38.9630071, 39.385119700000004, 39.7521405, 41.072663299999995, 21.3493646, 26.265350199999997, 39.732914799999996, 26.580283899999998, 29.826334600000003, 39.9085157, 38.8455898, 39.661811, 44.959076700000004, 26.1375315, 30.320931199999997, 39.9068546, 33.1059882, 32.9832119, 38.059096999999994, 41.7681721, 35.1907765, 34.463885100000006, 41.673958899999995, 45.0988606, 35.21007410000001, 27.915848999999998, 36.093394700000005, 35.317974799999995, 30.380419, 42.1790521, 36.075016399999996, 33.46021330000001, 38.142344200000004, 33.5207847, 33.8893924, 43.704473, 47.9189705, 34.197443299999996, 33.9726959, 32.054159000000006, 39.6862598, 41.108643, 40.7128119, 41.279379999999996, 33.504936199999996, 47.298427200000006, 47.7080925, 38.6718268, 32.4462823, 37.751201, 36.8448035, 33.6940064, 42.23753060000001, 37.3033363, 34.974844700000006, 27.929778000000002, 41.1325888, 45.5281169, 41.7336229, 38.6484879, 36.305864899999996, 41.7762401, 32.8479042, 45.03912929999999, 41.4111051, 41.445095, 40.694829299999995, 35.7909911, 33.778833500000005, 33.7808851, 32.5415573, 34.1828906, 32.8002103, 44.950155, 33.5719474, 39.61584620000001, 36.1627441, 36.107779799999996, 38.2374372, 37.2837456, 38.4564269, 34.1396027, 42.105360299999994, 40.8699762, 26.2411125, 38.4611543, 25.8224276, 39.9041936, 45.0175949, 35.7489279, 39.9253879, 34.0555602, 42.6447316, 25.9290515, 36.0925869, 40.268118799999996, 42.2051878, 43.067480200000006, 38.9536716, 30.045792, 28.0376886, 33.968801299999996, 37.90156210000001, 32.949374, 40.7841344, 33.731861, 32.318844, 34.2046643, 45.7802151, 39.7365218, 38.017687200000005, 33.9486636, 40.8625283, 41.5924476, 42.589892299999995, 33.7039886, 38.7681302, 39.5484257, 39.7414549, 45.2408953, 33.4683712, 39.0156284, 33.1965648, 42.0005258, 42.6124793, 41.420795700000006, 40.307584399999996, 34.0018666, 35.4082071, 34.0820627, 41.4729942, 44.9537451, 41.7204166, 47.889939899999995, 41.388915399999995, 40.050410799999995, 20.801889399999997, 40.825953999999996, 40.837415899999996, 34.5311782, 42.4059665, 34.75386339999999, 36.276953799999994, 36.8195888, 34.411561, 39.645911600000005, 30.7634615, 38.70234179999999, 33.898470399999994, 36.3910354, 38.2684638, 39.8287576, 40.384593100000004, 43.0729164, 42.656224200000004, 38.195673600000006, 33.976853999999996, 40.7323708, 33.088078499999995, 45.4306502, 44.9703403, 39.629594299999994, 35.341264100000004, 39.450094899999996, 28.793724800000003, 36.8105831, 34.1001324, 40.280327, 37.9608135, 30.4503149, 45.50396920000001, 42.4831809, 41.813554499999995, 34.03055620000001, 47.61037279999999, 34.2669104, 42.5539949, 32.7626153, 40.715734999999995, 40.3037989, 40.5009545, 33.741006, 37.6353602, 39.631312, 32.859104200000004, 35.3762348, 44.9168655, 35.458998799999996, 38.4143234, 36.8446787, 37.539958399999996, 38.9423488, 40.566035299999996, 43.6358472, 44.954109100000004, 42.191998299999995, 38.5828705, 33.8548908, 34.0293136, 34.0781954, 42.1957211, 29.642378000000004, 38.9710405, 35.5747618, 33.928394700000005, 40.582176399999994, 38.4632744, 42.6471705, 41.1369415, 42.222255700000005, 34.972970000000004, 38.5473451, 39.1826275, 31.9698536, 40.0903961, 26.5797055, 39.8822458, 41.8002804, 33.873524100000004, 42.6396768, 43.304165000000005, 32.7166577, 39.7500556, 41.54407570000001, 33.3129045, 32.1156901, 45.679504, 33.9974216, 33.955833899999995, 45.0755825, 38.111521, 41.2896117, 39.073679399999996, 44.849545299999996, 47.05280689999999, 40.8457874, 45.3905054, 44.1063256, 47.646822799999995, 35.2996701, 37.600362200000006, 34.2788511, 33.6344482, 43.0486527, 40.7440007, 39.658646000000005, 41.4126156, 36.4201875, 34.2654115, 45.080813899999995, 40.738473600000006, 41.6425449, 46.8714029, 38.728047499999995, 32.7840225, 44.2939911, 33.468801, 37.738859000000005, 37.2411911, 39.0908513, 36.0173789, 34.1851953, 32.7765333, 44.6527774, 44.3427157, 38.8514105, 33.852908299999996, 40.6591038, 38.8758311, 33.795374, 34.2516083, 40.7246283, 45.320499299999994, 37.46236210000001, 29.940639899999997, 33.8352186, 39.620852899999996, 39.7644805, 42.2700183, 42.3138055, 25.834111899999996, 29.9951852, 35.36422460000001, 38.923891299999994, 40.6563567, 38.9039498, 38.967226700000005, 36.19297, 45.5885856, 39.111689, 33.6920021, 38.7987325, 29.892596, 40.318405600000006, 41.7196717, 47.6581015, 33.9721225, 46.86918729999999, 33.0402437, 42.2193562, 39.20086679999999, 33.856317700000005, 41.414489700000004, 41.997296399999996, 37.3163299, 46.7141896, 40.1658533, 40.692964200000006, 39.3193302, 38.8055635, 34.7323519, 29.816115999999997, 39.6496146, 40.929716799999994, 34.1815516, 39.507186100000006, 32.9654838, 21.339523, 33.913976, 40.44749, 42.2740065, 36.14085479999999, 37.8906499, 33.024395299999995, 38.767807899999994, 21.345775600000003, 30.2583558, 38.9840391, 33.3855247, 43.5369101, 43.1546865, 36.85592379999999, 34.0198929, 33.9956333, 33.8416367, 35.21727070000001, 37.679632299999994, 40.781029, 33.8646012, 47.91401870000001, 38.774433, 34.7628785, 41.7689528, 41.996589799999995, 39.3644763, 40.63318710000001, 41.627497600000005, 37.0135619, 43.056020700000005, 45.7000322, 38.3695473, 37.468624, 33.836, 47.7670311, 42.451013700000004, 39.907118, 40.712363399999994, 32.804769199999996, 42.670339399999996, 38.848651700000005, 27.9623191, 40.719581700000006, 41.5768652, 33.931052, 39.7734461, 37.3547002, 39.365944799999994, 45.492642100000005, 27.4901903, 33.9299484, 47.6458408, 38.830786200000006, 33.897979799999995, 30.494869800000004, 34.0994645, 35.963676, 39.6922526, 41.850992600000005, 25.7758186, 45.579836799999995, 43.977587400000004, 37.5330658, 41.372518, 33.956033700000006, 42.9757238, 32.8589423, 38.942043, 33.96420620000001, 39.5670035, 42.464624799999996, 34.2967355, 33.934240100000004, 45.601075, 43.8591275, 36.007463200000004, 41.6488961, 45.0087925, 39.7020374, 40.802299700000006, 33.3281393, 41.9289576, 37.720008899999996, 41.9583016, 39.8779975, 29.8167961, 44.9986375, 41.6216991, 30.215384399999998, 38.60991729999999, 41.0977471, 35.5063506, 34.144579, 33.423136199999995, 36.230545899999996, 34.0020976, 30.416166399999998, 33.6164674, 38.2017236, 33.5847024, 40.377931700000005, 41.935702899999995, 37.7594331, 39.202993400000004, 42.512013200000005, 42.6660855, 38.8116221, 25.9339375, 25.477841199999997, 28.275122399999997, 42.0823969, 40.2143917, 40.33376129999999, 47.240288899999996, 39.316668299999996, 39.3498089, 33.9652179, 40.693467, 39.6899412, 38.21168839999999, 38.909129899999996, 38.78329960000001, 39.8320466, 47.2003278, 40.7062404, 39.1452205, 33.74674470000001, 30.0072881, 33.048549300000005, 41.2836308, 41.9772907, 37.7625436, 42.6608795, 39.0940656, 40.558465500000004, 34.08087329999999, 34.1022274, 33.7926172, 33.7420805, 38.8779453, 35.517971200000005, 36.199307700000006, 39.296656299999995, 45.0332545, 39.6589153, 34.1911391, 39.071558200000005, 28.762775899999998, 37.3291927, 45.378118, 37.3461125, 32.673810100000004, 40.276425700000004, 40.628707299999995, 38.4780464, 47.8667826, 39.0592102, 40.3090939, 40.7587307, 37.663470700000005, 42.408153600000006, 39.5589997, 39.704845, 37.96781970000001, 25.957514899999996, 33.2076108, 38.3627836, 40.897279499999996, 44.9316858, 39.6068278, 38.1358448, 44.930036, 42.6249396, 40.8254505, 39.803604299999996, 32.7921847, 44.015558500000004, 41.8637638, 45.157438, 38.972821100000004, 39.399685, 33.967321000000005, 37.512005, 39.660399, 38.650622600000005, 29.923530699999997, 38.238305100000005, 39.1324295, 41.3178106, 32.9605446, 29.968637800000003, 41.477906, 42.9546545, 41.5572292, 44.97735, 40.7300384, 48.0675269, 42.037529, 33.9822771, 41.897122700000004, 41.921125599999996, 34.1533991, 40.346991700000004, 41.449105700000004, 37.6890403, 43.0854604, 42.406567200000005, 41.2947461, 33.751667100000006, 38.266309899999996, 40.598200899999995, 41.5786789, 43.5734662, 40.1084993, 34.2820993, 42.452335600000005, 39.3570586, 42.5698864, 32.7775147, 40.170843299999994, 36.1360904, 39.6582769, 41.4381919, 47.750058700000004, 38.761088, 39.4180367, 30.418342100000004, 33.7538831, 33.194394300000006, 37.2479436, 37.654788200000006, 39.4551318, 35.84071289999999, 40.02654329999999, 39.1642175, 41.1507713, 39.5737532, 33.999674799999994, 43.0401727, 38.662649, 31.596973900000002, 43.2280723, 33.90924329999999, 30.461428899999998, 39.5596074, 30.015690399999997, 38.919225700000005, 48.1119682, 40.7922439, 29.955869399999997, 39.0955926, 41.489498499999996, 39.3264635, 33.9056717, 39.1447453, 40.4140967, 39.3681732, 41.652232500000004, 34.155088799999994, 33.756052399999994, 39.979622, 33.5021972, 40.555509, 22.0063117, 44.7094662, 37.857805400000004, 33.8400414, 42.3987581, 41.1933983, 29.515300899999996, 43.0573383, 18.3847902, 34.2078852, 36.8592846, 42.843075, 34.988692799999995, 37.7324326, 39.5879745, 34.088223799999994, 37.3252966, 37.7775293, 35.3292335, 33.1511693, 40.696530700000004, 36.239634499999994, 40.751932700000005, 32.6703515, 39.579335799999996, 34.429766, 39.0472993, 39.6749283, 34.0703739, 34.1575595, 38.592993799999995, 35.1555386, 28.7392706, 33.92747, 32.5857682, 35.249206799999996, 47.512303, 42.69614489999999, 40.561262799999994, 41.9428559, 43.0348359, 37.796538399999996, 28.3126989, 45.492498499999996, 35.774008, 39.4002015, 38.6856089, 41.855247999999996, 44.9572638, 34.12942279999999, 37.6930984, 27.919084, 33.007083, 28.0912857, 45.196358399999994, 40.0046374, 38.929507, 45.162133700000005, 47.5771253, 38.388491200000004, 40.634262400000004, 40.6152294, 33.780868, 43.1333836, 38.0177451, 38.2250432, 32.9222447, 40.6940352, 45.4126599, 36.3080545, 38.608098, 33.988274600000004, 43.1568106, 25.9975358, 41.506827799999996, 35.3453468, 41.9484736, 41.6881398, 34.0124649, 40.745375200000005, 39.5034615, 40.6567999, 40.4847665, 26.6719999, 42.3560005, 38.6123227, 34.178458500000005, 33.2241243, 28.023237199999997, 40.2326201, 34.273149700000005, 37.8232995, 44.85210120000001, 28.601942699999995, 33.9794836, 33.758197100000004, 32.8665485, 41.979912299999995, 33.639712, 32.5458122, 36.859209299999996, 34.5476596, 33.1729111, 34.087543, 41.209652399999996, 34.140753100000005, 35.3472716, 45.5348468, 38.3749473, 37.3583268, 47.3135579, 34.1140671, 40.745089, 32.3685556, 37.845475799999996, 37.623634499999994, 33.8732438, 38.53586370000001, 35.0535023, 38.6380828, 33.9278048, 38.862800799999995, 42.988482299999994, 43.1309011, 40.5927893, 40.4558327, 40.863007, 36.844676799999995, 34.5504277, 40.306729499999996, 33.6017334, 44.0911076, 35.0869473, 40.91881179999999, 61.17388149999999, 41.1311633, 42.402223, 38.9739365, 40.8620016, 39.8676016, 45.129299700000004, 38.8806878, 34.076465899999995, 42.7640506, 34.266609, 42.4841094, 41.9627836, 39.940752200000006, 41.330762299999996, 28.0484773, 41.6266977, 40.774882899999994, 44.7964495, 38.313447499999995, 39.9255728, 39.7645863, 44.7823157, 25.9762354, 39.8116877, 37.5204883, 41.985801, 41.635570200000004, 34.015445, 40.6237135, 38.9383001, 33.6773576, 40.649931099999996, 32.7232203, 39.631488899999994, 41.431542799999995, 33.4042445, 33.97590770000001, 37.615230100000005, 32.73925, 39.6814221, 39.7796722, 41.764573399999996, 35.951895, 33.6850994, 41.4266158, 45.384417299999996, 34.2269621, 38.0626471, 38.4891674, 35.0927391, 41.8281516, 33.9804922, 30.1776027, 34.067040399999996, 41.467071600000004, 40.0895349, 40.6257185, 45.9817175, 39.364663, 32.8877124, 39.8315456, 32.8731554, 38.342413, 33.9247336, 45.1838261, 39.5774982, 44.7886836, 43.0037371, 33.934821, 41.8741811, 38.26863779999999, 33.6708235, 28.6782516, 34.066765000000004, 40.2180442, 27.322460600000003, 38.6201595, 45.163527, 34.073834399999996, 33.1115032, 38.727762799999994, 47.7387511, 36.1852245, 39.621465, 33.5490164, 34.4222771, 42.3834701, 38.4372393, 38.3008039, 40.044106299999996, 42.256117100000004, 37.588085299999996, 36.086126799999995, 34.179156400000004, 25.493676999999998, 29.940091499999998, 29.9187756, 28.5230337, 38.884690500000005, 32.7802399, 33.3767879, 41.617724200000005, 34.6270722, 41.8049939, 35.2427609, 41.673463899999994, 37.1139843, 45.437638, 39.9263159, 34.22643729999999, 35.079285399999996, 40.1531411, 35.231069899999994, 47.4368907, 39.8206729, 48.1335506, 41.533648799999995, 39.996446999999996, 42.0383251, 37.023032, 41.529189, 40.5022908, 39.0711287, 39.9336044, 28.0331372, 39.8607388, 36.9628814, 32.6775705, 39.684461600000006, 41.9972773, 45.68257929999999, 38.7869497, 39.3741504, 39.6323926, 37.9805494, 40.7291042, 33.546201, 36.0089212, 39.396757, 34.0794781, 33.9962787, 40.8296227, 40.70624829999999, 38.230832899999996, 37.5911419, 32.8059309, 43.067814299999995, 25.9633225, 34.202819, 37.7108737, 39.6597802, 32.6571679, 38.877451, 40.4793843, 25.505574, 34.02245070000001, 42.377434, 38.762310799999995, 39.841417, 41.945071, 41.128955700000006, 26.0576237, 37.24545139999999, 39.4184665, 41.8190118, 36.223662, 37.730861299999994, 33.0023401, 39.7639304, 30.239828399999997, 33.3419171, 40.1194604, 28.585369099999998, 42.78124329999999, 41.0012606, 35.286058000000004, 39.6486439, 38.609746200000004, 39.5325981, 33.7726916, 30.498669300000003, 44.7602474, 32.0652265, 36.8173967, 40.7457026, 43.089953799999996, 32.6027505, 41.985435200000005, 42.1970184, 37.7205706, 38.3191257, 36.002357700000005, 42.313947600000006, 33.884298, 28.1806131, 42.43745870000001, 38.9309966, 47.9114849, 37.4215508, 43.7410194, 41.6042005, 34.0405455, 37.9995651, 39.9308027, 41.7406751, 38.8845883, 39.1169211, 43.1885097, 33.9660533, 42.9701335, 33.729592100000005, 45.57353320000001, 36.2364181, 38.6259083, 40.7633953, 35.124221999999996, 41.6499143, 35.5408971, 39.7291072, 41.7953362, 34.4435485, 45.550644500000004, 38.5773838, 43.7609939, 36.97755720000001, 42.2367473, 34.4800598, 39.208410799999996, 33.893910399999996, 32.7470878, 33.7847677, 30.657083, 36.5675579, 33.1171539, 44.043727000000004, 44.946717, 47.6141558, 32.8692105, 36.9923687, 41.5444513, 34.2697395, 33.2968288, 43.082618599999996, 39.020928000000005, 38.6070496, 39.2961666, 39.8041387, 39.8120932, 42.634930600000004, 44.640213, 41.5947322, 47.6595705, 38.8401479, 42.0655463, 38.6717899, 35.90925479999999, 29.8841731, 44.166451200000004, 39.2931179, 34.2350541, 36.1297454, 39.0833905, 38.458602299999995, 33.137136100000006, 38.7708646, 35.104204100000004, 33.8737602, 37.5228124, 40.3084444, 36.8417075, 33.997422799999995, 45.1635151, 42.023920399999994, 30.3816272, 41.518472100000004, 44.930212299999994, 38.9517691, 34.6851224, 33.8224328, 39.56622410000001, 34.934093700000005, 34.8608181, 27.7289925, 39.4596604, 37.99687279999999, 34.6130995, 35.051288899999996, 42.055788899999996, 38.8840144, 45.5118958, 43.164643, 40.777795899999994, 42.808323, 40.0353669, 45.045539899999994, 37.439472200000004, 41.7975955, 40.8232785, 40.236325799999996, 42.7509412, 38.7123427, 40.8995005, 30.395354100000002, 34.18901470000001, 44.8790447, 40.1477284, 39.042347, 44.82114, 25.9890145, 37.560402, 33.924429499999995, 37.6627736, 26.027914600000003, 41.2996807, 33.8525481, 44.7246681, 37.0774493, 36.268899, 39.9459117, 40.676894299999994, 35.3215131, 34.1029152, 39.2864506, 40.1303735, 47.91199879999999, 44.7054047, 42.6871818, 28.153478399999997, 42.5167766, 40.2592494, 45.571070500000005, 42.8071279, 32.4474548, 42.204548200000005, 34.0715256, 37.7437123, 41.71027479999999, 44.7034713, 35.2937377, 28.665073200000002, 34.2135354, 47.3543904, 38.021805799999996, 34.3068456, 30.4438109, 36.77248, 28.5076251, 42.5053726, 37.9835416, 39.351553, 35.4141842, 39.602517999999996, 41.8300727, 44.9767946, 33.7083201, 33.576446399999995, 41.5660798, 41.8832373, 37.2484034, 41.8251471, 44.850630200000005, 47.7050513, 35.3940158, 47.477949, 34.1723184, 41.6794426, 33.692413, 33.609080299999995, 34.3148667, 40.6778181, 33.5499025, 29.9504348, 39.67850479999999, 44.935311799999994, 29.561439500000002, 33.9331436, 41.144280200000004, 42.38545560000001, 33.3867166, 33.4066222, 36.3669665, 44.2831542, 42.874727500000006, 40.0325524, 44.7719887, 38.4604893, 32.1697768, 33.765513, 32.8141903, 44.9362252, 40.7854125, 40.097081700000004, 35.8811533, 42.502789899999996, 33.9344497, 32.9048662, 37.079820500000004, 45.532590899999995, 37.8057305, 37.810387299999995, 40.9252263, 39.15733839999999, 41.838072499999996, 38.939845, 38.6490292, 34.081298700000005, 41.9279225, 40.6808117, 41.3008526, 34.2012855, 39.7185409, 40.6024112, 33.1719277, 33.531888099999996, 33.6298446, 29.9392445, 39.6473825, 33.959235299999996, 41.6086836, 45.379976, 33.9041833, 32.853743699999995, 41.891704100000005, 38.6547268, 43.0276617, 37.5048796, 43.123652299999996, 44.309261600000006, 36.033376200000006, 33.816179999999996, 42.749425099999996, 39.369198700000005, 30.453112, 38.827250299999996, 30.211840500000005, 42.455279100000006, 40.632413899999996, 39.719848600000006, 33.4169647, 32.9983274, 43.4719674, 34.1010323, 44.051161, 40.0302822, 40.0596354, 31.720837899999996, 33.7861934, 42.056434, 38.9837684, 40.6583605, 39.0614701, 34.0941911, 44.9906716, 35.1053531, 38.864133700000004, 32.9875564, 41.995526399999996, 34.4462571, 45.5204364, 43.1392979, 41.54486, 40.0468743, 42.239911600000006, 34.0681289, 42.9516791, 39.593188500000004, 39.9890491, 37.988985799999995, 34.19026289999999, 33.5099245, 42.1808084, 32.8477546, 29.931275899999996, 42.7460905, 39.8528317, 34.419310499999995, 39.177211299999996, 42.490796200000005, 33.226577500000005, 39.7545144, 21.352138, 33.6470177, 30.2715136, 32.645370299999996, 36.86054229999999, 29.654509700000002, 30.5809786, 33.8993431, 41.2719628, 34.9507098, 40.541813899999994, 40.7709484, 42.4888502, 33.868544299999996, 33.970123, 39.0949854, 42.0591118, 33.8735321, 26.431171399999997, 36.3946856, 42.62186, 40.5752205, 38.1435795, 33.499072600000005, 38.283633, 28.682625399999996, 40.8256393, 41.7976477, 40.7098547, 40.7331478, 29.5198164, 34.239137299999996, 33.850627200000005, 33.901221899999996, 43.553393, 41.815275299999996, 33.33386289999999, 35.0787984, 38.8895132, 38.8301503, 45.0027841, 41.9722261, 39.753656899999996, 34.167784999999995, 40.627830200000005, 38.554222100000004, 41.1737527, 43.1267079, 39.0783614, 42.4237393, 42.6059032, 37.128913399999995, 39.031601, 37.0159015, 38.5589864, 44.501976299999995, 34.042714200000006, 41.885955700000004, 38.139345899999995, 41.7860127, 37.086036, 38.7177076, 36.12261779999999, 41.892354600000004, 34.964160299999996, 33.9958996, 37.6357093, 33.9653834, 37.7929713, 37.790826700000004, 33.5791773, 32.049231, 37.537143900000004, 33.8644752, 32.50738, 39.070618200000006, 40.400585799999995, 33.8909907, 33.173642, 36.9878537, 34.715171000000005, 42.557378799999995, 32.4434384, 34.795563, 36.2249153, 41.917635600000004, 38.6711, 39.651841299999994, 39.214379799999996, 34.1894237, 37.261888299999995, 26.8027249, 25.5305339, 26.277863800000002, 40.6959777, 33.1005787, 33.1082604, 34.692424200000005, 26.6194843, 37.4794918, 37.2513168, 34.0746639, 40.529618799999994, 40.0416293, 33.0223646, 34.984603299999996, 36.5163347, 34.0831934, 37.569342600000006, 30.272369, 39.648393, 47.323643100000005, 36.1381648, 33.6444403, 41.7626199, 43.6180124, 41.800028399999995, 41.5596694, 33.9608636, 39.4647097, 35.2196895, 39.7969664, 38.802231299999995, 36.0882006, 33.760462, 35.3907396, 38.99986810000001, 40.3861172, 34.2335792, 33.0052637, 36.0682088, 33.9170526, 38.9824111, 42.33671629999999, 40.7703685, 35.362885600000006, 30.092967699999996, 32.3430445, 37.3947888, 28.0920083, 33.8763664, 38.396493, 40.7076385, 41.5270605, 33.9360675, 38.1746473, 38.7706914, 33.1616179, 30.5007048, 32.4589224, 38.8000444, 26.0218037, 35.1317236, 30.2949463, 35.954426, 33.739953299999996, 35.2952319, 34.2532199, 38.757111, 35.03051729999999, 34.289249600000005, 38.8127184, 47.2490842, 41.2091142, 37.408917100000004, 44.9305501, 42.2738738, 33.131406, 35.9110903, 40.8656158, 41.4768637, 34.1168982, 45.0186675, 33.138393, 33.5264817, 33.5958075, 37.6695089, 41.5452063, 40.59681, 44.9421179, 44.250466499999995, 42.0971614, 33.239921, 48.93801679999999, 42.924897200000004, 33.1269139, 38.648392, 38.6508815, 32.5537738, 30.2854755, 41.936506, 43.0500535, 32.1459532, 45.5114054, 35.82832929999999, 41.5757659, 38.9276429, 33.9528787, 30.450600399999995, 41.59316810000001, 32.828309999999995, 42.124969799999995, 40.636615500000005, 25.8074225, 40.5664871, 33.892322, 39.1017126, 40.758413, 36.8185891, 44.8089686, 39.587646500000005, 38.660587799999995, 38.8761143, 26.5664311, 38.8681789, 33.5147925, 33.5635826, 41.6674169, 33.9925696, 28.023907799999996, 36.9856039, 47.521272499999995, 42.273292600000005, 35.061223999999996, 40.2935564, 42.44335170000001, 39.33497, 33.0146529, 30.256947999999998, 41.6695702, 33.4481905, 34.116282, 41.2415016, 38.9476928, 29.9890902, 26.6867977, 34.0317744, 40.0128408, 42.8192902, 33.9075148, 44.1738142, 34.138450299999995, 38.984487, 38.875466100000004, 47.9935725, 39.5156097, 33.4655887, 33.2761863, 41.9645676, 33.867769, 40.307782200000005, 43.606708399999995, 40.7840833, 39.26549970000001, 33.5875294, 34.849611100000004, 34.135628499999996, 27.878212800000004, 44.99841370000001, 34.0418546, 39.5880202, 33.7934864, 36.2985842, 44.92251029999999, 40.0698311, 34.3860838, 40.8907599, 41.3560355, 37.519939, 21.279919600000003, 33.691472499999996, 41.706095899999994, 33.682914200000006, 38.7335134, 44.298351200000006, 41.9814983, 45.404485799999996, 38.105289299999995, 33.8463255, 44.2768164, 37.7666663, 32.8407682, 29.894993499999998, 32.8685872, 26.656299800000003, 40.9054744, 29.4265208, 38.0504738, 41.9528214, 38.3880766, 38.8007872, 37.2927274, 38.9957928, 33.7947006, 47.2015548, 34.5770039, 39.8142211, 30.399003399999998, 39.105126500000004, 27.983951899999997, 39.795159600000005, 39.9432243, 35.271205, 41.923674, 32.570925300000006, 33.5873473, 47.642577, 38.8950867, 41.618336799999994, 41.8701141, 42.2821618, 40.2761082, 34.211133000000004, 36.056768, 39.8186204, 41.851896999999994, 35.167319899999995, 39.1128994, 29.919262800000002, 37.5903881, 33.4217957, 38.4543283, 18.461301300000002, 44.7021003, 38.528093299999995, 33.91535820000001, 44.938307200000004, 47.4504814, 36.047600200000005, 40.08913270000001, 33.029696, 36.4213092, 30.114807899999995, 33.2199403, 39.174042799999995, 33.2591005, 42.9320341, 40.7773655, 42.629906899999995, 40.400996500000005, 33.9740105, 36.7135739, 32.6876094, 41.2771801, 39.1863472, 27.943918699999998, 39.886139899999996, 40.2022162, 42.3484084, 39.5296592, 33.78145120000001, 38.805202, 42.3364359, 42.7211471, 42.3577096, 38.9370583, 41.915483200000004, 37.213851299999995, 38.8582606, 37.3840131, 40.6077104, 47.3080966, 40.7644351, 35.9588237, 44.8974318, 40.826851899999994, 41.665336200000006, 37.273088, 40.601979299999996, 41.6686114, 42.752083500000005, 38.6619763, 34.790786100000005, 26.175358199999998, 39.053527200000005, 26.3222157, 40.675115999999996, 32.5003844, 39.460088899999995, 27.9558723, 40.784608299999995, 40.9276974, 38.7389534, 30.2971474, 39.130748600000004, 33.935508899999995, 39.8199033, 36.13704129999999, 34.0468935, 39.522873600000004, 39.966604, 38.7039294, 41.25947, 34.7384243, 35.0137999, 38.9141018, 37.4753179, 36.880474799999995, 38.9409336, 40.0221698, 37.983712100000005, 42.193368799999995, 40.676167, 29.950261600000005, 38.8220549, 41.929795899999995, 42.3071378, 43.097724, 45.054828, 45.2156536, 39.732361600000004, 34.0955973, 33.51703, 33.0628042, 33.7015157, 41.514916299999996, 33.815000500000004, 35.2172698, 38.6727159, 41.103155, 34.390995600000004, 40.5912386, 39.389939500000004, 39.548165000000004, 39.6793695, 30.1267195, 26.1671006, 42.24468579999999, 40.9038349, 29.083055600000005, 30.5412368, 42.436766799999994, 28.196504200000003, 41.8757712, 42.7034472, 36.076998100000004, 33.9041561, 45.2785485, 40.2959283, 47.8750641, 40.623751399999996, 28.251254499999998, 39.772919200000004, 47.1655467, 39.7914233, 41.0744782, 45.1978857, 36.0494987, 32.9422201, 32.685567600000006, 34.115176, 39.6736383, 36.239400200000006, 35.3332303, 39.846589, 29.7149457, 36.842025799999995, 42.486804, 28.627056500000002, 34.431478000000006, 40.86763320000001, 33.8115206, 34.2962387, 40.341753999999995, 34.089251000000004, 38.338519399999996, 39.9232925, 42.8930821, 42.9065731, 37.3248541, 44.9508032, 32.8465208, 39.609022700000004, 39.290034399999996, 26.800517, 36.5887994, 37.7208213, 33.7444899, 42.5208083, 38.5669269, 39.9579911, 42.672366, 41.8842145, 32.5917561, 42.4294796, 35.1258104, 45.5119127, 37.6433756, 45.6307917, 39.0828844, 45.6571872, 40.8767726, 36.8543992, 41.5828883, 28.506292499999997, 39.4675762, 34.403251899999994, 40.7040749, 40.1327618, 21.3910655, 45.0209961, 37.77241420000001, 33.5831528, 40.0875511, 38.61725560000001, 33.983203499999995, 35.7571349, 39.353095, 37.7321434, 40.039070200000005], "lon": [-71.8003471, -73.8535818, -76.6352646, -82.4953954, -87.6524344, -87.6895801, -84.5191792, -87.9533782, -117.53148370000001, -122.4175676, -84.5118958, -96.7737127, -104.75016049999999, -105.06320290000001, -122.2877733, -81.5725255, -83.10543609999999, -122.04493329999998, -77.0004103, -72.70664599999999, -87.5935208, -118.19712549999998, -122.57460790000002, -83.7805108, -81.4686274, -118.2914165, -90.03944770000001, -90.1708158, -122.43774270000002, -75.9060251, -76.98584579999999, -89.5445109, -117.1918935, -75.6228934, -82.64598070000001, -80.18097009999998, -104.7444132, -73.8988181, -105.0388111, -72.678057, -73.8092386, -122.2833382, -76.9963306, -81.24534659999999, -80.87184920000001, -117.9952621, -121.73700590000001, -117.3350138, -73.9027247, -73.9027247, -114.99071809999998, -117.09417320000001, -73.903142, -84.4948331, -121.5189732, -118.2193041, -73.68580440000001, -75.27306490000001, -121.9984202, -115.1292682, -81.3425952, -121.48252020000001, -111.3869803, -122.33351640000001, -118.2869206, -118.1886037, -74.0143078, -122.56302009999999, -84.5570281, -118.5721382, -118.43188229999998, -104.77980059999999, -76.93591509999999, -121.3876534, -82.35859690000001, -74.0005814, -104.7524816, -121.2438237, -90.2574572, -104.67106340000001, -76.41187959999999, -118.55506650000001, -104.93027920000002, -122.96452520000001, -73.8617074, -72.7938172, -71.15308279999999, -72.6988738, -122.9922811, -71.17870649999999, -71.4294468, -122.2275801, -78.92134490000001, -122.97513400000001, -84.05337420000001, -74.2198605, -87.62987209999999, -76.9558384, -77.136443, -87.61399920000001, -95.8515017, -71.44862940000002, -77.2317752, -117.21662549999999, -122.8550041, -71.4191445, -118.1698152, -122.38449820000001, -116.93638670000001, -93.3059772, -77.542824, -77.52701970000001, -121.95604159999999, -116.96969650000001, -118.1433453, -81.59650450000001, -104.76535059999999, -84.1457623, -87.6649359, -97.5714682, -84.76831240000001, -122.3450761, -76.74529509999999, -73.2016218, -81.02227409999999, -77.01143420000001, -118.33951850000001, -122.41990600000001, -119.7924156, -104.8025716, -104.9311771, -80.7755245, -115.2612871, -117.6046422, -122.21418200000001, -116.2114686, -80.1390464, -84.3272835, -121.3639394, -122.02321040000001, -96.8471481, -93.1501854, -118.53172990000002, -118.80571189999999, -79.9838017, -96.7800762, -70.9161108, -112.38503130000001, -73.0482405, -73.76743640000001, -72.574247, -78.6210561, -71.87352109999999, -71.1275287, -84.3825135, -73.8565158, -84.4025892, -116.22611, -84.97582750000001, -118.2457754, -73.93213809999999, -77.51697740000002, -119.7439756, -80.3576356, -74.088895, -104.923252, -117.21769920000001, -122.29558899999999, -115.19832509999999, -77.42676850000001, -122.30175190000001, -73.20215970000001, -117.5071044, -117.89025729999999, -82.37651120000001, -97.1345969, -117.6207229, -82.33335749999999, -121.302748, -122.9130757, -118.1740906, -77.49838299999999, -94.560395, -115.21622849999999, -76.99783520000001, -104.9579436, -76.171318, -90.07262109999999, -81.6230968, -105.0045818, -118.59520990000001, -76.860196, -77.0389515, -116.9521669, -115.12053689999999, -80.29869609999999, -122.40471399999998, -93.142383, -84.15588120000001, -119.20225249999999, -81.6833, -71.0747098, -77.0538118, -104.8362493, -77.0118821, -72.4544528, -77.6972895, -96.85510959999999, -104.9931394, -111.8852453, -111.9961592, -117.6755256, -122.5571962, -80.1539561, -119.0445781, -72.8736415, -82.441176, -74.24356999999999, -83.08911479999999, -73.8859223, -81.65638620000001, -122.45688270000001, -105.02176580000001, -95.5806736, -87.623768, -73.87428809999999, -111.97418559999998, -93.30126700000001, -111.9243386, -104.85805990000001, -87.7376226, -118.3319132, -87.63840379999999, -77.47852850000001, -84.5440375, -77.4369618, -122.46777620000002, -117.91362990000002, -118.374302, -80.129109, -76.97940899999999, -87.6674491, -104.9048678, -104.76543559999999, -93.3125462, -80.8532073, -121.96057859999999, -95.4634483, -118.5855271, -77.1164683, -77.30277149999999, -117.09640149999998, -91.676311, -73.7778558, -105.121876, -111.98740819999999, -93.3133278, -120.54233300000001, -117.15201100000002, -118.32167700000001, -122.014721, -93.2662228, -119.19038529999999, -83.25051590000001, -104.9677997, -89.86134679999999, -105.1307399, -73.1029142, -104.89102620000001, -76.903318, -73.8538128, -104.7665861, -73.8952137, -122.5431129, -87.9463027, -86.8917438, -111.878993, -117.8817476, -81.92354449999999, -122.27416880000001, -121.3368081, -83.5317687, -111.85740200000001, -75.6464158, -87.9454476, -117.2341615, -87.98367420000001, -117.4868554, -117.6740258, -118.46053329999998, -111.66448570000001, -118.3482415, -118.18397659999998, -76.8295131, -71.7916493, -115.5677777, -111.9713025, -105.02291720000001, -77.1631963, -104.97443319999999, -74.2173714, -87.6302178, -117.5346297, -71.0937386, -76.1048153, -76.85140109999999, -71.5573907, -71.5330964, -105.97684270000002, -117.6242993, -122.2744575, -119.0634239, -90.0265755, -93.1863948, -105.98261029999999, -118.0760209, -77.12285759999999, -84.1770157, -81.5190981, -78.8704226, -81.1600547, -77.13113259999999, -77.6586767, -88.07363029999999, -104.7515366, -105.07456940000002, -71.35972220000001, -118.65656100000001, -117.8778643, -83.0885598, -87.98620079999999, -83.78917320000001, -118.21811459999999, -87.84415290000001, -76.86040229999999, -85.1633645, -117.17096629999999, -77.64416329999999, -77.001109, -104.8574515, -71.1661474, -77.2597436, -119.7201155, -106.27052959999999, -90.0765412, -117.4490622, -95.6588784, -83.29845440000001, -118.01720420000001, -93.0376071, -74.2160036, -96.80123490000001, -118.126802, -70.9136542, -88.218623, -85.4753422, -111.65919550000001, -73.9718051, -80.00427579999999, -88.080701, -117.44279180000001, -76.34536870000001, -73.8286536, -104.63106020000001, -80.0962292, -104.82039990000001, -73.8401352, -121.60167450000002, -112.0600165, -112.01187490000001, -87.6521652, -122.2513558, -104.8390645, -76.1193188, -117.51607779999999, -75.16294549999999, -87.65790159999999, -83.2852311, -81.7620338, -75.3710751, -81.5671073, -72.98673409999999, -118.322056, -77.45084890000001, -76.5320154, -112.0590439, -84.4769375, -104.7658824, -87.5989422, -76.97771800000001, -96.6917005, -87.8501113, -112.32059469999999, -122.40885490000001, -73.1969734, -86.120216, -83.09490720000001, -81.7224654, -117.3900615, -71.7499832, -73.5730887, -117.89581170000001, -105.1474972, -71.0421575, -76.088934, -79.86338459999999, -105.09770139999999, -96.78116390000001, -88.0971363, -117.4162682, -81.474019, -70.98840109999999, -77.5233071, -81.24539859999999, -122.94366240000001, -88.0796335, -73.9438615, -71.3163079, -122.5722572, -81.6882362, -76.4979347, -76.9026494, -96.6391141, -84.6067944, -122.3382222, -111.99742409999999, -84.2923388, -79.9244972, -118.4273952, -80.2227936, -83.5012785, -121.2887619, -117.9978509, -80.2127122, -76.1523907, -122.56661650000001, -90.98770909999999, -71.3345645, -84.84633790000001, -83.1237435, -118.3089917, -122.3566031, -79.9893873, -85.7020156, -117.52449240000001, -105.064927, -71.48240770000001, -118.45851850000001, -86.59051099999999, -77.2768035, -89.1107986, -112.301829, -74.4405589, -118.2491936, -76.86170209999999, -80.2353122, -76.7754851, -84.59357659999999, -88.0738166, -117.9286916, -84.1313282, -122.49367190000001, -118.43272169999999, -85.43702900000001, -73.57248609999999, -83.6434071, -105.1095361, -117.83766979999999, -118.53825390000002, -76.96252890000001, -118.4423602, -147.7262763, -76.14572259999998, -73.8921224, -90.2502412, -73.5409467, -122.3027487, -118.3569389, -104.9134956, -85.0200214, -77.4317689, -84.29459969999999, -90.2642112, -87.6280536, -121.30579920000001, -104.7579585, -86.0003997, -87.63239540000001, -81.3166036, -88.0173067, -80.05098170000001, -77.1966358, -77.9497306, -106.594435, -76.9594342, -104.7957722, -117.522205, -118.46592620000001, -74.8954186, -71.3093264, -117.1295175, -81.4112143, -104.94923680000001, -116.2442242, -80.1463303, -84.2410431, -122.240953, -122.05073270000001, -119.71583840000001, -80.7156559, -122.23202749999999, -93.2718722, -77.0029301, -121.8777455, -90.2137506, -74.2681204, -76.7424834, -74.26655720000001, -74.1824032, -118.2463128, -71.4240055, -77.12474279999999, -122.28689479999998, -76.9850809, -84.330538, -104.8089149, -115.197961, -118.4243044, -104.6338835, -86.5327165, -72.0091181, -122.57324950000002, -118.10633829999999, -118.09671809999999, -118.1623973, -77.0692614, -105.04610339999999, -121.77074270000001, -84.7707543, -118.3023777, -104.6902364, -94.5487109, -94.3496007, -97.32296579999999, -121.59800039999999, -79.9867715, -104.7958216, -77.2771369, -86.23382509999999, -77.5495714, -73.1178767, -73.46624969999999, -122.67452649999998, -76.9997922, -90.22513959999999, -117.39658200000001, -84.4467818, -76.54700150000001, -118.3402541, -117.01301509999999, -86.8893868, -87.6002666, -71.9061176, -81.558494, -73.76648459999998, -80.2784257, -105.0685379, -95.5197006, -89.26344940000001, -118.5606591, -112.1067463, -83.0960665, -96.9594948, -84.72677159999999, -71.0514885, -86.6754096, -87.7191305, -97.0980382, -80.1648288, -117.6396061, -83.43416040000001, -93.02428570000001, -117.0716346, -77.23337109999999, -117.91475700000001, -74.015852, -81.1787197, -118.21827959999999, -110.8290507, -121.4987966, -122.1939162, -94.40830559999999, -118.4598237, -118.2413457, -71.1557303, -72.20325550000001, -96.7381193, -121.4185883, -77.1777286, -77.57872259999999, -118.3657855, -82.508636, -80.3975735, -121.4447294, -84.1855843, -75.172227, -81.5391623, -76.5900973, -104.78020649999999, -119.76333000000001, -90.1095678, -118.19477250000001, -84.79650290000001, -122.57362040000001, -112.17534979999999, -77.4282188, -83.3071022, -96.21540999999999, -76.192898, -76.82301319999999, -70.8966155, -71.3083671, -73.9407223, -82.5569416, -117.5175804, -87.6920314, -84.2855515, -77.398648, -118.3475932, -80.2090662, -80.23104909999999, -119.049604, -88.05270300000001, -122.83231950000001, -76.91920259999999, -122.43177340000001, -73.76309029999999, -104.94997, -84.1781093, -75.351036, -73.7619559, -118.337332, -73.9669265, -87.65375470000001, -84.75528320000001, -117.11342690000001, -111.69229779999999, -84.5442585, -119.7051132, -81.0917023, -104.79142929999999, -80.373458, -122.17591829999999, -75.07889709999999, -118.4898281, -73.7006968, -84.5429643, -121.8142432, -123.04959609999999, -118.3834061, -104.7810429, -122.06936909999999, -75.2833596, -80.2268897, -118.1739007, -81.605797, -88.42837309999999, -116.89426340000001, -122.3050028, -93.36518459999999, -118.3318624, -105.0673281, -104.8004672, -76.90580179999999, -111.9131301, -81.01316240000001, -156.4887351, -77.33986829999999, -77.5152427, -80.214258, -122.9783913, -118.1012717, -73.98662850000001, -81.27791640000001, -73.61408349999999, -84.43707629999999, -122.31658300000001, -117.06904340000001, -82.46896219999999, -84.05411640000001, -73.96685809999998, -121.66642759999998, -122.3311112, -117.99030990000001, -96.7025835, -85.0442122, -84.98823940000001, -116.3132875, -104.734629, -117.96083840000001, -75.6077483, -97.13964990000001, -121.7937321, -118.24699679999999, -76.4257023, -122.57032759999998, -85.17757390000001, -83.30340859999998, -94.65876740000002, -88.060218, -117.21378429999999, -77.1149795, -88.9357363, -81.76852120000001, -158.1228176, -121.7489395, -77.5382198, -77.0149469, -117.79797190000001, -76.7288484, -111.958046, -83.5236163, -76.98640520000001, -96.68922540000001, -76.87034670000001, -87.74061440000001, -74.89057659999999, -120.87279040000001, -77.33513409999999, -71.3040807, -117.8525, -87.60962940000002, -117.6225929, -81.9698538, -84.35447740000001, -96.4543168, -74.226135, -73.9587186, -118.22111149999999, -117.9278881, -84.1307865, -86.8027103, -104.7755214, -80.7715182, -73.954388, -116.96135120000001, -105.0417135, -111.4251092, -87.751073, -81.5287478, -93.3488224, -74.02373270000001, -104.95043840000001, -83.95822059999999, -117.07538159999999, -82.8994151, -76.91067509999999, -122.28263899999999, -119.64456940000001, -83.7948034, -105.11373789999999, -80.8395961, -117.0867251, -89.9272045, -88.1378071, -76.1693867, -93.1768215, -117.60728950000001, -121.8713866, -111.9373758, -72.6406433, -71.0722753, -73.768763, -95.8341626, -87.6871169, -111.79754009999998, -104.7051421, -104.9942433, -88.13262850000001, -87.9572594, -80.240105, -77.0875449, -90.2355495, -73.9179179, -121.4661875, -104.7800166, -81.05376340000001, -81.1270015, -82.3057403, -77.09485059999999, -84.8776233, -105.04804240000001, -73.62330990000001, -76.8800491, -76.77030090000001, -105.01921670000002, -81.54995629999999, -158.0913758, -80.2581261, -104.80061500000001, -80.0757035, -95.5030621, -104.8356793, -104.7848078, -105.1022393, -93.27380240000001, -80.1453281, -81.58512579999999, -104.9681816, -117.06931509999998, -80.1343344, -78.89162950000001, -87.66963220000001, -89.693811, -118.52066840000002, -72.9988568, -93.3102718, -80.83161379999999, -82.32741440000001, -79.7417335, -119.02883519999999, -81.64336740000002, -71.0566567, -115.0593121, -84.4160043, -121.2785027, -117.1047071, -118.32234679999999, -116.610601, -97.02782420000001, -118.5273253, -118.2861364, -81.09312840000001, -104.7168189, -104.8304713, -73.8521815, -91.6871605, -84.3790981, -122.5635095, -117.44519109999999, -121.362801, -81.6681873, -122.4139445, -119.7202981, -84.3356621, -71.1305713, -107.80696270000001, -80.75370699999999, -82.78124659999999, -112.05005359999998, -122.5235732, -72.63428979999999, -90.2397912, -119.67304879999999, -72.5909593, -116.91065470000001, -93.3594938, -81.7756429, -81.5560578, -73.6167087, -78.6021439, -84.25627850000001, -84.2300879, -84.97489759999999, -118.3650028, -117.2039588, -93.28746109999999, -84.61162009999998, -105.1450331, -115.0712758, -77.3963482, -122.23130159999998, -121.9372588, -77.44517420000001, -117.2912706, -87.8996709, -74.1091938, -80.2055235, -122.76070659999999, -80.25190970000001, -104.79491800000001, -93.2872546, -80.8309436, -104.91150559999998, -117.18946070000001, -71.30959, -80.141806, -115.2928868, -76.89070799999999, -83.7474037, -87.90282979999999, -76.8174928, -81.6407986, -82.43878240000001, -117.55480039999999, -122.1826098, -117.11905520000002, -74.2236813, -84.41059849999999, -86.28863179999999, -118.5578906, -108.596204, -104.95436459999999, -122.1262173, -118.23918429999999, -74.070286, -93.7808947, -72.60249940000001, -84.5086055, -77.22993570000001, -86.75011740000001, -75.5747325, -93.3299204, -81.9734142, -77.40321750000001, -117.2759939, -72.59978890000001, -83.8249359, -91.04772259999999, -105.1552545, -118.3244227, -77.9731782, -118.15264950000001, -81.82063690000001, -93.25751629999999, -111.85357340000002, -122.2149774, -82.7020337, -82.9486151, -156.44101030000002, -73.8978818, -73.82928129999999, -117.2006679, -71.10275379999999, -86.63450279999999, -119.76935700000001, -76.2769553, -118.9627618, -105.04280700000001, -88.077923, -121.20877479999999, -118.2607508, -79.97001920000001, -85.80315209999999, -105.07453170000001, -105.10586129999999, -89.3860992, -71.3260812, -84.9052923, -83.8023847, -73.8942499, -117.06647099999999, -122.6425893, -93.1356392, -75.6112728, -97.5196446, -119.7434524, -81.26670390000001, -119.65398459999999, -84.18968829999999, -111.69142079999999, -84.7322281, -84.2919399, -122.4521467, -83.0749614, -87.5905449, -117.7652744, -122.33194099999999, -118.6580693, -89.09444429999999, -92.2463782, -73.9489203, -83.8054862, -105.0437937, -118.30293200000001, -122.0804834, -104.98321340000001, -83.6043296, -119.1367209, -92.52007270000001, -80.6346803, -104.7333998, -119.7567334, -122.50121999999999, -94.4869807, -74.3153599, -116.3985507, -89.6076214, -83.55727590000001, -90.5316032, -84.60795920000001, -118.5076229, -118.1855017, -121.71444380000001, -95.7287185, -77.3558162, -108.7310412, -84.6793579, -122.3762226, -121.48608940000001, -71.2834848, -104.7519569, -87.99196040000001, -120.43073670000001, -90.0439689, -77.28330600000001, -81.14302049999999, -111.62364939999999, -80.0614202, -104.7869665, -72.53210059999999, -117.95359309999999, -71.39564399999999, -96.6187806, -97.3738906, -75.5369353, -72.81126090000001, -111.90280249999999, -111.03066170000001, -123.29591129999999, -84.5386849, -118.4365003, -93.273065, -122.24971470000001, -73.4338977, -77.08192109999999, -92.632248, -122.77953079999999, -74.11203309999999, -122.70484109999998, -70.21624849999999, -117.35416780000001, -80.820144, -122.0225189, -119.15653130000001, -117.9474673, -87.94279279999999, -73.87109, -104.99616850000001, -81.9819988, -119.1003601, -118.58529750000001, -93.3444002, -73.33107159999999, -91.50949820000001, -96.76679759999999, -77.2129918, -116.95798529999999, -88.2679397, -82.0531079, -97.2567313, -121.82461909999999, -77.4854336, -78.9120187, -118.1397371, -117.0385895, -93.1882878, -121.1830055, -76.7107147, -117.99341820000001, -73.9091012, -94.7317676, -117.95554399999999, -118.2816328, -73.90029399999999, -122.64535490000002, -77.5133737, -89.966994, -118.08926299999999, -119.87650649999999, -83.941917, -83.5938966, -83.51677459999999, -80.21148690000001, -90.05535040000001, -80.80304709999999, -76.8364543, -74.2291175, -76.98667859999999, -77.0419399, -115.2740979, -122.4799189, -84.26524640000001, -117.7546973, -76.9896873, -95.4731807, -74.5757384, -72.2288725, -122.41377040000002, -84.51204320000001, -96.8723443, -117.29202749999999, -88.3294685, -84.39748309999999, -118.1926968, -71.5660799, -91.6443642, -121.89713300000001, -92.2152605, -105.11538020000002, -73.4073395, -76.6678344, -77.625419, -92.262856, -95.7090108, -106.50195169999999, -74.7507171, -118.2829278, -121.5606959, -97.2193408, -157.8696157, -118.22070009999999, -74.170046, -71.0742308, -115.03832560000001, -122.31811640000001, -97.084327, -104.5221938, -158.03516499999998, -81.5682563, -76.7772427, -111.91806240000001, -111.9397541, -77.6391009, -76.25399240000002, -118.41247379999999, -118.42030259999999, -83.963953, -80.8236353, -120.9376668, -81.3751563, -118.14023629999998, -122.22270259999998, -77.584113, -86.62849229999999, -87.56381429999999, -71.5079906, -76.49703149999999, -73.95684200000001, -72.90782790000002, -76.35556059999999, -83.7249741, -122.63841399999998, -97.6692022, -77.6112348, -84.6062571, -122.2582787, -88.2254104, -105.040497, -73.70937109999998, -117.254695, -73.78242790000002, -119.9503432, -82.2391436, -73.7661843, -87.34653859999999, -118.1901733, -84.2248918, -121.84696540000002, -77.4308462, -122.53070819999999, -82.5957303, -84.2527137, -117.39184009999998, -90.32088540000001, -84.2233287, -87.2162337, -84.0967614, -114.8350406, -75.04835959999998, -72.45008179999999, -80.4047272, -122.3603524, -92.5326089, -120.86099170000001, -73.0032869, -118.27614150000001, -71.4613127, -79.77483740000001, -77.0556067, -84.23151949999999, -83.4301994, -83.2454242, -118.7532342, -84.5843198, -122.4749338, -91.2263875, -87.26555479999999, -91.4913927, -93.2668994, -104.8008257, -96.736205, -111.7984566, -88.7558659, -121.4337996, -87.66069820000001, -105.0297696, -95.49267640000001, -93.2809123, -93.69701500000001, -92.03408, -121.51489240000001, -73.417517, -119.27198909999998, -118.5320785, -84.6796763, -115.21608119999999, -117.98000049999999, -89.0201169, -112.247472, -85.81967790000002, -84.18644640000001, -79.8588904, -87.7038401, -122.4191487, -76.8893719, -112.12182609999999, -89.01260090000001, -77.1360243, -80.31976750000001, -80.4558094, -82.732586, -78.4358508, -111.6974375, -75.94688609999999, -121.63444750000001, -76.6953197, -76.61630600000001, -118.37839869999999, -111.88260819999999, -104.8148644, -122.53435490000001, -76.9490616, -121.33531909999999, -84.8854254, -122.4786272, -73.9050398, -77.1880849, -84.2083098, -90.0568664, -96.6054046, -111.95640890000001, -88.1211674, -122.39560559999998, -73.2275149, -106.88630239999999, -74.156518, -117.9632149, -118.2669741, -118.3043149, -84.3650954, -76.9353432, -97.55691259999999, -115.0352662, -84.2702168, -92.8033755, -104.8126127, -118.5469513, -108.5670101, -82.6439496, -76.56179709999999, -122.7835541, -121.97349969999999, -117.09704579999999, -111.9884344, -74.1188591, -121.45830349999999, -121.82464350000001, -119.9327905, -79.38787590000001, -73.88262809999999, -77.49947220000001, -82.97175940000001, -76.34351290000001, -105.1211568, -100.8009399, -80.1579683, -96.71394529999999, -76.4129622, -73.84975899999999, -93.1116714, -105.101052, -122.2652793, -93.36186359999999, -71.28862990000002, -73.8495052, -86.02115529999999, -116.92640259999999, -88.5513441, -87.69255030000001, -93.2486536, -85.8684286, -77.140079, -117.23714479999998, -77.6348554, -104.7627206, -121.1293034, -90.04647109999999, -76.42280229999999, -75.5381422, -72.8322364, -96.8087578, -90.01329150000001, -81.7912518, -87.8550699, -87.3455213, -92.9712937, -74.155392, -122.17321399999999, -87.685499, -118.06204579999999, -72.17142679999999, -87.69975409999999, -117.8290128, -111.97515220000001, -91.62918640000001, -122.04933600000001, -87.98336379999999, -70.9974786, -73.9288811, -118.02009579999999, -104.6083782, -75.50213000000001, -73.07750300000001, -116.56534540000001, -75.30916479999999, -118.3925764, -83.1911457, -76.8041439, -82.9934126, -115.5571364, -86.0812069, -86.74107679999999, -83.82342, -81.6243314, -117.4083743, -76.7865355, -84.3755377, -81.66262370000001, -84.1315944, -117.2838101, -94.17554940000001, -121.03077569999999, -77.40782209999999, -106.28808980000001, -82.9761993, -76.8468865, -104.7521848, -105.06254640000002, -118.2839315, -89.4893192, -121.01216699999999, -84.169855, -75.44928370000001, -84.5584976, -81.6085525, -105.09795770000001, -81.7335359, -77.5315135, -123.4287236, -96.70937669999999, -90.0643723, -84.494182, -81.6455445, -76.6304217, -117.79200300000001, -84.5301021, -104.7943144, -104.84226329999998, -86.2970783, -117.59325859999998, -84.182363, -104.80529140000002, -112.1429058, -90.04064699999999, -159.6248282, -93.18992659999999, -122.30124779999998, -84.7067038, -83.1643604, -111.96978130000001, -95.04998459999999, -87.8898619, -66.1486169, -84.4870266, -119.69316570000001, -70.92456990000001, -82.20953399999999, -121.42116299999999, -105.0633084, -118.18780829999999, -120.4601195, -122.20319920000001, -80.698909, -117.17737549999998, -73.6249571, -115.1255528, -73.89948299999999, -117.0785895, -104.8362566, -118.52310049999998, -104.2966601, -105.031805, -117.7067072, -119.03913, -90.2821537, -80.85981640000001, -81.2382532, -118.40382509999999, -96.8865473, -89.98294179999999, -111.2737486, -89.02196479999999, -74.1398995, -87.7174955, -87.9620643, -122.2494562, -81.3565291, -122.79204879999999, -78.6481695, -76.81116209999999, -121.2953919, -87.65474, -93.3150267, -117.59301049999999, -121.08097479999999, -82.23125920000001, -96.9267193, -82.52804859999999, -122.7960744, -82.85642209999999, -76.7691425, -122.5881278, -122.33093600000001, -78.96445179999999, -73.9429558, -73.97605759999999, -117.80284070000002, -77.65619050000001, -122.56173259999998, -90.4106558, -96.9448806, -73.7587303, -122.64412730000001, -119.6308433, -122.81450509999999, -118.42330890000001, -83.6687953, -80.27054770000001, -72.8340199, -89.9924923, -88.7159258, -72.90043890000001, -83.90969040000002, -74.2135059, -104.7371996, -111.9454463, -105.01800390000001, -81.6998186, -83.0254934, -77.3553713, -118.4410821, -117.23537809999999, -82.3317766, -111.66121240000001, -118.39856999999999, -122.2536653, -92.9548605, -81.18218900000001, -117.29179440000001, -84.8394665, -79.9833334, -87.664188, -117.69447790000001, -92.0459472, -119.6660507, -86.3754059, -96.8899875, -117.87224350000001, -73.901152, -118.24855590000001, -106.61059170000001, -123.0521513, -75.6539686, -121.86618020000002, -122.18352890000001, -117.78936570000002, -111.92255690000002, -86.3398046, -122.28340630000001, -122.4101017, -117.63614, -121.4295972, -106.6398078, -120.93693929999999, -118.34838429999999, -77.0730697, -87.9409967, -88.0165698, -105.10524529999999, -111.82684609999998, -73.97274209999999, -119.70186559999999, -118.10368970000002, -83.1097705, -112.32031359999999, -70.2285964, -89.96172370000001, -74.1384458, -149.848285, -81.9009985, -70.99369920000001, -76.9265276, -74.12224920000001, -104.94197630000001, -93.47137459999999, -77.11055520000001, -117.9439945, -84.4599382, -117.5413331, -83.1092731, -70.6681223, -82.8572933, -81.3499068, -82.4131381, -70.92781590000001, -82.7576983, -93.1123359, -121.1238857, -82.8288008, -75.5282127, -93.5385204, -80.2629204, -105.07376599999999, -77.3948324, -76.52037440000001, -72.07752679999999, -84.8219359, -80.25126359999999, -77.0781397, -111.8382486, -111.88126670000001, -97.33765550000001, -77.720447, -97.3920707, -111.83159440000001, -118.3730134, -121.0239311, -116.9812065, -104.9504003, -104.8759804, -83.5883382, -86.5324808, -84.2587867, -73.1151448, -122.65819109999998, -118.6012202, -85.8754335, -121.383137, -106.78374409999999, -71.4878644, -118.1942193, -95.5707122, -117.7827824, -81.7428718, -74.9667387, -73.9564859, -94.3792296, -84.410154, -96.8473457, -105.03796489999999, -96.7776351, -121.95693100000001, -117.9292136, -93.3556682, -105.0034557, -93.4454977, -83.7921236, -83.9310572, -87.6619014, -76.473568, -78.9839079, -81.47863690000001, -84.59804190000001, -82.6120422, -82.520912, -90.2060528, -93.2597809, -118.55578929999999, -117.0899733, -90.1002623, -117.40242759999998, -80.0030013, -105.55857720000002, -117.16255509999999, -119.69752959999998, -71.09512959999999, -121.43205449999999, -77.50639699999999, -83.1789442, -71.83350159999999, -77.4535483, -119.5624953, -84.20043079999999, -80.4958493, -90.1135507, -89.9774858, -81.29735720000001, -94.4318263, -116.9383632, -83.26548340000001, -70.91573509999999, -98.4661395, -87.6624414, -80.8428441, -83.534401, -85.04704029999999, -122.78814969999999, -105.0822175, -118.46437759999998, -106.6127406, -83.2020135, -80.870799, -122.2014158, -75.1147342, -122.1637635, -93.6113141, -75.1167526, -91.6153272, -121.5818003, -93.5241364, -104.9175585, -84.4980095, -104.95158799999999, -81.8403497, -86.22927259999999, -86.38676679999999, -117.05476770000001, -84.163647, -87.6559864, -108.746867, -90.3406478, -76.71680090000001, -105.15635959999999, -121.2764321, -73.4779715, -117.19789159999999, -78.8853868, -76.3428558, -117.6460511, -117.51402759999998, -96.68271419999999, -73.5557891, -104.6525321, -122.04868700000002, -96.81229429999999, -87.9399712, -80.13635790000001, -119.1860277, -121.91779369999999, -104.8947662, -117.05642009999998, -120.4293625, -120.59706770000001, -80.42265479999999, -117.8980812, -71.1966282, -77.14439200000001, -105.0116197, -87.6760595, -73.5945339, -80.1207787, -79.92554720000001, -76.3107388, -87.59517609999999, -115.32060449999999, -122.16564840000002, -96.8245577, -105.0462665, -81.7846793, -111.9198091, -105.0290663, -81.4339188, -83.2536654, -80.7281358, -80.8140714, -104.78180520000001, -122.96693880000001, -119.8397793, -118.2023757, -86.4657385, -93.26641529999999, -81.1270475, -76.336438, -111.879636, -75.2286955, -96.91636379999998, -87.86941949999999, -83.60161109999999, -121.04567990000001, -121.924618, -86.5823902, -83.7000112, -117.83505829999999, -82.4111305, -71.4622486, -95.1972813, -122.3146889, -121.89649070000002, -87.7137865, -109.24732479999999, -83.8155058, -121.3622008, -82.9428093, -72.8413583, -76.8056304, -82.0608909, -77.53530140000001, -118.2629318, -87.9018627, -84.9218971, -122.68362490000001, -115.08924479999999, -121.3914626, -74.2353303, -80.972061, -91.5650449, -97.5707381, -104.95078670000001, -87.9755167, -118.5164043, -122.56252669999999, -121.45474320000001, -111.2117653, -121.58635190000001, -121.78645859999999, -118.63286699999999, -94.41714420000001, -117.8479811, -79.99542480000001, -118.3159757, -81.66678459999999, -86.55437370000001, -117.180627, -123.12508970000002, -93.09103809999999, -122.28109579999999, -117.21753500000001, -76.41272990000002, -72.0630395, -118.68482900000001, -84.4668415, -87.99757690000001, -84.2899306, -121.304405, -84.5150927, -86.00014870000001, -86.3016016, -71.307502, -121.10320890000001, -73.4440872, -122.3235185, -76.8240487, -91.7799436, -90.3237969, -77.822577, -81.315088, -88.57371020000001, -84.49499770000001, -119.0878362, -115.3192672, -77.013595, -77.412402, -117.08679199999999, -77.15732249999999, -106.97537820000001, -118.12121470000001, -77.3080714, -111.67405090000001, -76.3237885, -118.2981841, -93.0542963, -88.152699, -81.5830561, -81.6120068, -93.2482858, -84.49987309999999, -82.2888109, -118.2032005, -76.4170063, -78.9513522, -76.8419397, -82.6394702, -84.45586540000001, -77.0230025, -112.3049518, -78.99308640000001, -70.9952537, -76.9143548, -122.40656340000001, -88.0116944, -73.22137140000001, -85.5212597, -104.91271029999999, -92.80822090000001, -121.88192169999999, -87.6767426, -81.35913149999999, -74.7184493, -83.3218946, -121.31757659999998, -73.8437344, -87.39519659999999, -82.0906631, -93.66194899999999, -76.5963253, -84.4907439, -92.9183588, -80.2330786, -77.3930985, -84.0484281, -121.02044029999999, -80.23091509999999, -72.9726942, -118.25696040000001, -93.23160290000001, -88.6334401, -115.12590859999999, -75.16994749999999, -73.7364182, -80.7066959, -117.8678976, -76.5586438, -75.518211, -122.03220759999999, -93.2311426, -83.1412734, -82.4516642, -70.8869311, -80.19496579999999, -122.65593740000001, -87.9022081, -89.98479429999999, -70.92502950000001, -84.5008181, -122.4142166, -71.1489973, -93.2991255, -89.9561775, -81.5059645, -119.1858676, -122.03229669999999, -122.0963072, -84.1453121, -87.2180587, -119.77919540000002, -81.3198043, -70.8879672, -84.40615009999999, -76.66933320000001, -80.86812859999999, -105.12226650000001, -71.4281689, -122.9793007, -84.274474, -117.5835223, -73.0762333, -87.8097247, -121.8645577, -87.7877679, -91.93350240000001, -121.9486574, -119.41649050000001, -94.9009071, -118.12467690000001, -86.14102829999999, -117.22558459999999, -117.1893389, -85.296075, -95.8582428, -86.8329641, -89.962128, -104.838073, -122.7764678, -95.03758959999999, -117.9434406, -74.0282748, -71.0043188, -111.7456385, -84.5509279, -121.47588940000001, -92.9183023, -82.588053, -82.9464802, -93.25415229999999, -121.40334299999999, -110.83239209999999, -84.3947157, -116.92702050000001, -92.88406450000001, -82.5355507, -82.8518434, -78.5902418, -83.1787589, -117.4707309, -97.162151, -120.28808149999999, -92.9583911, -122.28478030000001, -122.276991, -75.39697109999999, -95.6983078, -71.43797679999999, -76.9626302, -121.23910740000001, -118.3811478, -87.74410479999999, -73.88751490000001, -81.48586829999999, -86.8254882, -105.0464605, -73.96348640000001, -117.2369006, -117.1188981, -111.75197709999999, -95.55523640000001, -86.8263847, -81.0781387, -93.54637559999999, -93.2077627, -84.74336690000001, -97.2277052, -87.7021747, -90.2316895, -87.9879693, -122.277553, -93.1915014, -69.7967858, -79.8324917, -118.1953378, -84.5932204, -76.5912458, -97.6266926, -77.0986804, -97.84044509999998, -83.03038199999999, -73.9338762, -75.5313509, -84.2042316, -80.1695101, -89.75715129999999, -84.161121, -122.994372, -76.30827459999999, -74.88639079999999, -92.11405129999999, -118.1534873, -71.6404009, -74.9113078, -112.0175041, -94.4230107, -118.20039609999999, -122.9807382, -81.3302319, -76.89099379999999, -115.544002, -71.51909309999999, -118.5457784, -94.10648909999999, -77.6079993, -71.2998632, -82.4239872, -83.6767996, -84.1465317, -90.1148966, -94.27193630000001, -75.1536062, -77.51522750000001, -118.47780549999999, -84.32672779999999, -83.6009219, -96.791368, -90.09419749999999, -105.4423656, -104.9708005, -118.46404720000001, -84.4624267, -82.9351259, -111.71186409999999, -75.0825843, -157.92195130000002, -117.96712820000002, -81.74097629999999, -117.0210215, -119.6445547, -95.41372059999999, -91.1507657, -118.2100244, -72.5903881, -89.98837320000001, -105.01601299999999, -74.1427474, -82.90291359999999, -118.19865520000002, -83.36595, -108.46618740000001, -70.9731985, -84.6134055, -80.0809957, -93.73437559999999, -71.3323941, -74.1552188, -85.7000147, -84.1993992, -90.585431, -81.4123057, -73.8923237, -87.6671138, -73.787975, -73.8127448, -95.0841364, -118.46213020000002, -117.8977733, -118.19649299999999, -89.4817003, -87.70918449999999, -86.9127674, -89.8594371, -76.6408656, -76.8882324, -123.3092456, -91.65382070000001, -84.29586390000001, -118.52451940000002, -75.340006, -121.4637479, -80.7717824, -76.1035564, -77.5478652, -70.99791590000001, -90.8455705, -122.1354489, -77.03998259999999, -76.4268079, -90.47081999999999, -88.0112051, -81.0051449, -71.06830500000001, -122.23518419999999, -72.51340350000001, -84.0718983, -77.72406540000001, -80.2209341, -87.6745068, -120.4445191, -118.39615970000001, -85.53651359999999, -117.41157620000001, -122.41273329999999, -120.4501293, -117.7339145, -81.10924990000001, -121.98714720000001, -118.1532084, -92.145009, -94.6739124, -111.73068740000001, -84.2742635, -90.8551191, -121.57134939999999, -106.6087281, -71.741518, -111.32159329999999, -87.1461015, -86.73991509999999, -88.1853806, -121.26697539999999, -77.5535734, -121.0349257, -119.21465859999999, -79.947919, -80.6742637, -80.397187, -80.270392, -73.8505707, -117.2889625, -96.75933909999999, -80.8004274, -81.8630223, -76.9098239, -121.9644886, -118.33927390000001, -74.1456003, -76.6960717, -97.0013819, -92.0028444, -82.520596, -118.1039746, -122.0194346, -81.59968, -119.9652218, -121.9918469, -80.2559043, -117.67611310000001, -74.0717295, -116.28560139999999, -72.7010468, -83.63023079999999, -117.5886851, -76.2158395, -81.2641614, -105.0146221, -104.7640557, -86.6808618, -84.3039394, -119.11887970000001, -77.493291, -111.81469170000001, -118.5830621, -97.085786, -79.82309709999998, -118.20335349999999, -77.0121085, -83.3216202, -73.1464445, -119.0699317, -81.69586140000001, -111.11910120000002, -77.655827, -82.41997990000002, -83.95321390000001, -85.5388817, -73.3791696, -87.3912228, -83.9729365, -85.66727829999999, -77.5182829, -96.8150999, -91.3450421, -86.4218265, -121.2774336, -80.4262045, -80.9106075, -81.7252802, -86.86523249999999, -117.78199679999999, -82.5690391, -116.8492507, -77.1801939, -85.01035990000001, -118.460655, -104.84972629999999, -122.4745331, -82.1308213, -121.90196540000001, -92.9133764, -71.13714159999999, -117.07240729999998, -78.56697, -74.13685490000002, -81.78414690000001, -80.6528806, -93.3133625, -111.56212909999999, -117.6933882, -83.9200147, -122.4690923, -72.9772052, -111.99314009999999, -123.0350176, -88.4093984, -87.96901690000001, -117.309149, -122.3043688, -112.50139420000001, -96.5738493, -121.3352428, -121.1811222, -92.10202659999999, -89.84271020000001, -88.0368551, -87.8972725, -110.89989569999999, -122.89084720000001, -80.7688395, -73.03407779999999, -104.76373249999999, -83.87077420000001, -91.04650079999999, -87.53637009999998, -116.92865, -71.9513754, -111.528697, -80.1990921, -83.1494625, -84.704128, -76.899811, -73.563186, -119.85075069999999, -92.4607571, -106.59548400000001, -90.4902891, -94.6283243, -81.9084412, -77.01824549999999, -82.176615, -117.7391591, -83.5480189, -84.4718611, -82.12849240000001, -86.44148059999999, -122.5964115, -89.0145959, -106.5810659, -111.7153517, -88.6014427, -76.5404207, -97.0381436, -81.77795809999999, -70.9229142, -82.1218361, -84.44789279999999, -74.5363043, -77.384211, -90.1955376, -80.6785674, -117.7984846, -75.67710670000001, -84.4167094, -84.4754314, -88.99097629999999, -118.1269528, -76.9911738, -94.8285374, -104.60041329999999, -87.1796286, -84.18767659999999, -81.9463201, -87.77226479999999, -84.0519014, -105.0792047, -116.367522, -73.2545352, -94.41458370000001, -85.27037740000002, -81.9031052, -84.16511170000001, -82.7809295, -123.1411884, -118.3794518, -105.0815406, -118.18501909999999, -119.26494620000001, -93.2082804, -76.8021022, -118.5964298, -82.28766309999999, -73.0801902, -77.58632159999999, -157.8189501, -84.9611645, -83.45416, -117.64980829999999, -77.1067237, -69.7073145, -72.595582, -122.69148090000002, -122.2365335, -84.8391427, -96.7748515, -121.3695435, -117.2571877, -90.2336686, -116.9617915, -81.6290686, -74.01667979999999, -81.5097052, -78.45248079999999, -87.65324129999999, -121.46317859999998, -104.867667, -120.49909950000001, -76.96844300000001, -118.14712079999998, -123.10828300000001, -118.03661229999999, -75.00228709999999, -89.9053053, -122.28300279999999, -80.645168, -86.129808, -105.8783655, -119.0038623, -88.1497543, -117.05226850000001, -117.10310079999999, -122.6193665, -104.77200699999999, -81.4294524, -71.5621815, -71.1414485, -76.8060245, -118.8593759, -79.8093069, -86.2129746, -87.8918628, -89.9957721, -77.2505262, -90.0973878, -113.28615220000002, -88.827967, -90.4690325, -66.1859103, -93.249169, -121.30757279999999, -117.9082621, -93.2924425, -122.30330320000002, -115.19573030000001, -111.60786499999999, -97.04842109999998, -114.2068706, -81.6319421, -87.5824598, -84.60633670000001, -117.3032479, -74.184442, -84.1355805, -71.32457679999999, -111.8604239, -118.1555455, -84.22634649999999, -114.51140320000002, -95.99522309999999, -122.02590490000001, -82.26714190000001, -82.9518208, -79.9368033, -71.0703632, -105.0208384, -84.46619150000001, -121.164918, -122.85852690000002, -87.81207690000001, -71.0694208, -104.7654017, -71.29102840000002, -77.4534501, -104.73514, -77.69981429999999, -74.2886585, -122.3237353, -73.8827319, -114.80745320000001, -95.56692690000001, -74.1186885, -81.3291447, -121.8169777, -111.92328090000001, -72.83325119999999, -84.3974228, -77.0984854, -92.49519520000001, -80.3056734, -77.0045016, -80.186487, -73.91793740000001, -90.1742553, -104.729947, -82.755215, -124.17987079999999, -74.168588, -121.2400729, -97.7002768, -76.6083071, -83.67968499999999, -105.1331372, -115.3018253, -118.20315009999999, -121.52693119999999, -104.9730418, -77.48194009999999, -111.9636361, -92.3113125, -90.0225038, -77.0062645, -77.70428290000001, -119.6918625, -76.9930948, -82.9016155, -121.70565330000001, -83.24477409999999, -73.954356, -95.5079947, -77.4259416, -87.7614217, -71.0790559, -89.36580649999999, -93.2719382, -93.6138932, -83.7516184, -117.48001880000001, -117.14771110000001, -96.9288491, -117.8725713, -90.4482449, -84.0972463, -90.01037059999999, -121.3179767, -74.06139449999999, -118.44115179999999, -111.82288529999998, -107.22158950000001, -78.0777361, -119.83800249999999, -81.5602172, -80.207239, -71.1424773, -74.16816899999999, -81.9742659, -87.1745144, -88.0344922, -80.66629559999998, -71.4136777, -87.8054366, -86.7054437, -84.25714040000001, -93.7573113, -111.74171509999998, -122.2668834, -111.9339934, -82.32689029999999, -105.00470279999999, -122.6131385, -105.1828838, -85.3059832, -93.2785707, -79.95015740000001, -96.3445753, -96.42124229999999, -118.1898523, -104.79911870000001, -115.19847390000001, -89.8953467, -82.8213099, -95.4441139, -76.0203088, -92.3427654, -81.424715, -118.5622047, -73.0969285, -79.07768420000001, -84.74278690000001, -79.85135129999999, -117.6958358, -122.88153929999999, -86.1738852, -83.70968979999999, -73.8451396, -121.76422009999999, -93.2280411, -83.64548640000001, -105.01095090000001, -84.46676540000001, -80.1173962, -119.5492976, -121.8911828, -116.2164629, -83.36955259999999, -121.32605090000001, -105.1352355, -83.61206259999999, -87.73804109999999, -117.04906489999999, -71.0821193, -89.7001709, -122.5721528, -77.6254137, -122.5689312, -76.9850101, -122.5884602, -74.1245887, -76.3295069, -73.0636497, -81.4709671, -88.3746439, -116.9358977, -82.05766690000002, -74.71786359999999, -157.9900179, -92.910852, -122.39045829999999, -117.68418100000001, -104.7967638, -121.3373166, -118.4661393, -78.70428829999999, -76.73331479999999, -121.24290249999999, -75.1251352], "type": "scattergeo"}],
                            {"geo": {"countrycolor": "rgb(255, 255, 255)", "lakecolor": "rgb(255, 255, 255)", "landcolor": "rgb(212, 212, 212)", "lataxis": {"dtick": 5, "gridwidth": 0.5, "range": [20.0, 60.0], "showgrid": true}, "lonaxis": {"dtick": 5, "gridwidth": 0.5, "range": [-140.0, -55.0], "showgrid": true}, "projection": {"rotation": {"lon": -100}, "type": "conic conformal"}, "resolution": 50, "scope": "north america", "showcountries": true, "showlakes": true, "showland": true, "showsubunits": true, "subunitcolor": "rgb(255, 255, 255)"}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}, "title": {"text": "Top 2,500 locations with second mortgage is the highest and percent ownership is above 10 percent"}},
                            {"responsive": true}
                        ).then(function(){
    
    var gd = document.getElementById('23b74194-1832-4765-b19c-724b5da80806');
    var x = new MutationObserver(function (mutations, observer) {{
            var display = window.getComputedStyle(gd).display;
            if (!display || display === 'none') {{
                console.log([gd, 'removed!']);
                Plotly.purge(gd);
                observer.disconnect();
            }}
    }});
    
    // Listen for the removal of the full notebook cells
    var notebookContainer = gd.closest('#notebook-container');
    if (notebookContainer) {{
        x.observe(notebookContainer, {childList: true});
    }}
    
    // Listen for the clearing of the current output cell
    var outputEl = gd.closest('.output');
    if (outputEl) {{
        x.observe(outputEl, {childList: true});
    }}
    
                            })
                    };
                    });
                </script>
            </div>


Use the following bad debt equation: Bad Debt = P (Second Mortgage ∩ Home Equity Loan) Bad Debt = second_mortgage + home_equity - home_equity_second_mortgage c) Create pie charts to show overall debt and bad debt
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    df_train['bad_debt']=df_train['second_mortgage']+df_train['home_equity']-df_train['home_equity_second_mortgage']

.. code:: ipython3

    df_train['bins'] = pd.cut(df_train['bad_debt'],bins=[0,0.10,1], labels=["less than 50%","50-100%"])
    df_train.groupby(['bins']).size().plot(kind='pie',subplots=True,startangle=90, autopct='%1.1f%%')
    plt.axis('equal')
    
    plt.show()
    #df.plot.pie(subplots=True,figsize=(8, 3))



.. image:: output_34_0.png


Create Box and whisker plot and analyze the distribution for 2nd mortgage, home equity, good debt, and bad debt for different cities
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    cols=[]
    df_train.columns




.. parsed-literal::

    Index(['COUNTYID', 'STATEID', 'state', 'state_ab', 'city', 'place', 'type',
           'primary', 'zip_code', 'area_code', 'lat', 'lng', 'ALand', 'AWater',
           'pop', 'male_pop', 'female_pop', 'rent_mean', 'rent_median',
           'rent_stdev', 'rent_sample_weight', 'rent_samples', 'rent_gt_10',
           'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35',
           'rent_gt_40', 'rent_gt_50', 'universe_samples', 'used_samples',
           'hi_mean', 'hi_median', 'hi_stdev', 'hi_sample_weight', 'hi_samples',
           'family_mean', 'family_median', 'family_stdev', 'family_sample_weight',
           'family_samples', 'hc_mortgage_mean', 'hc_mortgage_median',
           'hc_mortgage_stdev', 'hc_mortgage_sample_weight', 'hc_mortgage_samples',
           'hc_mean', 'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight',
           'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt',
           'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree',
           'hs_degree_male', 'hs_degree_female', 'male_age_mean',
           'male_age_median', 'male_age_stdev', 'male_age_sample_weight',
           'male_age_samples', 'female_age_mean', 'female_age_median',
           'female_age_stdev', 'female_age_sample_weight', 'female_age_samples',
           'pct_own', 'married', 'married_snp', 'separated', 'divorced',
           'bad_debt', 'bins'],
          dtype='object')



.. code:: ipython3

    #Taking Hamilton and Manhattan cities data
    cols=['second_mortgage','home_equity','debt','bad_debt']
    df_box_hamilton=df_train.loc[df_train['city'] == 'Hamilton']
    df_box_manhattan=df_train.loc[df_train['city'] == 'Manhattan']
    df_box_city=pd.concat([df_box_hamilton,df_box_manhattan])
    df_box_city.head(4)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>state</th>
          <th>state_ab</th>
          <th>city</th>
          <th>place</th>
          <th>type</th>
          <th>primary</th>
          <th>zip_code</th>
          <th>area_code</th>
          <th>...</th>
          <th>female_age_stdev</th>
          <th>female_age_sample_weight</th>
          <th>female_age_samples</th>
          <th>pct_own</th>
          <th>married</th>
          <th>married_snp</th>
          <th>separated</th>
          <th>divorced</th>
          <th>bad_debt</th>
          <th>bins</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>267822</td>
          <td>53</td>
          <td>36</td>
          <td>New York</td>
          <td>NY</td>
          <td>Hamilton</td>
          <td>Hamilton</td>
          <td>City</td>
          <td>tract</td>
          <td>13346</td>
          <td>315</td>
          <td>...</td>
          <td>22.51276</td>
          <td>685.33845</td>
          <td>2618.0</td>
          <td>0.79046</td>
          <td>0.57851</td>
          <td>0.01882</td>
          <td>0.01240</td>
          <td>0.08770</td>
          <td>0.09408</td>
          <td>less than 50%</td>
        </tr>
        <tr>
          <td>263797</td>
          <td>21</td>
          <td>34</td>
          <td>New Jersey</td>
          <td>NJ</td>
          <td>Hamilton</td>
          <td>Yardville</td>
          <td>City</td>
          <td>tract</td>
          <td>8610</td>
          <td>609</td>
          <td>...</td>
          <td>24.05831</td>
          <td>732.58443</td>
          <td>3124.0</td>
          <td>0.64400</td>
          <td>0.56377</td>
          <td>0.01980</td>
          <td>0.00990</td>
          <td>0.04892</td>
          <td>0.18071</td>
          <td>50-100%</td>
        </tr>
        <tr>
          <td>270979</td>
          <td>17</td>
          <td>39</td>
          <td>Ohio</td>
          <td>OH</td>
          <td>Hamilton</td>
          <td>Hamilton City</td>
          <td>Village</td>
          <td>tract</td>
          <td>45015</td>
          <td>513</td>
          <td>...</td>
          <td>22.66500</td>
          <td>565.32725</td>
          <td>2528.0</td>
          <td>0.61278</td>
          <td>0.47397</td>
          <td>0.04419</td>
          <td>0.02663</td>
          <td>0.13741</td>
          <td>0.15005</td>
          <td>50-100%</td>
        </tr>
        <tr>
          <td>259028</td>
          <td>95</td>
          <td>28</td>
          <td>Mississippi</td>
          <td>MS</td>
          <td>Hamilton</td>
          <td>Hamilton</td>
          <td>CDP</td>
          <td>tract</td>
          <td>39746</td>
          <td>662</td>
          <td>...</td>
          <td>22.79602</td>
          <td>483.01311</td>
          <td>1954.0</td>
          <td>0.83241</td>
          <td>0.58678</td>
          <td>0.01052</td>
          <td>0.00000</td>
          <td>0.11721</td>
          <td>0.02130</td>
          <td>less than 50%</td>
        </tr>
      </tbody>
    </table>
    <p>4 rows × 79 columns</p>
    </div>



.. code:: ipython3

    plt.figure(figsize=(10,5))
    sns.boxplot(data=df_box_city,x='second_mortgage', y='city',width=0.5,palette="Set3")
    plt.show()



.. image:: output_38_0.png


.. code:: ipython3

    plt.figure(figsize=(10,5))
    sns.boxplot(data=df_box_city,x='home_equity', y='city',width=0.5,palette="Set3")
    plt.show()



.. image:: output_39_0.png


.. code:: ipython3

    plt.figure(figsize=(10,5))
    sns.boxplot(data=df_box_city,x='debt', y='city',width=0.5,palette="Set3")
    plt.show()



.. image:: output_40_0.png


.. code:: ipython3

    plt.figure(figsize=(10,5))
    sns.boxplot(data=df_box_city,x='bad_debt', y='city',width=0.5,palette="Set3")
    plt.show()



.. image:: output_41_0.png


Manhattan has higher metrics compared to Hamilton

Create a collated income distribution chart for family income, house hold income, and remaining income
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    sns.distplot(df_train['hi_mean'])
    plt.title('Household income distribution chart')
    plt.show()



.. image:: output_44_0.png


.. code:: ipython3

    sns.distplot(df_train['family_mean'])
    plt.title('Family income distribution chart')
    plt.show()



.. image:: output_45_0.png


.. code:: ipython3

    sns.distplot(df_train['family_mean']-df_train['hi_mean'])
    plt.title('Remaining income distribution chart')
    plt.show()



.. image:: output_46_0.png


Income distribution almost has normality in its distrbution

Perform EDA and come out with insights into population density and age. You may have to derive new fields (make sure to weight averages for accurate measurements):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    #plt.figure(figsize=(25,10))
    fig,(ax1,ax2,ax3)=plt.subplots(3,1)
    sns.distplot(df_train['pop'],ax=ax1)
    sns.distplot(df_train['male_pop'],ax=ax2)
    sns.distplot(df_train['female_pop'],ax=ax3)
    plt.subplots_adjust(wspace=0.8,hspace=0.8)
    plt.tight_layout()
    plt.show()



.. image:: output_49_0.png


.. code:: ipython3

    #plt.figure(figsize=(25,10))
    fig,(ax1,ax2)=plt.subplots(2,1)
    sns.distplot(df_train['male_age_mean'],ax=ax1)
    sns.distplot(df_train['female_age_mean'],ax=ax2)
    plt.subplots_adjust(wspace=0.8,hspace=0.8)
    plt.tight_layout()
    plt.show()



.. image:: output_50_0.png


a) Use pop and ALand variables to create a new field called population density
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_train['pop_density']=df_train['pop']/df_train['ALand']

.. code:: ipython3

    df_test['pop_density']=df_test['pop']/df_test['ALand']

.. code:: ipython3

    sns.distplot(df_train['pop_density'])
    plt.title('Population Density')
    plt.show() # Very less density is noticed



.. image:: output_54_0.png


Use male_age_median, female_age_median, male_pop, and female_pop to create a new field called median age c) Visualize the findings using appropriate chart type
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_train['age_median']=(df_train['male_age_median']+df_train['female_age_median'])/2
    df_test['age_median']=(df_test['male_age_median']+df_test['female_age_median'])/2

.. code:: ipython3

    df_train[['male_age_median','female_age_median','male_pop','female_pop','age_median']].head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>male_age_median</th>
          <th>female_age_median</th>
          <th>male_pop</th>
          <th>female_pop</th>
          <th>age_median</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>267822</td>
          <td>44.00000</td>
          <td>45.33333</td>
          <td>2612</td>
          <td>2618</td>
          <td>44.666665</td>
        </tr>
        <tr>
          <td>246444</td>
          <td>32.00000</td>
          <td>37.58333</td>
          <td>1349</td>
          <td>1284</td>
          <td>34.791665</td>
        </tr>
        <tr>
          <td>245683</td>
          <td>40.83333</td>
          <td>42.83333</td>
          <td>3643</td>
          <td>3238</td>
          <td>41.833330</td>
        </tr>
        <tr>
          <td>279653</td>
          <td>48.91667</td>
          <td>50.58333</td>
          <td>1141</td>
          <td>1559</td>
          <td>49.750000</td>
        </tr>
        <tr>
          <td>247218</td>
          <td>22.41667</td>
          <td>21.58333</td>
          <td>2586</td>
          <td>3051</td>
          <td>22.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    sns.distplot(df_train['age_median'])
    plt.title('Median Age')
    plt.show()
    # Age of population is mostly between 20 and 60
    # Majority are of age around 40
    # Median age distribution has a gaussian distribution
    # Some right skewness is noticed



.. image:: output_58_0.png


.. code:: ipython3

    sns.boxplot(df_train['age_median'])
    plt.title('Population Density')
    plt.show() 



.. image:: output_59_0.png


Create bins for population into a new variable by selecting appropriate class interval so that the number of categories don’t exceed 5 for the ease of analysis.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_train['pop'].describe()




.. parsed-literal::

    count    27321.000000
    mean      4316.032685
    std       2169.226173
    min          0.000000
    25%       2885.000000
    50%       4042.000000
    75%       5430.000000
    max      53812.000000
    Name: pop, dtype: float64



.. code:: ipython3

    df_train['pop_bins']=pd.cut(df_train['pop'],bins=5,labels=['very low','low','medium','high','very high'])

.. code:: ipython3

    df_train[['pop','pop_bins']]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>pop</th>
          <th>pop_bins</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>267822</td>
          <td>5230</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>246444</td>
          <td>2633</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>245683</td>
          <td>6881</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>279653</td>
          <td>2700</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>247218</td>
          <td>5637</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <td>279212</td>
          <td>1847</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>277856</td>
          <td>4155</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>233000</td>
          <td>2829</td>
          <td>very low</td>
        </tr>
        <tr>
          <td>287425</td>
          <td>11542</td>
          <td>low</td>
        </tr>
        <tr>
          <td>265371</td>
          <td>3726</td>
          <td>very low</td>
        </tr>
      </tbody>
    </table>
    <p>27321 rows × 2 columns</p>
    </div>



.. code:: ipython3

    df_train['pop_bins'].value_counts()




.. parsed-literal::

    very low     27058
    low            246
    medium           9
    high             7
    very high        1
    Name: pop_bins, dtype: int64



Analyze the married, separated, and divorced population for these population brackets
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_train.groupby(by='pop_bins')[['married','separated','divorced']].count()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>married</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
        <tr>
          <th>pop_bins</th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>very low</td>
          <td>27058</td>
          <td>27058</td>
          <td>27058</td>
        </tr>
        <tr>
          <td>low</td>
          <td>246</td>
          <td>246</td>
          <td>246</td>
        </tr>
        <tr>
          <td>medium</td>
          <td>9</td>
          <td>9</td>
          <td>9</td>
        </tr>
        <tr>
          <td>high</td>
          <td>7</td>
          <td>7</td>
          <td>7</td>
        </tr>
        <tr>
          <td>very high</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df_train.groupby(by='pop_bins')[['married','separated','divorced']].agg(["mean", "median"])




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead tr th {
            text-align: left;
        }
    
        .dataframe thead tr:last-of-type th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr>
          <th></th>
          <th colspan="2" halign="left">married</th>
          <th colspan="2" halign="left">separated</th>
          <th colspan="2" halign="left">divorced</th>
        </tr>
        <tr>
          <th></th>
          <th>mean</th>
          <th>median</th>
          <th>mean</th>
          <th>median</th>
          <th>mean</th>
          <th>median</th>
        </tr>
        <tr>
          <th>pop_bins</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>very low</td>
          <td>0.507548</td>
          <td>0.524680</td>
          <td>0.019126</td>
          <td>0.013650</td>
          <td>0.100504</td>
          <td>0.096020</td>
        </tr>
        <tr>
          <td>low</td>
          <td>0.584894</td>
          <td>0.593135</td>
          <td>0.015833</td>
          <td>0.011195</td>
          <td>0.075348</td>
          <td>0.070045</td>
        </tr>
        <tr>
          <td>medium</td>
          <td>0.655737</td>
          <td>0.618710</td>
          <td>0.005003</td>
          <td>0.004120</td>
          <td>0.065927</td>
          <td>0.064890</td>
        </tr>
        <tr>
          <td>high</td>
          <td>0.503359</td>
          <td>0.335660</td>
          <td>0.008141</td>
          <td>0.002500</td>
          <td>0.039030</td>
          <td>0.010320</td>
        </tr>
        <tr>
          <td>very high</td>
          <td>0.734740</td>
          <td>0.734740</td>
          <td>0.004050</td>
          <td>0.004050</td>
          <td>0.030360</td>
          <td>0.030360</td>
        </tr>
      </tbody>
    </table>
    </div>



1. Very high population group has more married people and less
   percantage of separated and divorced couples
2. In very low population groups, there are more divorced people

Visualize using appropriate chart type
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    plt.figure(figsize=(10,5))
    pop_bin_married=df_train.groupby(by='pop_bins')[['married','separated','divorced']].agg(["mean"])
    pop_bin_married.plot(figsize=(20,8))
    plt.legend(loc='best')
    plt.show()



.. parsed-literal::

    <Figure size 720x360 with 0 Axes>



.. image:: output_70_1.png


Please detail your observations for rent as a percentage of income at an overall level, and for different states.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    rent_state_mean=df_train.groupby(by='state')['rent_mean'].agg(["mean"])
    rent_state_mean.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>mean</th>
        </tr>
        <tr>
          <th>state</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Alabama</td>
          <td>774.004927</td>
        </tr>
        <tr>
          <td>Alaska</td>
          <td>1185.763570</td>
        </tr>
        <tr>
          <td>Arizona</td>
          <td>1097.753511</td>
        </tr>
        <tr>
          <td>Arkansas</td>
          <td>720.918575</td>
        </tr>
        <tr>
          <td>California</td>
          <td>1471.133857</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    income_state_mean=df_train.groupby(by='state')['family_mean'].agg(["mean"])
    income_state_mean.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>mean</th>
        </tr>
        <tr>
          <th>state</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Alabama</td>
          <td>67030.064213</td>
        </tr>
        <tr>
          <td>Alaska</td>
          <td>92136.545109</td>
        </tr>
        <tr>
          <td>Arizona</td>
          <td>73328.238798</td>
        </tr>
        <tr>
          <td>Arkansas</td>
          <td>64765.377850</td>
        </tr>
        <tr>
          <td>California</td>
          <td>87655.470820</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    rent_perc_of_income=rent_state_mean['mean']/income_state_mean['mean']
    rent_perc_of_income.head(10)




.. parsed-literal::

    state
    Alabama                 0.011547
    Alaska                  0.012870
    Arizona                 0.014970
    Arkansas                0.011131
    California              0.016783
    Colorado                0.013529
    Connecticut             0.012637
    Delaware                0.012929
    District of Columbia    0.013198
    Florida                 0.015772
    Name: mean, dtype: float64



.. code:: ipython3

    #overall level rent as a percentage of income
    sum(df_train['rent_mean'])/sum(df_train['family_mean'])




.. parsed-literal::

    0.013358170721473864



Perform correlation analysis for all the relevant variables by creating a heatmap. Describe your findings.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_train.columns




.. parsed-literal::

    Index(['COUNTYID', 'STATEID', 'state', 'state_ab', 'city', 'place', 'type',
           'primary', 'zip_code', 'area_code', 'lat', 'lng', 'ALand', 'AWater',
           'pop', 'male_pop', 'female_pop', 'rent_mean', 'rent_median',
           'rent_stdev', 'rent_sample_weight', 'rent_samples', 'rent_gt_10',
           'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35',
           'rent_gt_40', 'rent_gt_50', 'universe_samples', 'used_samples',
           'hi_mean', 'hi_median', 'hi_stdev', 'hi_sample_weight', 'hi_samples',
           'family_mean', 'family_median', 'family_stdev', 'family_sample_weight',
           'family_samples', 'hc_mortgage_mean', 'hc_mortgage_median',
           'hc_mortgage_stdev', 'hc_mortgage_sample_weight', 'hc_mortgage_samples',
           'hc_mean', 'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight',
           'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt',
           'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree',
           'hs_degree_male', 'hs_degree_female', 'male_age_mean',
           'male_age_median', 'male_age_stdev', 'male_age_sample_weight',
           'male_age_samples', 'female_age_mean', 'female_age_median',
           'female_age_stdev', 'female_age_sample_weight', 'female_age_samples',
           'pct_own', 'married', 'married_snp', 'separated', 'divorced',
           'bad_debt', 'bins', 'pop_density', 'age_median', 'pop_bins'],
          dtype='object')



.. code:: ipython3

    cor=df_train[['COUNTYID','STATEID','zip_code','type','pop', 'family_mean',
             'second_mortgage', 'home_equity', 'debt','hs_degree',
               'age_median','pct_own', 'married','separated', 'divorced']].corr()

.. code:: ipython3

    plt.figure(figsize=(20,10))
    sns.heatmap(cor,annot=True,cmap='coolwarm')
    plt.show()



.. image:: output_79_0.png


1. High positive correaltion is noticed between pop, male_pop and
   female_pop
2. High positive correaltion is noticed between rent_mean,hi_mean,
   family_mean,hc_mean

1. The economic multivariate data has a significant number of measured variables. The goal is to find where the measured variables depend on a number of smaller unobserved common factors or latent variables. 2. Each variable is assumed to be dependent upon a linear combination of the common factors, and the coefficients are known as loadings. Each measured variable also includes a component due to independent random variability, known as “specific variance” because it is specific to one variable. Obtain the common factors and then plot the loadings. Use factor analysis to find latent variables in our dataset and gain insight into the linear relationships in the data. Following are the list of latent variables:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

• Highschool graduation rates • Median population age • Second mortgage
statistics • Percent own • Bad debt expense

.. code:: ipython3

    from sklearn.decomposition import FactorAnalysis
    from factor_analyzer import FactorAnalyzer

.. code:: ipython3

    #pip install factor_analyzer

.. code:: ipython3

    fa=FactorAnalyzer(n_factors=5)
    fa.fit_transform(df_train.select_dtypes(exclude= ('object','category')))
    fa.loadings_




.. parsed-literal::

    array([[-1.12589168e-01,  1.95646475e-02, -2.39331087e-02,
            -6.27632638e-02,  4.23474753e-02],
           [-1.10186763e-01,  1.33506222e-02,  2.79651240e-02,
            -1.49825865e-01,  1.10838809e-01],
           [-8.28678615e-02,  5.16372371e-02, -1.36451863e-01,
            -4.98918578e-02, -1.04024836e-01],
           [ 1.80961148e-02,  1.92013750e-02,  5.81329806e-03,
             2.64842730e-02, -6.12442435e-03],
           [ 9.02324721e-02, -9.72544319e-02, -6.54601343e-02,
            -1.33145904e-01, -1.48594605e-01],
           [-1.07335676e-02, -4.12376817e-02,  1.45853485e-01,
             8.80433269e-03,  1.08227570e-01],
           [-4.28796978e-02, -2.09780213e-02,  3.66726856e-02,
            -9.45597337e-02,  5.91380485e-02],
           [-2.44243078e-03, -1.53245408e-02, -2.68300811e-03,
            -4.52473017e-02,  2.37240639e-02],
           [ 7.92164317e-02,  9.57453306e-01, -8.71151628e-02,
            -6.59924032e-03, -3.97273193e-02],
           [ 7.39808192e-02,  9.18750508e-01, -1.08834838e-01,
            -2.79371593e-02, -3.93153650e-02],
           [ 8.06598882e-02,  9.47839205e-01, -6.08006510e-02,
             1.53627067e-02, -3.86977277e-02],
           [ 7.70052132e-01,  9.84675230e-03, -3.71249746e-02,
             1.14949043e-01, -1.23784684e-01],
           [ 7.18615886e-01,  6.24980329e-03, -4.59787405e-02,
             1.09109691e-01, -1.35301909e-01],
           [ 7.07647234e-01,  2.46625383e-02, -1.00860855e-02,
             1.04472483e-01,  7.72381182e-02],
           [-1.34545497e-01,  3.36809292e-01, -4.87894952e-01,
            -4.15446148e-02,  3.17608517e-01],
           [ 2.31079714e-01,  4.37729796e-01, -6.40209222e-01,
            -2.52311048e-02,  3.47216238e-01],
           [-4.52068115e-02,  3.51263839e-02,  3.07537010e-02,
             4.44793499e-01, -1.63273407e-01],
           [-2.50717063e-02,  1.70166786e-02,  4.57227294e-02,
             6.76083909e-01, -1.55256768e-01],
           [-3.90694433e-02, -1.67460881e-02,  8.13962719e-02,
             8.36389121e-01, -9.18259814e-02],
           [-5.14161938e-02, -3.57207142e-02,  1.10795163e-01,
             9.25123727e-01, -4.44866453e-02],
           [-6.08589974e-02, -4.41860619e-02,  1.35794016e-01,
             9.53019898e-01, -2.21548619e-02],
           [-4.57771131e-02, -5.25526131e-02,  1.41019879e-01,
             9.32702649e-01, -5.83303614e-07],
           [-4.19486024e-02, -5.90387643e-02,  1.28851779e-01,
             8.87316679e-01,  1.05894327e-02],
           [-2.47894610e-02, -7.29670562e-02,  9.41510472e-02,
             7.79023679e-01,  2.95352844e-02],
           [ 2.12258462e-01,  4.65992347e-01, -6.14495960e-01,
            -2.47660078e-02,  3.66644541e-01],
           [ 2.33057234e-01,  4.47057841e-01, -6.28263414e-01,
            -2.71547693e-02,  3.43419602e-01],
           [ 7.85157082e-01,  4.91249248e-02,  1.44540486e-01,
            -2.05217624e-01, -1.54523362e-01],
           [ 7.10324880e-01,  4.99730435e-02,  1.32239993e-01,
            -2.19171861e-01, -2.10505573e-01],
           [ 8.61780961e-01,  4.35044831e-02,  1.65839100e-01,
            -1.19850815e-01,  3.16733662e-02],
           [-2.23443275e-01,  8.46259563e-01, -4.61177203e-02,
             6.88599251e-02,  2.27742321e-01],
           [ 1.43837555e-01,  9.53197420e-01,  2.27887449e-02,
            -4.57890466e-02,  1.00796447e-01],
           [ 8.30286481e-01,  3.42025993e-02,  1.61106002e-01,
            -2.04570323e-01, -7.48710515e-02],
           [ 7.94476575e-01,  2.83818588e-02,  1.51219549e-01,
            -2.07681492e-01, -9.12497115e-02],
           [ 8.11481635e-01,  4.32314872e-02,  1.43645561e-01,
            -1.07778259e-01,  5.79540060e-02],
           [-3.37741910e-01,  8.64927632e-01,  3.58933714e-02,
             9.07183966e-02,  4.46327270e-02],
           [ 5.03572646e-02,  9.35515353e-01,  1.51475404e-01,
            -2.51501261e-02, -9.34471620e-02],
           [ 9.78242251e-01, -3.31490306e-02, -1.05261175e-01,
             4.50364249e-02,  7.37362095e-02],
           [ 9.59137197e-01, -3.90023025e-02, -1.20630340e-01,
             4.52591423e-02,  6.64877273e-02],
           [ 8.14087180e-01,  2.23057157e-03,  7.66518523e-02,
             2.02747442e-02,  1.27634825e-01],
           [-4.15353976e-01,  7.18339580e-01,  3.40068062e-01,
            -7.18402770e-02, -2.77950503e-01],
           [ 7.64912667e-02,  7.24900629e-01,  2.74193205e-01,
            -4.83952644e-02, -3.52988279e-01],
           [ 9.10390869e-01, -5.36541235e-02, -4.68641892e-02,
            -7.64183032e-04,  1.63870467e-01],
           [ 8.73011872e-01, -5.30302316e-02, -5.89943143e-02,
            -1.58989825e-03,  1.52417547e-01],
           [ 7.55087673e-01, -3.56133888e-03,  5.39542562e-02,
             4.24181456e-03,  2.58043485e-01],
           [-1.23469886e-01,  6.07438130e-01,  6.33039225e-01,
            -2.14798817e-02,  2.47973918e-01],
           [-3.42866894e-01,  5.59526285e-01,  5.88213014e-01,
            -2.51533511e-02,  2.18419887e-01],
           [-1.60867227e-01, -1.53062626e-02, -1.57026584e-01,
             1.09243758e-01, -6.61660849e-01],
           [-1.37306763e-01, -2.17250640e-02, -1.58408929e-01,
             1.25156192e-01, -6.71630804e-01],
           [ 2.45096179e-01, -2.54584602e-02, -2.66691424e-02,
             9.53148491e-02, -6.42510850e-01],
           [ 2.03988672e-01,  7.85172867e-02, -3.01656210e-01,
             2.28379435e-02, -6.29223308e-01],
           [ 1.08926097e-01, -6.34332391e-02, -3.36565249e-02,
            -9.49480501e-02,  6.81473864e-01],
           [-2.63787621e-01, -6.43281062e-03, -3.58792182e-02,
            -9.37962445e-02,  6.47817007e-01],
           [-2.15717047e-01, -7.36588959e-02,  3.50113235e-01,
            -1.95201601e-02,  6.36783767e-01],
           [ 3.94306145e-01,  6.09565687e-02,  2.55337866e-01,
            -2.20362098e-01, -1.84248083e-01],
           [ 4.07877887e-01,  6.27256518e-02,  2.23926911e-01,
            -2.10028736e-01, -1.71989226e-01],
           [ 3.53156876e-01,  5.36715662e-02,  2.69603574e-01,
            -2.16933222e-01, -1.80072075e-01],
           [ 2.33537257e-01, -4.91732977e-02,  8.14450780e-01,
             9.36688878e-02,  3.27131925e-01],
           [ 2.40298207e-01, -3.38140108e-02,  8.31496983e-01,
             7.52417611e-02,  2.46323609e-01],
           [-6.71839513e-02,  6.58504548e-02,  5.86207690e-01,
             8.72955237e-02,  9.12541356e-02],
           [ 5.59835543e-02,  8.17918702e-01, -1.78458350e-01,
            -1.55949440e-02, -3.34299742e-02],
           [ 7.16426395e-02,  9.23428543e-01, -1.07142695e-01,
            -2.78635384e-02, -4.35991121e-02],
           [ 1.92496948e-01, -4.75870397e-02,  8.03173211e-01,
             1.43492718e-01,  3.33862162e-01],
           [ 1.87644427e-01, -3.29941031e-02,  8.58024482e-01,
             1.31329950e-01,  2.55679717e-01],
           [-1.02263659e-01,  6.03984273e-02,  4.72982262e-01,
             7.36848412e-02,  1.12273909e-01],
           [ 6.14776642e-02,  8.77962748e-01, -1.50410286e-01,
             2.20991027e-02, -4.17158178e-02],
           [ 7.83728215e-02,  9.54508794e-01, -5.91095907e-02,
             1.64800924e-02, -4.32590992e-02],
           [-3.24381861e-02,  1.11167164e-01,  7.84467393e-01,
            -4.37718579e-02, -2.80931224e-01],
           [ 1.76682387e-01,  1.90494239e-01,  5.61405491e-01,
            -1.20746164e-01, -1.32570787e-01],
           [-6.37386686e-02, -7.03047914e-02, -2.68934059e-01,
             1.28589788e-01,  1.88507846e-01],
           [-1.56051274e-01, -7.08033933e-02, -1.45964499e-01,
             1.24253729e-01,  1.46293106e-01],
           [-3.56716296e-01, -5.29910744e-02,  1.47771604e-01,
             2.87196190e-02,  1.13159574e-01],
           [ 2.42173828e-01, -2.86199107e-02, -3.25958359e-02,
             1.05027812e-01, -6.55406062e-01],
           [ 3.50196763e-01, -1.05016417e-02, -3.95274130e-01,
             5.92876756e-02,  2.91651806e-01],
           [ 2.25671539e-01, -3.42672770e-02,  8.92876617e-01,
             1.12426808e-01,  2.67065195e-01]])



Data Modeling : Linear Regression
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. Build a linear Regression model to predict the total monthly
   expenditure for home mortgages loan. Please refer
   ‘deplotment_RE.xlsx’. Column hc_mortgage_mean is predicted variable.
   This is the mean monthly mortgage and owner costs of specified
   geographical location. Note: Exclude loans from prediction model
   which have NaN (Not a Number) values for hc_mortgage_mean.

.. code:: ipython3

    df_train.columns




.. parsed-literal::

    Index(['COUNTYID', 'STATEID', 'state', 'state_ab', 'city', 'place', 'type',
           'primary', 'zip_code', 'area_code', 'lat', 'lng', 'ALand', 'AWater',
           'pop', 'male_pop', 'female_pop', 'rent_mean', 'rent_median',
           'rent_stdev', 'rent_sample_weight', 'rent_samples', 'rent_gt_10',
           'rent_gt_15', 'rent_gt_20', 'rent_gt_25', 'rent_gt_30', 'rent_gt_35',
           'rent_gt_40', 'rent_gt_50', 'universe_samples', 'used_samples',
           'hi_mean', 'hi_median', 'hi_stdev', 'hi_sample_weight', 'hi_samples',
           'family_mean', 'family_median', 'family_stdev', 'family_sample_weight',
           'family_samples', 'hc_mortgage_mean', 'hc_mortgage_median',
           'hc_mortgage_stdev', 'hc_mortgage_sample_weight', 'hc_mortgage_samples',
           'hc_mean', 'hc_median', 'hc_stdev', 'hc_samples', 'hc_sample_weight',
           'home_equity_second_mortgage', 'second_mortgage', 'home_equity', 'debt',
           'second_mortgage_cdf', 'home_equity_cdf', 'debt_cdf', 'hs_degree',
           'hs_degree_male', 'hs_degree_female', 'male_age_mean',
           'male_age_median', 'male_age_stdev', 'male_age_sample_weight',
           'male_age_samples', 'female_age_mean', 'female_age_median',
           'female_age_stdev', 'female_age_sample_weight', 'female_age_samples',
           'pct_own', 'married', 'married_snp', 'separated', 'divorced',
           'bad_debt', 'bins', 'pop_density', 'age_median', 'pop_bins'],
          dtype='object')



.. code:: ipython3

    df_train['type'].unique()
    type_dict={'type':{'City':1, 
                       'Urban':2, 
                       'Town':3, 
                       'CDP':4, 
                       'Village':5, 
                       'Borough':6}
              }
    df_train.replace(type_dict,inplace=True)

.. code:: ipython3

    df_train['type'].unique()




.. parsed-literal::

    array([1, 2, 3, 4, 5, 6], dtype=int64)



.. code:: ipython3

    df_test.replace(type_dict,inplace=True)

.. code:: ipython3

    df_test['type'].unique()




.. parsed-literal::

    array([4, 1, 6, 3, 5, 2], dtype=int64)



.. code:: ipython3

    feature_cols=['COUNTYID','STATEID','zip_code','type','pop', 'family_mean',
             'second_mortgage', 'home_equity', 'debt','hs_degree',
               'age_median','pct_own', 'married','separated', 'divorced']

.. code:: ipython3

    x_train=df_train[feature_cols]
    y_train=df_train['hc_mortgage_mean']

.. code:: ipython3

    x_test=df_test[feature_cols]
    y_test=df_test['hc_mortgage_mean']

.. code:: ipython3

    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score, mean_absolute_error,mean_squared_error,accuracy_score

.. code:: ipython3

    x_train.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>COUNTYID</th>
          <th>STATEID</th>
          <th>zip_code</th>
          <th>type</th>
          <th>pop</th>
          <th>family_mean</th>
          <th>second_mortgage</th>
          <th>home_equity</th>
          <th>debt</th>
          <th>hs_degree</th>
          <th>age_median</th>
          <th>pct_own</th>
          <th>married</th>
          <th>separated</th>
          <th>divorced</th>
        </tr>
        <tr>
          <th>UID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>267822</td>
          <td>53</td>
          <td>36</td>
          <td>13346</td>
          <td>1</td>
          <td>5230</td>
          <td>67994.14790</td>
          <td>0.02077</td>
          <td>0.08919</td>
          <td>0.52963</td>
          <td>0.89288</td>
          <td>44.666665</td>
          <td>0.79046</td>
          <td>0.57851</td>
          <td>0.01240</td>
          <td>0.08770</td>
        </tr>
        <tr>
          <td>246444</td>
          <td>141</td>
          <td>18</td>
          <td>46616</td>
          <td>1</td>
          <td>2633</td>
          <td>50670.10337</td>
          <td>0.02222</td>
          <td>0.04274</td>
          <td>0.60855</td>
          <td>0.90487</td>
          <td>34.791665</td>
          <td>0.52483</td>
          <td>0.34886</td>
          <td>0.01426</td>
          <td>0.09030</td>
        </tr>
        <tr>
          <td>245683</td>
          <td>63</td>
          <td>18</td>
          <td>46122</td>
          <td>1</td>
          <td>6881</td>
          <td>95262.51431</td>
          <td>0.00000</td>
          <td>0.09512</td>
          <td>0.73484</td>
          <td>0.94288</td>
          <td>41.833330</td>
          <td>0.85331</td>
          <td>0.64745</td>
          <td>0.01607</td>
          <td>0.10657</td>
        </tr>
        <tr>
          <td>279653</td>
          <td>127</td>
          <td>72</td>
          <td>927</td>
          <td>2</td>
          <td>2700</td>
          <td>56401.68133</td>
          <td>0.01086</td>
          <td>0.01086</td>
          <td>0.52714</td>
          <td>0.91500</td>
          <td>49.750000</td>
          <td>0.65037</td>
          <td>0.47257</td>
          <td>0.02021</td>
          <td>0.10106</td>
        </tr>
        <tr>
          <td>247218</td>
          <td>161</td>
          <td>20</td>
          <td>66502</td>
          <td>1</td>
          <td>5637</td>
          <td>54053.42396</td>
          <td>0.05426</td>
          <td>0.05426</td>
          <td>0.51938</td>
          <td>1.00000</td>
          <td>22.000000</td>
          <td>0.13046</td>
          <td>0.12356</td>
          <td>0.00000</td>
          <td>0.03109</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    sc=StandardScaler()
    x_train_scaled=sc.fit_transform(x_train)
    x_test_scaled=sc.fit_transform(x_test)

Run a model at a Nation level. If the accuracy levels and R square are not satisfactory proceed to below step.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    linereg=LinearRegression()
    linereg.fit(x_train_scaled,y_train)




.. parsed-literal::

    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)



.. code:: ipython3

    y_pred=linereg.predict(x_test_scaled)

.. code:: ipython3

    print("Overall R2 score of linear regression model", r2_score(y_test,y_pred))
    print("Overall RMSE of linear regression model", np.sqrt(mean_squared_error(y_test,y_pred)))


.. parsed-literal::

    Overall R2 score of linear regression model 0.7348210754610929
    Overall RMSE of linear regression model 323.1018894984635


The Accuracy and R2 score are good, but still will investigate the model
performance at state level

Run another model at State level. There are 52 states in USA.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    state=df_train['STATEID'].unique()
    state[0:5]
    #Picking a few iDs 20,1,45,6




.. parsed-literal::

    array([36, 18, 72, 20,  1], dtype=int64)



.. code:: ipython3

    for i in [20,1,45]:
        print("State ID-",i)
        
        x_train_nation=df_train[df_train['COUNTYID']==i][feature_cols]
        y_train_nation=df_train[df_train['COUNTYID']==i]['hc_mortgage_mean']
        
        x_test_nation=df_test[df_test['COUNTYID']==i][feature_cols]
        y_test_nation=df_test[df_test['COUNTYID']==i]['hc_mortgage_mean']
        
        x_train_scaled_nation=sc.fit_transform(x_train_nation)
        x_test_scaled_nation=sc.fit_transform(x_test_nation)
        
        linereg.fit(x_train_scaled_nation,y_train_nation)
        y_pred_nation=linereg.predict(x_test_scaled_nation)
        
        print("Overall R2 score of linear regression model for state,",i,":-" ,r2_score(y_test_nation,y_pred_nation))
        print("Overall RMSE of linear regression model for state,",i,":-" ,np.sqrt(mean_squared_error(y_test_nation,y_pred_nation)))
        print("\n")


.. parsed-literal::

    State ID- 20
    Overall R2 score of linear regression model for state, 20 :- 0.6046603766461807
    Overall RMSE of linear regression model for state, 20 :- 307.9718899931473
    
    
    State ID- 1
    Overall R2 score of linear regression model for state, 1 :- 0.8104382475484616
    Overall RMSE of linear regression model for state, 1 :- 307.8275861848435
    
    
    State ID- 45
    Overall R2 score of linear regression model for state, 45 :- 0.7887446497855252
    Overall RMSE of linear regression model for state, 45 :- 225.69615420724136
    
    


.. code:: ipython3

    # To check the residuals

.. code:: ipython3

    residuals=y_test-y_pred
    residuals




.. parsed-literal::

    UID
    255504    281.969088
    252676    -69.935775
    276314    190.761969
    248614   -157.290627
    286865     -9.887017
                 ...    
    238088    -67.541646
    242811    -41.578757
    250127   -127.427569
    241096   -330.820475
    287763    217.760642
    Name: hc_mortgage_mean, Length: 11709, dtype: float64



.. code:: ipython3

    plt.hist(residuals) # Normal distribution of residuals




.. parsed-literal::

    (array([6.000e+00, 3.000e+00, 2.900e+01, 7.670e+02, 7.823e+03, 2.716e+03,
            3.010e+02, 4.900e+01, 1.200e+01, 3.000e+00]),
     array([-2515.04284233, -1982.92661329, -1450.81038425,  -918.69415521,
             -386.57792617,   145.53830287,   677.65453191,  1209.77076095,
             1741.88698999,  2274.00321903,  2806.11944807]),
     <a list of 10 Patch objects>)




.. image:: output_109_1.png


.. code:: ipython3

    sns.distplot(residuals)




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x1fc95516b88>




.. image:: output_110_1.png


.. code:: ipython3

    plt.scatter(residuals,y_pred) # Same variance and residuals does not have correlation with predictor
    # Independance of residuals




.. parsed-literal::

    <matplotlib.collections.PathCollection at 0x1fc951333c8>




.. image:: output_111_1.png


