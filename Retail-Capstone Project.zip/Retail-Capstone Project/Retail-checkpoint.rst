Retail
------

.. code:: ipython3

    #Load necessary Libraries
    import pandas as pd
    import numpy as np
    import seaborn as sns
    from operator import attrgetter
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt
    import datetime as dt
    from scipy.stats import skewnorm
    import scipy.stats as stats  
    from sklearn.preprocessing import LabelEncoder
    import pylab as p  
    from sklearn.preprocessing import StandardScaler

.. code:: ipython3

    df=pd.read_excel('Online Retail.xlsx',sheet_name='Online Retail')

.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>InvoiceNo</th>
          <th>StockCode</th>
          <th>Description</th>
          <th>Quantity</th>
          <th>InvoiceDate</th>
          <th>UnitPrice</th>
          <th>CustomerID</th>
          <th>Country</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>536365</td>
          <td>85123A</td>
          <td>WHITE HANGING HEART T-LIGHT HOLDER</td>
          <td>6</td>
          <td>2010-12-01 08:26:00</td>
          <td>2.55</td>
          <td>17850.0</td>
          <td>United Kingdom</td>
        </tr>
        <tr>
          <th>1</th>
          <td>536365</td>
          <td>71053</td>
          <td>WHITE METAL LANTERN</td>
          <td>6</td>
          <td>2010-12-01 08:26:00</td>
          <td>3.39</td>
          <td>17850.0</td>
          <td>United Kingdom</td>
        </tr>
        <tr>
          <th>2</th>
          <td>536365</td>
          <td>84406B</td>
          <td>CREAM CUPID HEARTS COAT HANGER</td>
          <td>8</td>
          <td>2010-12-01 08:26:00</td>
          <td>2.75</td>
          <td>17850.0</td>
          <td>United Kingdom</td>
        </tr>
        <tr>
          <th>3</th>
          <td>536365</td>
          <td>84029G</td>
          <td>KNITTED UNION FLAG HOT WATER BOTTLE</td>
          <td>6</td>
          <td>2010-12-01 08:26:00</td>
          <td>3.39</td>
          <td>17850.0</td>
          <td>United Kingdom</td>
        </tr>
        <tr>
          <th>4</th>
          <td>536365</td>
          <td>84029E</td>
          <td>RED WOOLLY HOTTIE WHITE HEART.</td>
          <td>6</td>
          <td>2010-12-01 08:26:00</td>
          <td>3.39</td>
          <td>17850.0</td>
          <td>United Kingdom</td>
        </tr>
      </tbody>
    </table>
    </div>



Data Cleaning
-------------

Checking the missing values
---------------------------

.. code:: ipython3

    df.isnull().sum()




.. parsed-literal::

    InvoiceNo           0
    StockCode           0
    Description      1454
    Quantity            0
    InvoiceDate         0
    UnitPrice           0
    CustomerID     135080
    Country             0
    dtype: int64



.. code:: ipython3

    df.dropna(subset=['CustomerID'], inplace=True)

.. code:: ipython3

    df.isnull().sum()




.. parsed-literal::

    InvoiceNo      0
    StockCode      0
    Description    0
    Quantity       0
    InvoiceDate    0
    UnitPrice      0
    CustomerID     0
    Country        0
    dtype: int64



Remove duplicate data records.
------------------------------

.. code:: ipython3

    df.duplicated().sum()




.. parsed-literal::

    5225



.. code:: ipython3

    df=df.drop_duplicates()

.. code:: ipython3

    df.duplicated().sum()




.. parsed-literal::

    0



Perform descriptive analytics on the given data.
------------------------------------------------

Country
~~~~~~~

.. code:: ipython3

    pd.DataFrame(df['Country'].unique())




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>0</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>United Kingdom</td>
        </tr>
        <tr>
          <th>1</th>
          <td>France</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Australia</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Netherlands</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Germany</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Norway</td>
        </tr>
        <tr>
          <th>6</th>
          <td>EIRE</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Switzerland</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Spain</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Poland</td>
        </tr>
        <tr>
          <th>10</th>
          <td>Portugal</td>
        </tr>
        <tr>
          <th>11</th>
          <td>Italy</td>
        </tr>
        <tr>
          <th>12</th>
          <td>Belgium</td>
        </tr>
        <tr>
          <th>13</th>
          <td>Lithuania</td>
        </tr>
        <tr>
          <th>14</th>
          <td>Japan</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Iceland</td>
        </tr>
        <tr>
          <th>16</th>
          <td>Channel Islands</td>
        </tr>
        <tr>
          <th>17</th>
          <td>Denmark</td>
        </tr>
        <tr>
          <th>18</th>
          <td>Cyprus</td>
        </tr>
        <tr>
          <th>19</th>
          <td>Sweden</td>
        </tr>
        <tr>
          <th>20</th>
          <td>Austria</td>
        </tr>
        <tr>
          <th>21</th>
          <td>Israel</td>
        </tr>
        <tr>
          <th>22</th>
          <td>Finland</td>
        </tr>
        <tr>
          <th>23</th>
          <td>Greece</td>
        </tr>
        <tr>
          <th>24</th>
          <td>Singapore</td>
        </tr>
        <tr>
          <th>25</th>
          <td>Lebanon</td>
        </tr>
        <tr>
          <th>26</th>
          <td>United Arab Emirates</td>
        </tr>
        <tr>
          <th>27</th>
          <td>Saudi Arabia</td>
        </tr>
        <tr>
          <th>28</th>
          <td>Czech Republic</td>
        </tr>
        <tr>
          <th>29</th>
          <td>Canada</td>
        </tr>
        <tr>
          <th>30</th>
          <td>Unspecified</td>
        </tr>
        <tr>
          <th>31</th>
          <td>Brazil</td>
        </tr>
        <tr>
          <th>32</th>
          <td>USA</td>
        </tr>
        <tr>
          <th>33</th>
          <td>European Community</td>
        </tr>
        <tr>
          <th>34</th>
          <td>Bahrain</td>
        </tr>
        <tr>
          <th>35</th>
          <td>Malta</td>
        </tr>
        <tr>
          <th>36</th>
          <td>RSA</td>
        </tr>
      </tbody>
    </table>
    </div>



Total Customers
~~~~~~~~~~~~~~~

.. code:: ipython3

    len(df['CustomerID'].unique())




.. parsed-literal::

    4372



Majority of Customer country wise
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    c=pd.DataFrame(df.groupby('Country')['CustomerID'].nunique())

.. code:: ipython3

    customercoutrywise=pd.DataFrame(c).sort_values(by='CustomerID', ascending=False)

.. code:: ipython3

    customercoutrywise




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>CustomerID</th>
        </tr>
        <tr>
          <th>Country</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>United Kingdom</th>
          <td>3950</td>
        </tr>
        <tr>
          <th>Germany</th>
          <td>95</td>
        </tr>
        <tr>
          <th>France</th>
          <td>87</td>
        </tr>
        <tr>
          <th>Spain</th>
          <td>31</td>
        </tr>
        <tr>
          <th>Belgium</th>
          <td>25</td>
        </tr>
        <tr>
          <th>Switzerland</th>
          <td>21</td>
        </tr>
        <tr>
          <th>Portugal</th>
          <td>19</td>
        </tr>
        <tr>
          <th>Italy</th>
          <td>15</td>
        </tr>
        <tr>
          <th>Finland</th>
          <td>12</td>
        </tr>
        <tr>
          <th>Austria</th>
          <td>11</td>
        </tr>
        <tr>
          <th>Norway</th>
          <td>10</td>
        </tr>
        <tr>
          <th>Netherlands</th>
          <td>9</td>
        </tr>
        <tr>
          <th>Australia</th>
          <td>9</td>
        </tr>
        <tr>
          <th>Denmark</th>
          <td>9</td>
        </tr>
        <tr>
          <th>Channel Islands</th>
          <td>9</td>
        </tr>
        <tr>
          <th>Cyprus</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Sweden</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Japan</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Poland</th>
          <td>6</td>
        </tr>
        <tr>
          <th>USA</th>
          <td>4</td>
        </tr>
        <tr>
          <th>Canada</th>
          <td>4</td>
        </tr>
        <tr>
          <th>Unspecified</th>
          <td>4</td>
        </tr>
        <tr>
          <th>Israel</th>
          <td>4</td>
        </tr>
        <tr>
          <th>Greece</th>
          <td>4</td>
        </tr>
        <tr>
          <th>EIRE</th>
          <td>3</td>
        </tr>
        <tr>
          <th>Malta</th>
          <td>2</td>
        </tr>
        <tr>
          <th>United Arab Emirates</th>
          <td>2</td>
        </tr>
        <tr>
          <th>Bahrain</th>
          <td>2</td>
        </tr>
        <tr>
          <th>Czech Republic</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Lithuania</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Lebanon</th>
          <td>1</td>
        </tr>
        <tr>
          <th>RSA</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Saudi Arabia</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Singapore</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Iceland</th>
          <td>1</td>
        </tr>
        <tr>
          <th>Brazil</th>
          <td>1</td>
        </tr>
        <tr>
          <th>European Community</th>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



Customer Order More than one item
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    n_orders = df.groupby(['CustomerID'])['InvoiceNo'].nunique()
    mult_orders_perc = np.sum(n_orders > 1) / df['CustomerID'].nunique()
    print(f'{100 * mult_orders_perc:.2f}% of customers ordered more than one item.')



.. parsed-literal::

    69.97% of customers ordered more than one item.


.. code:: ipython3

    
    ax = sns.distplot(n_orders, kde=False, hist=True)
    ax.set(title='Distribution of number of orders per customer',
           xlabel='# of orders', 
           ylabel='# of customers');
                        



.. image:: output_24_0.png


Data Transformation
===================

Cohort Analysis
---------------

.. code:: ipython3

    df['order_month'] = df['InvoiceDate'].dt.to_period('M')


.. code:: ipython3

    df['cohort'] = df.groupby('CustomerID')['InvoiceDate'] \
                     .transform('min') \
                     .dt.to_period('M') 

.. code:: ipython3

    df_cohort=pd.DataFrame(df.groupby(['cohort', 'order_month']) \
                  .agg(n_customers=('CustomerID', 'nunique')) \
                  .reset_index(drop=False)) 

a) Active customer each Cohort
------------------------------

.. code:: ipython3

    df_cohort['period_number'] = (df_cohort.order_month - df_cohort.cohort).apply(attrgetter('n'))
    df_cohort




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>cohort</th>
          <th>order_month</th>
          <th>n_customers</th>
          <th>period_number</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2010-12</td>
          <td>2010-12</td>
          <td>948</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2010-12</td>
          <td>2011-01</td>
          <td>362</td>
          <td>1</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2010-12</td>
          <td>2011-02</td>
          <td>317</td>
          <td>2</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2010-12</td>
          <td>2011-03</td>
          <td>367</td>
          <td>3</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2010-12</td>
          <td>2011-04</td>
          <td>341</td>
          <td>4</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>86</th>
          <td>2011-10</td>
          <td>2011-11</td>
          <td>93</td>
          <td>1</td>
        </tr>
        <tr>
          <th>87</th>
          <td>2011-10</td>
          <td>2011-12</td>
          <td>46</td>
          <td>2</td>
        </tr>
        <tr>
          <th>88</th>
          <td>2011-11</td>
          <td>2011-11</td>
          <td>321</td>
          <td>0</td>
        </tr>
        <tr>
          <th>89</th>
          <td>2011-11</td>
          <td>2011-12</td>
          <td>43</td>
          <td>1</td>
        </tr>
        <tr>
          <th>90</th>
          <td>2011-12</td>
          <td>2011-12</td>
          <td>41</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>91 rows × 4 columns</p>
    </div>



.. code:: ipython3

    cohort_pivot = df_cohort.pivot_table(index = 'cohort',
                                         columns = 'period_number',
                                         values = 'n_customers')
    cohort_pivot




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th>period_number</th>
          <th>0</th>
          <th>1</th>
          <th>2</th>
          <th>3</th>
          <th>4</th>
          <th>5</th>
          <th>6</th>
          <th>7</th>
          <th>8</th>
          <th>9</th>
          <th>10</th>
          <th>11</th>
          <th>12</th>
        </tr>
        <tr>
          <th>cohort</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>2010-12</th>
          <td>948.0</td>
          <td>362.0</td>
          <td>317.0</td>
          <td>367.0</td>
          <td>341.0</td>
          <td>376.0</td>
          <td>360.0</td>
          <td>336.0</td>
          <td>336.0</td>
          <td>374.0</td>
          <td>354.0</td>
          <td>474.0</td>
          <td>260.0</td>
        </tr>
        <tr>
          <th>2011-01</th>
          <td>421.0</td>
          <td>101.0</td>
          <td>119.0</td>
          <td>102.0</td>
          <td>138.0</td>
          <td>126.0</td>
          <td>110.0</td>
          <td>108.0</td>
          <td>131.0</td>
          <td>146.0</td>
          <td>155.0</td>
          <td>63.0</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-02</th>
          <td>380.0</td>
          <td>94.0</td>
          <td>73.0</td>
          <td>106.0</td>
          <td>102.0</td>
          <td>94.0</td>
          <td>97.0</td>
          <td>107.0</td>
          <td>98.0</td>
          <td>119.0</td>
          <td>35.0</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-03</th>
          <td>440.0</td>
          <td>84.0</td>
          <td>112.0</td>
          <td>96.0</td>
          <td>102.0</td>
          <td>78.0</td>
          <td>116.0</td>
          <td>105.0</td>
          <td>127.0</td>
          <td>39.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-04</th>
          <td>299.0</td>
          <td>68.0</td>
          <td>66.0</td>
          <td>63.0</td>
          <td>62.0</td>
          <td>71.0</td>
          <td>69.0</td>
          <td>78.0</td>
          <td>25.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-05</th>
          <td>279.0</td>
          <td>66.0</td>
          <td>48.0</td>
          <td>48.0</td>
          <td>60.0</td>
          <td>68.0</td>
          <td>74.0</td>
          <td>29.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-06</th>
          <td>235.0</td>
          <td>49.0</td>
          <td>44.0</td>
          <td>64.0</td>
          <td>58.0</td>
          <td>79.0</td>
          <td>24.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-07</th>
          <td>191.0</td>
          <td>40.0</td>
          <td>39.0</td>
          <td>44.0</td>
          <td>52.0</td>
          <td>22.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-08</th>
          <td>167.0</td>
          <td>42.0</td>
          <td>42.0</td>
          <td>42.0</td>
          <td>23.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-09</th>
          <td>298.0</td>
          <td>89.0</td>
          <td>97.0</td>
          <td>36.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-10</th>
          <td>352.0</td>
          <td>93.0</td>
          <td>46.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-11</th>
          <td>321.0</td>
          <td>43.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-12</th>
          <td>41.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    cohort_size = cohort_pivot.iloc[:,0]
    retention_matrix = cohort_pivot.divide(cohort_size, axis = 0)


.. code:: ipython3

    retention_matrix




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th>period_number</th>
          <th>0</th>
          <th>1</th>
          <th>2</th>
          <th>3</th>
          <th>4</th>
          <th>5</th>
          <th>6</th>
          <th>7</th>
          <th>8</th>
          <th>9</th>
          <th>10</th>
          <th>11</th>
          <th>12</th>
        </tr>
        <tr>
          <th>cohort</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>2010-12</th>
          <td>1.0</td>
          <td>0.381857</td>
          <td>0.334388</td>
          <td>0.387131</td>
          <td>0.359705</td>
          <td>0.396624</td>
          <td>0.379747</td>
          <td>0.354430</td>
          <td>0.354430</td>
          <td>0.394515</td>
          <td>0.373418</td>
          <td>0.500000</td>
          <td>0.274262</td>
        </tr>
        <tr>
          <th>2011-01</th>
          <td>1.0</td>
          <td>0.239905</td>
          <td>0.282660</td>
          <td>0.242280</td>
          <td>0.327791</td>
          <td>0.299287</td>
          <td>0.261283</td>
          <td>0.256532</td>
          <td>0.311164</td>
          <td>0.346793</td>
          <td>0.368171</td>
          <td>0.149644</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-02</th>
          <td>1.0</td>
          <td>0.247368</td>
          <td>0.192105</td>
          <td>0.278947</td>
          <td>0.268421</td>
          <td>0.247368</td>
          <td>0.255263</td>
          <td>0.281579</td>
          <td>0.257895</td>
          <td>0.313158</td>
          <td>0.092105</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-03</th>
          <td>1.0</td>
          <td>0.190909</td>
          <td>0.254545</td>
          <td>0.218182</td>
          <td>0.231818</td>
          <td>0.177273</td>
          <td>0.263636</td>
          <td>0.238636</td>
          <td>0.288636</td>
          <td>0.088636</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-04</th>
          <td>1.0</td>
          <td>0.227425</td>
          <td>0.220736</td>
          <td>0.210702</td>
          <td>0.207358</td>
          <td>0.237458</td>
          <td>0.230769</td>
          <td>0.260870</td>
          <td>0.083612</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-05</th>
          <td>1.0</td>
          <td>0.236559</td>
          <td>0.172043</td>
          <td>0.172043</td>
          <td>0.215054</td>
          <td>0.243728</td>
          <td>0.265233</td>
          <td>0.103943</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-06</th>
          <td>1.0</td>
          <td>0.208511</td>
          <td>0.187234</td>
          <td>0.272340</td>
          <td>0.246809</td>
          <td>0.336170</td>
          <td>0.102128</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-07</th>
          <td>1.0</td>
          <td>0.209424</td>
          <td>0.204188</td>
          <td>0.230366</td>
          <td>0.272251</td>
          <td>0.115183</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-08</th>
          <td>1.0</td>
          <td>0.251497</td>
          <td>0.251497</td>
          <td>0.251497</td>
          <td>0.137725</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-09</th>
          <td>1.0</td>
          <td>0.298658</td>
          <td>0.325503</td>
          <td>0.120805</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-10</th>
          <td>1.0</td>
          <td>0.264205</td>
          <td>0.130682</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-11</th>
          <td>1.0</td>
          <td>0.133956</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2011-12</th>
          <td>1.0</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    with sns.axes_style("white"):
        fig, ax = plt.subplots(1, 2, figsize=(12, 8), sharey=True, gridspec_kw={'width_ratios': [1, 11]})
        
        # retention matrix
        sns.heatmap(retention_matrix, 
                    mask=retention_matrix.isnull(), 
                    annot=True, 
                    fmt='.0%', 
                    cmap='RdYlGn', 
                    ax=ax[1])
        ax[1].set_title('Monthly Cohorts: User Retention', fontsize=16)
        ax[1].set(xlabel='# of periods',
                  ylabel='')
    
        # cohort size
        cohort_size_df = pd.DataFrame(cohort_size).rename(columns={0: 'cohort_size'})
        white_cmap = mcolors.ListedColormap(['white'])
        sns.heatmap(cohort_size_df, 
                    annot=True, 
                    cbar=False, 
                    fmt='g', 
                    cmap=white_cmap, 
                    ax=ax[0])
    
        fig.tight_layout()



.. image:: output_34_0.png


Build RFM model

.. code:: ipython3

    df['InvoiceDate'].max()





.. parsed-literal::

    Timestamp('2011-12-09 12:50:00')



Latest Date is 2011-12-09 so in order to calculate recency we will use
2011-12-10

RFM metrics
~~~~~~~~~~~

.. code:: ipython3

    latestdate = dt.datetime(2011,12,10)
    rfmtable=df.groupby('CustomerID').agg({'InvoiceDate': lambda x: (latestdate - x.max()).days, 'InvoiceNo': lambda x: len(x),'UnitPrice': lambda x: x.sum()})
    rfmtable=rfmtable.rename(columns={'InvoiceDate': 'recency', 
                             'InvoiceNo': 'frequency', 
                             'UnitPrice': 'monetary_value'})
    rfmtable




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>recency</th>
          <th>frequency</th>
          <th>monetary_value</th>
        </tr>
        <tr>
          <th>CustomerID</th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>12346.0</th>
          <td>325</td>
          <td>2</td>
          <td>2.08</td>
        </tr>
        <tr>
          <th>12347.0</th>
          <td>2</td>
          <td>182</td>
          <td>481.21</td>
        </tr>
        <tr>
          <th>12348.0</th>
          <td>75</td>
          <td>31</td>
          <td>178.71</td>
        </tr>
        <tr>
          <th>12349.0</th>
          <td>18</td>
          <td>73</td>
          <td>605.10</td>
        </tr>
        <tr>
          <th>12350.0</th>
          <td>310</td>
          <td>17</td>
          <td>65.30</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>18280.0</th>
          <td>277</td>
          <td>10</td>
          <td>47.65</td>
        </tr>
        <tr>
          <th>18281.0</th>
          <td>180</td>
          <td>7</td>
          <td>39.36</td>
        </tr>
        <tr>
          <th>18282.0</th>
          <td>7</td>
          <td>13</td>
          <td>62.68</td>
        </tr>
        <tr>
          <th>18283.0</th>
          <td>3</td>
          <td>721</td>
          <td>1174.33</td>
        </tr>
        <tr>
          <th>18287.0</th>
          <td>42</td>
          <td>70</td>
          <td>104.55</td>
        </tr>
      </tbody>
    </table>
    <p>4372 rows × 3 columns</p>
    </div>



RFM segments
------------

Quantile

.. code:: ipython3

    quantiles = rfmtable.quantile(q=[0.25,0.5,0.75])
    quantiles.to_dict()
    





.. parsed-literal::

    {'recency': {0.25: 16.0, 0.5: 50.0, 0.75: 143.0},
     'frequency': {0.25: 17.0, 0.5: 41.0, 0.75: 99.25},
     'monetary_value': {0.25: 52.730000000000004, 0.5: 128.925, 0.75: 299.0975}}



.. code:: ipython3

    segmented_rfm = rfmtable

Recency must be low

.. code:: ipython3

    def recencyscore(x,p,d):
        if x <= d[p][0.25]:
            return 1
        elif x <= d[p][0.50]:
            return 2
        elif x <= d[p][0.75]:
            return 3
        else:
            return 4
        
    def fmscore(x,p,d):
        if x <= d[p][0.25]:
            return 4
        elif x <= d[p][0.50]:
            return 3
        elif x <= d[p][0.75]:
            return 2
        else:
            return 1    
        



.. code:: ipython3

    segmented_rfm['r_quartile'] = segmented_rfm['recency'].apply(recencyscore, args=('recency',quantiles,))
    segmented_rfm['f_quartile'] = segmented_rfm['frequency'].apply(fmscore, args=('frequency',quantiles,))
    segmented_rfm['m_quartile'] = segmented_rfm['monetary_value'].apply(fmscore, args=('monetary_value',quantiles,))
    
    
    segmented_rfm.head()





.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>recency</th>
          <th>frequency</th>
          <th>monetary_value</th>
          <th>r_quartile</th>
          <th>f_quartile</th>
          <th>m_quartile</th>
        </tr>
        <tr>
          <th>CustomerID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>12346.0</th>
          <td>325</td>
          <td>2</td>
          <td>2.08</td>
          <td>4</td>
          <td>4</td>
          <td>4</td>
        </tr>
        <tr>
          <th>12347.0</th>
          <td>2</td>
          <td>182</td>
          <td>481.21</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>12348.0</th>
          <td>75</td>
          <td>31</td>
          <td>178.71</td>
          <td>3</td>
          <td>3</td>
          <td>2</td>
        </tr>
        <tr>
          <th>12349.0</th>
          <td>18</td>
          <td>73</td>
          <td>605.10</td>
          <td>2</td>
          <td>2</td>
          <td>1</td>
        </tr>
        <tr>
          <th>12350.0</th>
          <td>310</td>
          <td>17</td>
          <td>65.30</td>
          <td>4</td>
          <td>4</td>
          <td>3</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    segmented_rfm.to_csv('SegmentedRFM.csv')
    segmented_rfm['RFMScore'] = segmented_rfm.r_quartile.map(str)+segmented_rfm.f_quartile.map(str)+segmented_rfm.m_quartile.map(str)
    
    segmented_rfm.head()





.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>recency</th>
          <th>frequency</th>
          <th>monetary_value</th>
          <th>r_quartile</th>
          <th>f_quartile</th>
          <th>m_quartile</th>
          <th>RFMScore</th>
        </tr>
        <tr>
          <th>CustomerID</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>12346.0</th>
          <td>325</td>
          <td>2</td>
          <td>2.08</td>
          <td>4</td>
          <td>4</td>
          <td>4</td>
          <td>444</td>
        </tr>
        <tr>
          <th>12347.0</th>
          <td>2</td>
          <td>182</td>
          <td>481.21</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>111</td>
        </tr>
        <tr>
          <th>12348.0</th>
          <td>75</td>
          <td>31</td>
          <td>178.71</td>
          <td>3</td>
          <td>3</td>
          <td>2</td>
          <td>332</td>
        </tr>
        <tr>
          <th>12349.0</th>
          <td>18</td>
          <td>73</td>
          <td>605.10</td>
          <td>2</td>
          <td>2</td>
          <td>1</td>
          <td>221</td>
        </tr>
        <tr>
          <th>12350.0</th>
          <td>310</td>
          <td>17</td>
          <td>65.30</td>
          <td>4</td>
          <td>4</td>
          <td>3</td>
          <td>443</td>
        </tr>
      </tbody>
    </table>
    </div>



Customer Segementation according to RFM
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    pd.set_option("display.max_colwidth", 10000)
    data = {'Customer Segement':['Best Customers', 'Loyal Customers', 'Big Spender', 'Almost Lost','Lost Customers','Lost Cheap Customers'], 'RFM':['111', 'X1X', 'XX1', '311','411','444'],'Desrciption':['Bought Most Recently and More Often', 'Buy Most Frequently', 'Spend The Most', 'Did not purchased for some time but purchased frequently and most','Did not purchased for some time but purchased frequently and most','Last purchased long ago,purchased few and spent little']}
    pd.DataFrame(data)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Customer Segement</th>
          <th>RFM</th>
          <th>Desrciption</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Best Customers</td>
          <td>111</td>
          <td>Bought Most Recently and More Often</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Loyal Customers</td>
          <td>X1X</td>
          <td>Buy Most Frequently</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Big Spender</td>
          <td>XX1</td>
          <td>Spend The Most</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Almost Lost</td>
          <td>311</td>
          <td>Did not purchased for some time but purchased frequently and most</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Lost Customers</td>
          <td>411</td>
          <td>Did not purchased for some time but purchased frequently and most</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Lost Cheap Customers</td>
          <td>444</td>
          <td>Last purchased long ago,purchased few and spent little</td>
        </tr>
      </tbody>
    </table>
    </div>



Clustering using K-mean

.. code:: ipython3

    cluster = segmented_rfm
    cluster = cluster.reset_index(level=0).iloc[:,[2,3]].values
    
    pd.DataFrame(cluster)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>0</th>
          <th>1</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2.0</td>
          <td>2.08</td>
        </tr>
        <tr>
          <th>1</th>
          <td>182.0</td>
          <td>481.21</td>
        </tr>
        <tr>
          <th>2</th>
          <td>31.0</td>
          <td>178.71</td>
        </tr>
        <tr>
          <th>3</th>
          <td>73.0</td>
          <td>605.10</td>
        </tr>
        <tr>
          <th>4</th>
          <td>17.0</td>
          <td>65.30</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>4367</th>
          <td>10.0</td>
          <td>47.65</td>
        </tr>
        <tr>
          <th>4368</th>
          <td>7.0</td>
          <td>39.36</td>
        </tr>
        <tr>
          <th>4369</th>
          <td>13.0</td>
          <td>62.68</td>
        </tr>
        <tr>
          <th>4370</th>
          <td>721.0</td>
          <td>1174.33</td>
        </tr>
        <tr>
          <th>4371</th>
          <td>70.0</td>
          <td>104.55</td>
        </tr>
      </tbody>
    </table>
    <p>4372 rows × 2 columns</p>
    </div>



.. code:: ipython3

    sc= StandardScaler()
    cluster = sc.fit_transform(cluster)

.. code:: ipython3

    sns.distplot(cluster[0])




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x2b563074448>




.. image:: output_53_1.png


.. code:: ipython3

    sns.distplot(cluster[1])




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x2b56e9b5488>




.. image:: output_54_1.png


WCSS

.. code:: ipython3

    from sklearn.cluster import KMeans
    wcss = []
    for i in range(1, 11):
        kmeans = KMeans(n_clusters = i, init = 'k-means++')
        kmeans.fit(cluster)
        wcss.append(kmeans.inertia_)
    plt.plot(range(1, 11), wcss)
    plt.title('The Elbow Method')
    plt.xlabel('Number of clusters')
    plt.ylabel('WCSS')
    plt.show()



.. image:: output_56_0.png


Optimum number of clusters to be formed is 4

.. code:: ipython3

    kmeans = KMeans(n_clusters = 4, init = 'k-means++')
    y_kmeans = kmeans.fit_predict(cluster)
    plt.scatter(cluster[y_kmeans == 0, 0], cluster[y_kmeans == 0, 1], s = 5, c = 'red', label = 'Lost Customer')
    plt.scatter(cluster[y_kmeans == 1, 0], cluster[y_kmeans == 1, 1], s = 5, c = 'blue', label = 'Loyal customer')
    plt.scatter(cluster[y_kmeans == 2, 0], cluster[y_kmeans == 2, 1], s = 5, c = 'green', label = 'Average Customers')
    plt.scatter(cluster[y_kmeans == 3, 0], cluster[y_kmeans == 3, 1], s = 5, c = 'cyan', label = 'Bought frequently but Spend less')
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s = 20, c = 'yellow', label = 'Centroids')
    plt.title('Clusters of customers')
    plt.xlabel('Total Spending')
    plt.ylabel('Buying Frequency')
    plt.legend()
    plt.show()



.. image:: output_58_0.png


